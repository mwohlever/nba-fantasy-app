"use client";

import {
  useEffect,
  useMemo,
  useState,
} from "react";

import AppNav from "@/components/AppNav";
import ReadOnlyPlayerModal from "@/components/lineups/ReadOnlyPlayerModal";
import PlayerResearchModal from "@/components/lineups/PlayerResearchModal";
import PlayerHeadshot from "@/components/ui/PlayerHeadshot";
import type {
  Player,
} from "@/components/lineups/types";
import {
  useSelectedSport,
} from "@/components/providers/SportProvider";

type PlayerHistoryRow = {
  player_id: number;
  player_name: string;

  nba_player_id: number | null;
  nfl_player_id: number | null;

  espn_golf_player_id?: string | null;
  headshot_url?: string | null;
  country?: string | null;
  owgr_rank?: number | null;

  times_drafted: number;

  avg_score: number;
  high_score: number;
  low_score: number;

  winning_lineups: number;
  runner_up_lineups: number;
  podium_lineups?: number;

  avg_finish: number | null;

  cuts_made?: number;
  cut_opportunities?: number;
  cuts_made_pct?: number | null;

  completed_rounds?: number;
  rounds_under_par?: number;

  birdies?: number;
  eagles?: number;
  albatrosses?: number;
  holes_in_one?: number;
  pars?: number;
  bogeys?: number;
  double_bogeys_or_worse?: number;

  /*
   * Real-world professional season statistics.
   * These are populated in Season Stats mode and
   * intentionally remain separate from 111 History.
   */
  position_group?: string | null;
  team_abbreviation?: string | null;

  season_games_played?: number | null;
  season_fantasy_points?: number | null;
  season_points?: number | null;
  season_rebounds?: number | null;
  season_assists?: number | null;
  season_steals?: number | null;
  season_blocks?: number | null;
  season_turnovers?: number | null;

  /*
   * NFL professional-season research stats.
   * Per-game values are used for ranking/comparison
   * so missed games do not distort player quality.
   */
  nfl_games_played?: number | null;

  nfl_fantasy_points_per_game?: number | null;

  nfl_passing_yards_per_game?: number | null;
  nfl_passing_tds_per_game?: number | null;
  nfl_passing_ints_per_game?: number | null;

  nfl_rushing_yards_per_game?: number | null;
  nfl_rushing_tds_per_game?: number | null;

  nfl_receiving_targets_per_game?: number | null;
  nfl_receptions_per_game?: number | null;
  nfl_receiving_yards_per_game?: number | null;
  nfl_receiving_tds_per_game?: number | null;

  nfl_fumbles_lost_per_game?: number | null;

  /*
   * PGA professional season research.
   */
  golf_season_tournaments_played?: number | null;
  golf_season_rounds_played?: number | null;

  golf_season_cuts_made?: number | null;
  golf_season_cuts_made_pct?: number | null;

  golf_season_wins?: number | null;
  golf_season_top_5?: number | null;
  golf_season_top_10?: number | null;

  golf_season_scoring_average?: number | null;

  golf_season_birdies_per_round?: number | null;
  golf_season_birdie_rate?: number | null;
  golf_season_bogey_rate?: number | null;

  golf_season_gir_pct?: number | null;
  golf_season_driving_accuracy_pct?: number | null;
  golf_season_driving_distance?: number | null;
  golf_season_putts_per_gir?: number | null;

  golf_season_has_detailed_stats?: boolean;
};

type SortKey =
  | "player_name"
  | "times_drafted"
  | "avg_score"
  | "high_score"
  | "low_score"
  | "winning_lineups"
  | "runner_up_lineups"
  | "podium_lineups"
  | "avg_finish"
  | "cuts_made_pct"
  | "birdies"
  | "eagles"
  | "albatrosses"
  | "holes_in_one"
  | "rounds_under_par"
  | "season_fantasy_points"
  | "season_points"
  | "season_rebounds"
  | "season_assists"
  | "season_steals"
  | "season_blocks"
  | "season_turnovers"
  | "nfl_fp"
  | "nfl_pass_yd"
  | "nfl_pass_td"
  | "nfl_int"
  | "nfl_rush_yd"
  | "nfl_rush_td"
  | "nfl_targets"
  | "nfl_receptions"
  | "nfl_rec_yd"
  | "nfl_rec_td"
  | "golf_scoring_avg"
  | "golf_cuts_pct"
  | "golf_wins"
  | "golf_top5"
  | "golf_top10"
  | "golf_birdies_round"
  | "golf_birdie_rate"
  | "golf_bogey_rate"
  | "golf_gir"
  | "golf_drive_acc"
  | "golf_drive_dist"
  | "golf_putts_gir"
  | "golf_events";

type SortDirection =
  | "asc"
  | "desc";

type HistoryMode =
  | "league"
  | "season";

type ApiResponse = {
  success: boolean;
  season: number | "all";
  sport?: string;
  playerHistory:
    PlayerHistoryRow[];
};

type GolfProfile = {
  success: boolean;

  selectedSeason:
    number | "all";

  player: {
    id: number;
    name: string;
    position_group:
      string | null;

    country?: string | null;

    owgrRank?:
      number | null;

    owgrUpdatedAt?:
      string | null;

    espnGolfPlayerId?:
      string | null;

    headshotUrl?:
      string | null;
  };

  summary: {
    timesDrafted: number;

    wins: number;
    runnerUps: number;
    podiums?: number;

    winRate:
      number | null;

    draftedMostBy: {
      teamName: string;
      count: number;
    } | null;

    draftedByBreakdown:
      Array<{
        teamName: string;
        count: number;
      }>;

    averageFantasyPoints:
      number | null;

    bestFantasyPoints:
      number | null;

    worstFantasyPoints:
      number | null;

    averageFinish:
      number | null;

    cutsMade?: number;
    cutOpportunities?: number;
    cutsMadePct?:
      number | null;

    birdies?: number;
    eagles?: number;
    albatrosses?: number;
    holesInOne?: number;

    pars?: number;
    bogeys?: number;
    doubleBogeysOrWorse?:
      number;

    roundsUnderPar?: number;
    completedRounds?: number;
  };

  recentHistory:
    Array<{
      slateId:
        number;

      slateLabel:
        string;

      teamName:
        string;

      finishPosition:
        number | null;

      fantasyPoints:
        number | null;

      golferScore?:
        number | null;

      status?:
        string | null;

      madeCut?:
        boolean | null;

      stats?: {
        birdies?: number;
        eagles?: number;
        albatrosses?: number;
        holesInOne?: number;

        pars?: number;
        bogeys?: number;
        doubleBogeysOrWorse?:
          number;

        roundsUnderPar?:
          number;

        completedRounds?:
          number;
      };
    }>;
};

function golfScore(
  value:
    number | null | undefined,
  digits = 1,
) {
  if (
    value === null ||
    value === undefined ||
    !Number.isFinite(
      Number(value),
    )
  ) {
    return "—";
  }

  const numeric =
    Number(value);

  const rounded =
    Number(
      numeric.toFixed(
        digits,
      ),
    );

  if (rounded === 0) {
    return "E";
  }

  if (rounded > 0) {
    return `+${rounded}`;
  }

  return String(
    rounded,
  );
}

function fmt(
  value:
    number | null | undefined,
  digits = 1,
) {
  if (
    value === null ||
    value === undefined
  ) {
    return "—";
  }

  return Number(
    value,
  ).toFixed(
    digits,
  );
}

function ordinal(
  position:
    number | null | undefined,
) {
  if (!position) {
    return "—";
  }

  const mod100 =
    position % 100;

  if (
    mod100 >= 11 &&
    mod100 <= 13
  ) {
    return `${position}th`;
  }

  const mod10 =
    position % 10;

  if (mod10 === 1) {
    return `${position}st`;
  }

  if (mod10 === 2) {
    return `${position}nd`;
  }

  if (mod10 === 3) {
    return `${position}rd`;
  }

  return `${position}th`;
}

function cutDisplay(
  made:
    number | undefined,
  opportunities:
    number | undefined,
) {
  const safeMade =
    made ?? 0;

  const safeOpportunities =
    opportunities ?? 0;

  if (
    safeOpportunities === 0
  ) {
    return "—";
  }

  return (
    `${safeMade}/` +
    `${safeOpportunities}`
  );
}

function GolfStatCard({
  label,
  value,
  detail,
}: {
  label: string;
  value:
    string | number;
  detail?: string;
}) {
  return (
    <div className="rounded-2xl border border-emerald-100 bg-white p-4 shadow-sm">
      <div className="text-[11px] font-bold uppercase tracking-[0.16em] text-slate-500">
        {label}
      </div>

      <div className="mt-1 text-2xl font-black text-slate-950">
        {value}
      </div>

      {detail ? (
        <div className="mt-1 text-xs text-slate-500">
          {detail}
        </div>
      ) : null}
    </div>
  );
}

function GolfPlayerHistoryModal({
  row,
  season,
  onClose,
}: {
  row:
    PlayerHistoryRow | null;

  season:
    number | "all";

  onClose: () => void;
}) {
  const [
    profile,
    setProfile,
  ] =
    useState<GolfProfile | null>(
      null,
    );

  const [
    isLoading,
    setIsLoading,
  ] =
    useState(false);

  const [
    error,
    setError,
  ] =
    useState("");

  useEffect(() => {
    if (!row) {
      setProfile(null);
      setError("");
      return;
    }

    let isActive =
      true;

    async function loadProfile() {
      try {
        setIsLoading(true);
        setError("");

        const response =
          await fetch(
            `/api/player-league-profile?playerId=${row?.player_id}&season=${season}&sport=golf`,
            {
              cache:
                "no-store",
            },
          );

        const result =
          await response.json();

        if (!isActive) {
          return;
        }

        if (
          !response.ok
        ) {
          setError(
            result.error ??
              "Unable to load golfer history.",
          );

          setProfile(null);
          return;
        }

        setProfile(
          result as GolfProfile,
        );
      } catch (
        loadError
      ) {
        console.error(
          loadError,
        );

        if (
          isActive
        ) {
          setError(
            "Unable to load golfer history.",
          );

          setProfile(
            null,
          );
        }
      } finally {
        if (
          isActive
        ) {
          setIsLoading(
            false,
          );
        }
      }
    }

    void loadProfile();

    return () => {
      isActive =
        false;
    };
  }, [
    row,
    season,
  ]);

  useEffect(() => {
    if (!row) {
      return;
    }

    function handleKeyDown(
      event:
        KeyboardEvent,
    ) {
      if (
        event.key ===
        "Escape"
      ) {
        onClose();
      }
    }

    window.addEventListener(
      "keydown",
      handleKeyDown,
    );

    return () => {
      window.removeEventListener(
        "keydown",
        handleKeyDown,
      );
    };
  }, [
    row,
    onClose,
  ]);

  if (!row) {
    return null;
  }

  const summary =
    profile?.summary;

  const player =
    profile?.player;

  const headshotUrl =
    player?.headshotUrl ??
    row.headshot_url ??
    (
      row.espn_golf_player_id
        ? `https://a.espncdn.com/i/headshots/golf/players/full/${row.espn_golf_player_id}.png`
        : null
    );

  return (
    <div
      className="fixed inset-0 z-[100] flex items-end justify-center bg-slate-950/65 p-0 backdrop-blur-sm sm:items-center sm:p-6"
      onMouseDown={
        (
          event,
        ) => {
          if (
            event.target ===
            event.currentTarget
          ) {
            onClose();
          }
        }
      }
    >
      <div className="max-h-[94vh] w-full overflow-y-auto rounded-t-[28px] bg-slate-50 shadow-2xl sm:max-w-4xl sm:rounded-[28px]">
        <div className="sticky top-0 z-10 border-b border-slate-200 bg-white/95 px-4 py-4 backdrop-blur sm:px-6">
          <div className="flex items-center justify-between gap-4">
            <div className="text-xs font-black uppercase tracking-[0.22em] text-emerald-700">
              Golfer History
            </div>

            <button
              type="button"
              onClick={
                onClose
              }
              className="flex h-9 w-9 items-center justify-center rounded-full bg-slate-100 text-lg font-bold text-slate-600 transition hover:bg-slate-200"
              aria-label="Close golfer history"
            >
              ×
            </button>
          </div>
        </div>

        {isLoading ? (
          <div className="p-8 text-center text-sm text-slate-500">
            Loading golfer history...
          </div>
        ) : error ? (
          <div className="p-6">
            <div className="rounded-2xl border border-red-200 bg-red-50 px-4 py-4 text-sm text-red-700">
              {error}
            </div>
          </div>
        ) : profile ? (
          <div className="space-y-5 p-4 pb-10 sm:p-6">
            <section className="overflow-hidden rounded-3xl border border-emerald-200 bg-gradient-to-br from-emerald-950 via-emerald-900 to-slate-950 p-5 text-white shadow-lg sm:p-6">
              <div className="flex items-center gap-4">
                <div className="h-20 w-20 shrink-0 overflow-hidden rounded-full border-2 border-white/20 bg-white/10 sm:h-24 sm:w-24">
                  {headshotUrl ? (
                    <img
                      src={
                        headshotUrl
                      }
                      alt={
                        player?.name ??
                        row.player_name
                      }
                      className="h-full w-full object-cover"
                    />
                  ) : (
                    <div className="flex h-full w-full items-center justify-center text-3xl">
                      ⛳
                    </div>
                  )}
                </div>

                <div className="min-w-0 flex-1">
                  <div className="text-xs font-bold uppercase tracking-[0.2em] text-emerald-300">
                    {season ===
                    "all"
                      ? "All-Time"
                      : `${season} Season`}
                  </div>

                  <h2 className="mt-1 truncate text-2xl font-black sm:text-3xl">
                    {player?.name ??
                      row.player_name}
                  </h2>

                  <div className="mt-2 flex flex-wrap gap-x-4 gap-y-1 text-sm text-emerald-100">
                    {player?.country ? (
                      <span>
                        {
                          player.country
                        }
                      </span>
                    ) : null}

                    {player?.owgrRank ? (
                      <span>
                        OWGR #
                        {
                          player.owgrRank
                        }
                      </span>
                    ) : null}

                    <span>
                      Drafted{" "}
                      {
                        summary?.timesDrafted ??
                        row.times_drafted
                      }
                      x
                    </span>
                  </div>
                </div>
              </div>
            </section>

            <section>
              <div className="mb-3">
                <div className="text-xs font-black uppercase tracking-[0.18em] text-slate-500">
                  League Impact
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
                <GolfStatCard
                  label="Wins"
                  value={
                    summary?.wins ??
                    0
                  }
                  detail="Team won when drafted"
                />

                <GolfStatCard
                  label="Podiums"
                  value={
                    summary?.podiums ??
                    0
                  }
                  detail="Top-3 team finishes"
                />

                <GolfStatCard
                  label="Avg Finish"
                  value={
                    summary?.averageFinish ===
                    null
                      ? "—"
                      : ordinal(
                          Math.round(
                            Number(
                              summary?.averageFinish ??
                                0,
                            ),
                          ),
                        )
                  }
                  detail={
                    summary?.averageFinish !==
                    null
                      ? `Exact: ${fmt(
                          summary?.averageFinish,
                          1,
                        )}`
                      : "Finalized tournaments"
                  }
                />

                <GolfStatCard
                  label="Win Rate"
                  value={
                    summary?.winRate ===
                    null
                      ? "—"
                      : `${fmt(
                          summary?.winRate,
                          0,
                        )}%`
                  }
                  detail="Finalized tournaments"
                />
              </div>
            </section>

            <section>
              <div className="mb-3 text-xs font-black uppercase tracking-[0.18em] text-slate-500">
                Golfer Performance
              </div>

              <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
                <GolfStatCard
                  label="Avg Score"
                  value={
                    golfScore(
                      summary?.averageFantasyPoints,
                    )
                  }
                  detail="When drafted"
                />

                <GolfStatCard
                  label="Best Score"
                  value={
                    golfScore(
                      summary?.bestFantasyPoints,
                    )
                  }
                  detail="Lowest tournament score"
                />

                <GolfStatCard
                  label="Cuts Made"
                  value={
                    cutDisplay(
                      summary?.cutsMade,
                      summary?.cutOpportunities,
                    )
                  }
                  detail={
                    summary?.cutsMadePct ===
                    null ||
                    summary?.cutsMadePct ===
                    undefined
                      ? "No cut decisions yet"
                      : `${fmt(
                          summary.cutsMadePct,
                          0,
                        )}%`
                  }
                />

                <GolfStatCard
                  label="Rounds Under Par"
                  value={
                    `${summary?.roundsUnderPar ?? 0}/${summary?.completedRounds ?? 0}`
                  }
                  detail="Completed rounds"
                />
              </div>
            </section>

            <section className="rounded-3xl border border-slate-200 bg-white p-5 shadow-sm">
              <div>
                <div className="text-xs font-black uppercase tracking-[0.18em] text-slate-500">
                  Scoring Breakdown
                </div>

                <div className="mt-1 text-sm text-slate-500">
                  Hole results across tournaments where this golfer was drafted.
                </div>
              </div>

              <div className="mt-4 grid grid-cols-4 gap-2 text-center sm:grid-cols-8">
                {[
                  [
                    "Birdies",
                    summary?.birdies ??
                      0,
                  ],
                  [
                    "Eagles",
                    summary?.eagles ??
                      0,
                  ],
                  [
                    "Albatross",
                    summary?.albatrosses ??
                      0,
                  ],
                  [
                    "Aces",
                    summary?.holesInOne ??
                      0,
                  ],
                  [
                    "Pars",
                    summary?.pars ??
                      0,
                  ],
                  [
                    "Bogeys",
                    summary?.bogeys ??
                      0,
                  ],
                  [
                    "Double+",
                    summary?.doubleBogeysOrWorse ??
                      0,
                  ],
                  [
                    "Under Par",
                    summary?.roundsUnderPar ??
                      0,
                  ],
                ].map(
                  (
                    [
                      label,
                      value,
                    ],
                  ) => (
                    <div
                      key={
                        String(
                          label,
                        )
                      }
                      className="rounded-2xl bg-slate-50 px-2 py-3"
                    >
                      <div className="text-xl font-black text-slate-900">
                        {
                          value
                        }
                      </div>

                      <div className="mt-1 text-[10px] font-bold uppercase tracking-wide text-slate-500">
                        {
                          label
                        }
                      </div>
                    </div>
                  ),
                )}
              </div>
            </section>

            <section className="rounded-3xl border border-slate-200 bg-white p-5 shadow-sm">
              <div className="flex items-end justify-between gap-3">
                <div>
                  <div className="text-xs font-black uppercase tracking-[0.18em] text-slate-500">
                    Drafted By
                  </div>

                  <div className="mt-1 text-sm text-slate-500">
                    League ownership history.
                  </div>
                </div>

                {summary?.draftedMostBy ? (
                  <div className="text-right text-xs text-slate-500">
                    Most:{" "}
                    <strong className="text-slate-900">
                      {
                        summary.draftedMostBy.teamName
                      }
                    </strong>
                  </div>
                ) : null}
              </div>

              <div className="mt-4 flex flex-wrap gap-2">
                {summary?.draftedByBreakdown?.length ? (
                  summary.draftedByBreakdown.map(
                    (
                      owner,
                    ) => (
                      <div
                        key={
                          owner.teamName
                        }
                        className="rounded-full border border-emerald-200 bg-emerald-50 px-3 py-2 text-sm font-semibold text-emerald-900"
                      >
                        {
                          owner.teamName
                        }{" "}
                        ·{" "}
                        {
                          owner.count
                        }
                        x
                      </div>
                    ),
                  )
                ) : (
                  <div className="text-sm text-slate-500">
                    No draft history yet.
                  </div>
                )}
              </div>
            </section>

            <section className="rounded-3xl border border-slate-200 bg-white p-5 shadow-sm">
              <div>
                <div className="text-xs font-black uppercase tracking-[0.18em] text-slate-500">
                  Tournament History
                </div>

                <div className="mt-1 text-sm text-slate-500">
                  Most recent tournaments where this golfer was drafted.
                </div>
              </div>

              <div className="mt-4 space-y-3">
                {profile.recentHistory.length ===
                0 ? (
                  <div className="rounded-2xl border border-dashed border-slate-300 px-4 py-8 text-center text-sm text-slate-500">
                    No tournament history yet.
                  </div>
                ) : (
                  profile.recentHistory.map(
                    (
                      history,
                    ) => {
                      const stats =
                        history.stats;

                      const isFinal =
                        history.finishPosition !==
                        null;

                      const status =
                        String(
                          history.status ??
                            "",
                        ).toLowerCase();

                      const isCut =
                        history.madeCut ===
                          false ||
                        status ===
                          "cut";

                      return (
                        <div
                          key={`${history.slateId}-${history.teamName}`}
                          className="rounded-2xl border border-slate-200 bg-slate-50 p-4"
                        >
                          <div className="flex items-start justify-between gap-4">
                            <div className="min-w-0">
                              <div className="truncate font-bold text-slate-950">
                                {
                                  history.slateLabel
                                }
                              </div>

                              <div className="mt-1 text-xs text-slate-500">
                                Drafted by{" "}
                                <strong>
                                  {
                                    history.teamName
                                  }
                                </strong>
                              </div>
                            </div>

                            <div className="shrink-0 text-right">
                              <div className="text-xl font-black text-slate-950">
                                {golfScore(
                                  history.golferScore ??
                                    history.fantasyPoints,
                                )}
                              </div>

                              <div className="mt-1 text-xs font-bold">
                                {isFinal ? (
                                  <span className="text-slate-700">
                                    Team{" "}
                                    {ordinal(
                                      history.finishPosition,
                                    )}
                                  </span>
                                ) : isCut ? (
                                  <span className="text-red-600">
                                    CUT
                                  </span>
                                ) : (
                                  <span className="text-emerald-700">
                                    LIVE
                                  </span>
                                )}
                              </div>
                            </div>
                          </div>

                          {stats ? (
                            <div className="mt-3 flex flex-wrap gap-x-3 gap-y-1 border-t border-slate-200 pt-3 text-xs text-slate-500">
                              <span>
                                {
                                  stats.birdies ??
                                  0
                                }{" "}
                                birdies
                              </span>

                              <span>
                                {
                                  stats.eagles ??
                                  0
                                }{" "}
                                eagles
                              </span>

                              {(stats.albatrosses ??
                                0) >
                              0 ? (
                                <span className="font-bold text-violet-700">
                                  {
                                    stats.albatrosses
                                  }{" "}
                                  albatross
                                </span>
                              ) : null}

                              {(stats.holesInOne ??
                                0) >
                              0 ? (
                                <span className="font-bold text-amber-700">
                                  {
                                    stats.holesInOne
                                  }{" "}
                                  ace
                                </span>
                              ) : null}

                              <span>
                                {
                                  stats.bogeys ??
                                  0
                                }{" "}
                                bogeys
                              </span>

                              <span>
                                {
                                  stats.roundsUnderPar ??
                                  0
                                }{" "}
                                rounds under par
                              </span>
                            </div>
                          ) : null}
                        </div>
                      );
                    },
                  )
                )}
              </div>
            </section>
          </div>
        ) : null}
      </div>
    </div>
  );
}

function PlayerCompareModal({
  rows,
  sport,
  historyMode,
  onClose,
}: {
  rows:
    PlayerHistoryRow[];
  sport:
    "nba" | "nfl" | "golf";
  historyMode:
    HistoryMode;
  onClose: () => void;
}) {
  if (
    rows.length < 2
  ) {
    return null;
  }

  const isGolf =
    sport === "golf";

  const isGolfSeason =
    sport ===
      "golf" &&
    historyMode ===
      "season";

  const isNbaSeason =
    sport ===
      "nba" &&
    historyMode ===
      "season";

  const isNflSeason =
    sport ===
      "nfl" &&
    historyMode ===
      "season";

  const nflCompareHasQuarterback =
    isNflSeason &&
    rows.some(
      (row) =>
        String(
          row.position_group ??
            "",
        ).toUpperCase() ===
        "QB",
    );

  type CompareMetric = {
    label: string;
    value:
      (
        row:
          PlayerHistoryRow,
      ) =>
        number | null;
    display:
      (
        row:
          PlayerHistoryRow,
      ) =>
        string;
    better:
      "high" | "low";
  };

  const metrics:
    CompareMetric[] =
    isGolfSeason
      ? [
          {
            label:
              "Scoring Avg",
            value:
              (row) =>
                row.golf_season_scoring_average ??
                null,
            display:
              (row) =>
                fmt(
                  row.golf_season_scoring_average,
                  2,
                ),
            better:
              "low",
          },
          {
            label:
              "Cuts",
            value:
              (row) =>
                row.golf_season_cuts_made_pct ??
                null,
            display:
              (row) =>
                row.golf_season_cuts_made_pct ===
                  null ||
                row.golf_season_cuts_made_pct ===
                  undefined
                  ? "—"
                  : `${row.golf_season_cuts_made ?? 0}/${row.golf_season_tournaments_played ?? 0} · ${fmt(
                      row.golf_season_cuts_made_pct,
                      0,
                    )}%`,
            better:
              "high",
          },
          {
            label:
              "Wins",
            value:
              (row) =>
                row.golf_season_wins ??
                0,
            display:
              (row) =>
                String(
                  row.golf_season_wins ??
                    0,
                ),
            better:
              "high",
          },
          {
            label:
              "Top 5",
            value:
              (row) =>
                row.golf_season_top_5 ??
                0,
            display:
              (row) =>
                String(
                  row.golf_season_top_5 ??
                    0,
                ),
            better:
              "high",
          },
          {
            label:
              "Top 10",
            value:
              (row) =>
                row.golf_season_top_10 ??
                0,
            display:
              (row) =>
                String(
                  row.golf_season_top_10 ??
                    0,
                ),
            better:
              "high",
          },
          {
            label:
              "Birdies/R",
            value:
              (row) =>
                row.golf_season_birdies_per_round ??
                null,
            display:
              (row) =>
                fmt(
                  row.golf_season_birdies_per_round,
                  2,
                ),
            better:
              "high",
          },
          {
            label:
              "Birdie %",
            value:
              (row) =>
                row.golf_season_birdie_rate ??
                null,
            display:
              (row) =>
                row.golf_season_birdie_rate ===
                  null ||
                row.golf_season_birdie_rate ===
                  undefined
                  ? "—"
                  : `${fmt(
                      row.golf_season_birdie_rate,
                      1,
                    )}%`,
            better:
              "high",
          },
          {
            label:
              "Bogey %",
            value:
              (row) =>
                row.golf_season_bogey_rate ??
                null,
            display:
              (row) =>
                row.golf_season_bogey_rate ===
                  null ||
                row.golf_season_bogey_rate ===
                  undefined
                  ? "—"
                  : `${fmt(
                      row.golf_season_bogey_rate,
                      1,
                    )}%`,
            better:
              "low",
          },
          {
            label:
              "GIR",
            value:
              (row) =>
                row.golf_season_gir_pct ??
                null,
            display:
              (row) =>
                row.golf_season_gir_pct ===
                  null ||
                row.golf_season_gir_pct ===
                  undefined
                  ? "—"
                  : `${fmt(
                      row.golf_season_gir_pct,
                      1,
                    )}%`,
            better:
              "high",
          },
          {
            label:
              "Drive Acc",
            value:
              (row) =>
                row.golf_season_driving_accuracy_pct ??
                null,
            display:
              (row) =>
                row.golf_season_driving_accuracy_pct ===
                  null ||
                row.golf_season_driving_accuracy_pct ===
                  undefined
                  ? "—"
                  : `${fmt(
                      row.golf_season_driving_accuracy_pct,
                      1,
                    )}%`,
            better:
              "high",
          },
          {
            label:
              "Drive Dist",
            value:
              (row) =>
                row.golf_season_driving_distance ??
                null,
            display:
              (row) =>
                row.golf_season_driving_distance ===
                  null ||
                row.golf_season_driving_distance ===
                  undefined
                  ? "—"
                  : `${fmt(
                      row.golf_season_driving_distance,
                      1,
                    )} yd`,
            better:
              "high",
          },
          {
            label:
              "Putts/GIR",
            value:
              (row) =>
                row.golf_season_putts_per_gir ??
                null,
            display:
              (row) =>
                fmt(
                  row.golf_season_putts_per_gir,
                  2,
                ),
            better:
              "low",
          },
        ]
      : isNflSeason
      ? [
          {
            label:
              "FP/G",
            value:
              (row) =>
                row.nfl_fantasy_points_per_game ??
                null,
            display:
              (row) =>
                fmt(
                  row.nfl_fantasy_points_per_game,
                  2,
                ),
            better:
              "high",
          },
          ...(nflCompareHasQuarterback
            ? [
                {
                  label:
                    "Pass Yds/G",
                  value:
                    (row: PlayerHistoryRow) =>
                      row.nfl_passing_yards_per_game ??
                      null,
                  display:
                    (row: PlayerHistoryRow) =>
                      fmt(
                        row.nfl_passing_yards_per_game,
                        1,
                      ),
                  better:
                    "high" as const,
                },
                {
                  label:
                    "Pass TD/G",
                  value:
                    (row: PlayerHistoryRow) =>
                      row.nfl_passing_tds_per_game ??
                      null,
                  display:
                    (row: PlayerHistoryRow) =>
                      fmt(
                        row.nfl_passing_tds_per_game,
                        2,
                      ),
                  better:
                    "high" as const,
                },
                {
                  label:
                    "INT/G",
                  value:
                    (row: PlayerHistoryRow) =>
                      row.nfl_passing_ints_per_game ??
                      null,
                  display:
                    (row: PlayerHistoryRow) =>
                      fmt(
                        row.nfl_passing_ints_per_game,
                        2,
                      ),
                  better:
                    "low" as const,
                },
              ]
            : []),
          {
            label:
              "Rush Yds/G",
            value:
              (row) =>
                row.nfl_rushing_yards_per_game ??
                null,
            display:
              (row) =>
                fmt(
                  row.nfl_rushing_yards_per_game,
                  1,
                ),
            better:
              "high",
          },
          {
            label:
              "Rush TD/G",
            value:
              (row) =>
                row.nfl_rushing_tds_per_game ??
                null,
            display:
              (row) =>
                fmt(
                  row.nfl_rushing_tds_per_game,
                  2,
                ),
            better:
              "high",
          },
          {
            label:
              "Targets/G",
            value:
              (row) =>
                row.nfl_receiving_targets_per_game ??
                null,
            display:
              (row) =>
                fmt(
                  row.nfl_receiving_targets_per_game,
                  2,
                ),
            better:
              "high",
          },
          {
            label:
              "REC/G",
            value:
              (row) =>
                row.nfl_receptions_per_game ??
                null,
            display:
              (row) =>
                fmt(
                  row.nfl_receptions_per_game,
                  2,
                ),
            better:
              "high",
          },
          {
            label:
              "Rec Yds/G",
            value:
              (row) =>
                row.nfl_receiving_yards_per_game ??
                null,
            display:
              (row) =>
                fmt(
                  row.nfl_receiving_yards_per_game,
                  1,
                ),
            better:
              "high",
          },
          {
            label:
              "Rec TD/G",
            value:
              (row) =>
                row.nfl_receiving_tds_per_game ??
                null,
            display:
              (row) =>
                fmt(
                  row.nfl_receiving_tds_per_game,
                  2,
                ),
            better:
              "high",
          },
        ]
      : isNbaSeason
      ? [
          {
            label:
              "Fantasy Pts",
            value:
              (row) =>
                row.season_fantasy_points ??
                null,
            display:
              (row) =>
                fmt(
                  row.season_fantasy_points,
                  1,
                ),
            better:
              "high",
          },
          {
            label:
              "Points",
            value:
              (row) =>
                row.season_points ??
                null,
            display:
              (row) =>
                fmt(
                  row.season_points,
                  1,
                ),
            better:
              "high",
          },
          {
            label:
              "Rebounds",
            value:
              (row) =>
                row.season_rebounds ??
                null,
            display:
              (row) =>
                fmt(
                  row.season_rebounds,
                  1,
                ),
            better:
              "high",
          },
          {
            label:
              "Assists",
            value:
              (row) =>
                row.season_assists ??
                null,
            display:
              (row) =>
                fmt(
                  row.season_assists,
                  1,
                ),
            better:
              "high",
          },
          {
            label:
              "Steals",
            value:
              (row) =>
                row.season_steals ??
                null,
            display:
              (row) =>
                fmt(
                  row.season_steals,
                  1,
                ),
            better:
              "high",
          },
          {
            label:
              "Blocks",
            value:
              (row) =>
                row.season_blocks ??
                null,
            display:
              (row) =>
                fmt(
                  row.season_blocks,
                  1,
                ),
            better:
              "high",
          },
          {
            label:
              "Turnovers",
            value:
              (row) =>
                row.season_turnovers ??
                null,
            display:
              (row) =>
                fmt(
                  row.season_turnovers,
                  1,
                ),
            better:
              "low",
          },
        ]
      : isGolf
      ? [
          {
            label:
              "Avg Score",
            value:
              (row) =>
                row.avg_score,
            display:
              (row) =>
                golfScore(
                  row.avg_score,
                ),
            better:
              "low",
          },
          {
            label:
              "Best Score",
            value:
              (row) =>
                row.high_score,
            display:
              (row) =>
                golfScore(
                  row.high_score,
                ),
            better:
              "low",
          },
          {
            label:
              "Times Drafted",
            value:
              (row) =>
                row.times_drafted,
            display:
              (row) =>
                String(
                  row.times_drafted,
                ),
            better:
              "high",
          },
          {
            label:
              "Wins",
            value:
              (row) =>
                row.winning_lineups,
            display:
              (row) =>
                String(
                  row.winning_lineups,
                ),
            better:
              "high",
          },
          {
            label:
              "Podiums",
            value:
              (row) =>
                row.podium_lineups ??
                0,
            display:
              (row) =>
                String(
                  row.podium_lineups ??
                    0,
                ),
            better:
              "high",
          },
          {
            label:
              "Avg Finish",
            value:
              (row) =>
                row.avg_finish,
            display:
              (row) =>
                row.avg_finish ===
                null
                  ? "—"
                  : fmt(
                      row.avg_finish,
                      1,
                    ),
            better:
              "low",
          },
          {
            label:
              "Cuts",
            value:
              (row) =>
                row.cuts_made_pct ??
                null,
            display:
              (row) =>
                row.cut_opportunities
                  ? `${row.cuts_made ?? 0}/${row.cut_opportunities} · ${fmt(
                      row.cuts_made_pct,
                      0,
                    )}%`
                  : "—",
            better:
              "high",
          },
          {
            label:
              "Rounds Under Par",
            value:
              (row) =>
                row.rounds_under_par ??
                0,
            display:
              (row) =>
                `${row.rounds_under_par ?? 0}/${row.completed_rounds ?? 0}`,
            better:
              "high",
          },
          {
            label:
              "Birdies",
            value:
              (row) =>
                row.birdies ??
                0,
            display:
              (row) =>
                String(
                  row.birdies ??
                    0,
                ),
            better:
              "high",
          },
          {
            label:
              "Eagles",
            value:
              (row) =>
                row.eagles ??
                0,
            display:
              (row) =>
                String(
                  row.eagles ??
                    0,
                ),
            better:
              "high",
          },
          {
            label:
              "Albatrosses",
            value:
              (row) =>
                row.albatrosses ??
                0,
            display:
              (row) =>
                String(
                  row.albatrosses ??
                    0,
                ),
            better:
              "high",
          },
          {
            label:
              "Aces",
            value:
              (row) =>
                row.holes_in_one ??
                0,
            display:
              (row) =>
                String(
                  row.holes_in_one ??
                    0,
                ),
            better:
              "high",
          },
          {
            label:
              "Bogeys",
            value:
              (row) =>
                row.bogeys ??
                0,
            display:
              (row) =>
                String(
                  row.bogeys ??
                    0,
                ),
            better:
              "low",
          },
          {
            label:
              "Double+",
            value:
              (row) =>
                row.double_bogeys_or_worse ??
                0,
            display:
              (row) =>
                String(
                  row.double_bogeys_or_worse ??
                    0,
                ),
            better:
              "low",
          },
        ]
      : [
          {
            label:
              "Avg Score",
            value:
              (row) =>
                row.avg_score,
            display:
              (row) =>
                row.avg_score.toFixed(
                  2,
                ),
            better:
              "high",
          },
          {
            label:
              "High Score",
            value:
              (row) =>
                row.high_score,
            display:
              (row) =>
                row.high_score.toFixed(
                  2,
                ),
            better:
              "high",
          },
          {
            label:
              "Low Score",
            value:
              (row) =>
                row.low_score,
            display:
              (row) =>
                row.low_score.toFixed(
                  2,
                ),
            better:
              "high",
          },
          {
            label:
              "Times Drafted",
            value:
              (row) =>
                row.times_drafted,
            display:
              (row) =>
                String(
                  row.times_drafted,
                ),
            better:
              "high",
          },
          {
            label:
              "Wins",
            value:
              (row) =>
                row.winning_lineups,
            display:
              (row) =>
                String(
                  row.winning_lineups,
                ),
            better:
              "high",
          },
          {
            label:
              "Runner-Ups",
            value:
              (row) =>
                row.runner_up_lineups,
            display:
              (row) =>
                String(
                  row.runner_up_lineups,
                ),
            better:
              "high",
          },
          {
            label:
              "Avg Finish",
            value:
              (row) =>
                row.avg_finish,
            display:
              (row) =>
                row.avg_finish ===
                null
                  ? "—"
                  : fmt(
                      row.avg_finish,
                      2,
                    ),
            better:
              "low",
          },
        ];

  function isBest(
    metric:
      CompareMetric,
    row:
      PlayerHistoryRow,
  ) {
    const value =
      metric.value(
        row,
      );

    if (
      value === null ||
      !Number.isFinite(
        Number(value),
      )
    ) {
      return false;
    }

    const validValues =
      rows
        .map(
          (candidate) =>
            metric.value(
              candidate,
            ),
        )
        .filter(
          (
            candidate,
          ): candidate is number =>
            candidate !==
              null &&
            Number.isFinite(
              Number(
                candidate,
              ),
            ),
        );

    if (
      validValues.length ===
      0
    ) {
      return false;
    }

    const best =
      metric.better ===
      "low"
        ? Math.min(
            ...validValues,
          )
        : Math.max(
            ...validValues,
          );

    return (
      Number(value) ===
      best
    );
  }

  return (
    <div
      className="fixed inset-0 z-[12000] flex items-start justify-center bg-slate-950/75 p-0 backdrop-blur-sm sm:items-center sm:p-6"
      onMouseDown={
        (
          event,
        ) => {
          if (
            event.target ===
            event.currentTarget
          ) {
            onClose();
          }
        }
      }
    >
      <div className="h-[100dvh] max-h-[100dvh] w-full overflow-y-auto rounded-none bg-slate-950 shadow-2xl sm:h-auto sm:max-h-[92vh] sm:max-w-5xl sm:rounded-[28px]">
        <div
          className={`sticky top-0 z-20 border-b bg-slate-950/95 px-4 py-4 text-white backdrop-blur sm:px-6 ${
            isGolf
              ? "border-emerald-800/50"
              : "border-sky-800/50"
          }`}
        >
          <div className="flex items-center justify-between gap-4">
            <div>
              <div
                className={`text-xs font-black uppercase tracking-[0.2em] ${
                  isGolf
                    ? "text-emerald-300"
                    : "text-sky-300"
                }`}
              >
                Head-to-Head
              </div>

              <h2 className="mt-1 text-xl font-black text-white">
                Compare{" "}
                {isGolf
                  ? "Golfers"
                  : "Players"}
              </h2>
            </div>

            <button
              type="button"
              onClick={
                onClose
              }
              className="flex h-10 w-10 items-center justify-center rounded-full border border-slate-700 bg-slate-800 text-xl font-bold text-slate-200 hover:bg-slate-700"
              aria-label="Close comparison"
            >
              ×
            </button>
          </div>
        </div>

        <div className="p-4 pb-10 sm:p-6">
          <div
            className="grid gap-3"
            style={{
              gridTemplateColumns:
                `110px repeat(${rows.length}, minmax(0, 1fr))`,
            }}
          >
            <div
              aria-hidden="true"
              className="min-w-0"
            />

            {rows.map(
              (
                row,
              ) => (
                <div
                  key={
                    row.player_id
                  }
                  className={`min-w-0 rounded-2xl border bg-gradient-to-b px-2 py-3 text-center text-white sm:p-4 ${
                    isGolf
                      ? "border-emerald-400/80 from-emerald-950 to-slate-950"
                      : "border-sky-400/80 from-sky-950 to-slate-950"
                  }`}
                >
                  <div className="mx-auto flex h-12 w-12 items-center justify-center overflow-hidden rounded-full bg-white/10 sm:h-16 sm:w-16">
                    {isGolf ? (
                      row.headshot_url ||
                      row.espn_golf_player_id ? (
                        <img
                          src={
                            row.headshot_url ??
                            `https://a.espncdn.com/i/headshots/golf/players/full/${row.espn_golf_player_id}.png`
                          }
                          alt={
                            row.player_name
                          }
                          className="h-full w-full object-cover"
                        />
                      ) : (
                        <span>
                          ⛳
                        </span>
                      )
                    ) : (
                      <PlayerHeadshot
                        nbaPlayerId={
                          row.nba_player_id
                        }
                        nflPlayerId={
                          row.nfl_player_id
                        }
                        playerName={
                          row.player_name
                        }
                        size="md"
                      />
                    )}
                  </div>

                  <div className="mt-2 min-h-[32px] px-1 text-center text-[11px] font-black leading-tight text-white sm:min-h-0 sm:text-sm">
                    {
                      row.player_name
                    }
                  </div>

                  <div
                    className={`mt-1 text-[10px] sm:text-xs ${
                      isGolf
                        ? "text-emerald-200"
                        : "text-sky-200"
                    }`}
                  >
                    {isGolf
                      ? row.owgr_rank
                        ? `OWGR #${row.owgr_rank}`
                        : "OWGR —"
                      : isNbaSeason
                        ? [
                            row.team_abbreviation,
                            row.position_group,
                          ]
                            .filter(
                              Boolean,
                            )
                            .join(" · ") ||
                          "NBA"
                        : `Drafted ${row.times_drafted}x`}
                  </div>
                </div>
              ),
            )}
          </div>

          <div className="mt-5 overflow-hidden rounded-2xl border border-slate-700 bg-slate-900">
            {metrics.map(
              (
                metric,
                metricIndex,
              ) => (
                <div
                  key={
                    metric.label
                  }
                  className={`grid items-stretch ${
                    metricIndex >
                    0
                      ? "border-t border-slate-700"
                      : ""
                  }`}
                  style={{
                    gridTemplateColumns:
                      `110px repeat(${rows.length}, minmax(0, 1fr))`,
                  }}
                >
                  <div className="flex items-center bg-slate-900 px-3 py-3 text-[11px] font-bold uppercase tracking-wide text-slate-400 sm:px-4 sm:text-xs">
                    {
                      metric.label
                    }
                  </div>

                  {rows.map(
                    (
                      row,
                    ) => {
                      const best =
                        isBest(
                          metric,
                          row,
                        );

                      return (
                        <div
                          key={`${metric.label}-${row.player_id}`}
                          className={`flex items-center justify-center border-l border-slate-700 px-1 py-3 text-center text-sm font-black sm:px-3 sm:text-base ${
                            best
                              ? isGolf
                                ? "bg-emerald-950/90 text-emerald-300"
                                : "bg-sky-950/90 text-sky-300"
                              : "bg-slate-900 text-white"
                          }`}
                        >
                          <span>
                            {
                              metric.display(
                                row,
                              )
                            }
                          </span>

                          {best ? (
                            <span
                              className={`ml-1 text-[10px] ${
                                isGolf
                                  ? "text-emerald-300"
                                  : "text-sky-300"
                              }`}
                            >
                              ✓
                            </span>
                          ) : null}
                        </div>
                      );
                    },
                  )}
                </div>
              ),
            )}
          </div>

          <div className="mt-3 text-center text-xs text-slate-400">
            Highlighted values are best among the selected{" "}
            {isGolf
              ? "golfers"
              : "players"}
            .
          </div>
        </div>
      </div>
    </div>
  );
}

export default function PlayerHistoryPage() {
  const {
    selectedSport,
    isHydrated,
  } =
    useSelectedSport();

  const isGolf =
    selectedSport ===
    "golf";

  const [
    playerProjections,
    setPlayerProjections,
  ] =
    useState<
      Record<
        number,
        any
      >
    >({});

  const [
    rows,
    setRows,
  ] =
    useState<
      PlayerHistoryRow[]
    >([]);

  const [
    season,
    setSeason,
  ] =
    useState<
      number | "all"
    >(2026);

  const [
    historyMode,
    setHistoryMode,
  ] =
    useState<HistoryMode>(
      "season",
    );

  const [
    searchTerm,
    setSearchTerm,
  ] =
    useState("");

  const [
    minTimesDrafted,
    setMinTimesDrafted,
  ] =
    useState<number>(
      0,
    );

  const [
    isLoading,
    setIsLoading,
  ] =
    useState(true);

  const [
    message,
    setMessage,
  ] =
    useState("");

  const [
    sortKey,
    setSortKey,
  ] =
    useState<SortKey>(
      "times_drafted",
    );

  const [
    sortDirection,
    setSortDirection,
  ] =
    useState<SortDirection>(
      "desc",
    );

  const [
    profilePlayer,
    setProfilePlayer,
  ] =
    useState<Player | null>(
      null,
    );

  const [
    golfProfileRow,
    setGolfProfileRow,
  ] =
    useState<PlayerHistoryRow | null>(
      null,
    );

  const [
    compareMode,
    setCompareMode,
  ] =
    useState(false);

  const [
    comparePlayerIds,
    setComparePlayerIds,
  ] =
    useState<number[]>(
      [],
    );

  const [
    compareOpen,
    setCompareOpen,
  ] =
    useState(false);

  useEffect(() => {
    if (
      !isHydrated
    ) {
      return;
    }

    void loadPlayerHistory();
  }, [
    isHydrated,
    selectedSport,
    season,
    historyMode,
  ]);

  useEffect(() => {
    setProfilePlayer(
      null,
    );

    setGolfProfileRow(
      null,
    );

    setCompareMode(
      false,
    );

    setComparePlayerIds(
      [],
    );

    setCompareOpen(
      false,
    );

    /*
     * Switching sports should preserve the meaning of the
     * currently selected tab.
     *
     * Previously every sport change reset to times_drafted,
     * which is a League History sort key. Season Stats then
     * had no meaningful numeric sort until the page reloaded.
     */
    if (
      historyMode ===
      "season"
    ) {
      if (
        selectedSport ===
        "golf"
      ) {
        setSortKey(
          "golf_scoring_avg",
        );

        setSortDirection(
          "asc",
        );
      } else if (
        selectedSport ===
        "nfl"
      ) {
        setSortKey(
          "nfl_fp",
        );

        setSortDirection(
          "desc",
        );
      } else {
        setSortKey(
          "season_fantasy_points",
        );

        setSortDirection(
          "desc",
        );
      }
    } else {
      setSortKey(
        "times_drafted",
      );

      setSortDirection(
        "desc",
      );
    }
  }, [
    selectedSport,
    historyMode,
  ]);

  useEffect(() => {
    if (
      !isHydrated
    ) {
      return;
    }

    if (
      selectedSport !==
      "nba"
    ) {
      setPlayerProjections(
        {},
      );

      return;
    }

    async function loadPlayerProjections() {
      try {
        const response =
          await fetch(
            `/api/player-projections?season=${
              season ===
              "all"
                ? 2026
                : season
            }`,
            {
              cache:
                "no-store",
            },
          );

        const result =
          await response.json();

        setPlayerProjections(
          result.projections ??
            {},
        );
      } catch (
        error
      ) {
        console.error(
          error,
        );
      }
    }

    void loadPlayerProjections();
  }, [
    isHydrated,
    selectedSport,
    season,
  ]);

  async function loadPlayerHistory() {
    try {
      setIsLoading(
        true,
      );

      setMessage("");

      const endpoint =
        historyMode ===
        "season"
          ? `/api/player-season-stats?season=${season}&sport=${selectedSport}`
          : `/api/player-history?season=${season}&sport=${selectedSport}`;

      const response =
        await fetch(
          endpoint,
          {
            cache:
              "no-store",
          },
        );

      const result =
        await response.json();

      if (
        !response.ok
      ) {
        setMessage(
          result?.error ??
            (
              historyMode ===
              "season"
                ? "Failed to load season stats."
                : "Failed to load player history."
            ),
        );

        setRows([]);

        return;
      }

      const rawRows =
        historyMode ===
        "season"
          ? (
              result.playerStats ??
              result.playerSeasonStats ??
              result.players ??
              []
            )
          : (
              result.playerHistory ??
              []
            );

      const nextRows:
        PlayerHistoryRow[] =
        historyMode ===
          "season" &&
        selectedSport ===
          "nba"
          ? (
              Array.isArray(
                rawRows,
              )
                ? rawRows
                : []
            ).map(
              (
                row:
                  any,
              ) => {
                const fantasyPoints =
                  Number(
                    row.fantasy_points ??
                      0,
                  );

                return {
                  player_id:
                    Number(
                      row.player_id,
                    ),

                  player_name:
                    String(
                      row.player_name ??
                        "Unknown Player",
                    ),

                  nba_player_id:
                    row.nba_player_id ===
                      null ||
                    row.nba_player_id ===
                      undefined
                      ? null
                      : Number(
                          row.nba_player_id,
                        ),

                  nfl_player_id:
                    null,

                  times_drafted:
                    0,

                  avg_score:
                    fantasyPoints,

                  high_score:
                    fantasyPoints,

                  low_score:
                    fantasyPoints,

                  winning_lineups:
                    0,

                  runner_up_lineups:
                    0,

                  avg_finish:
                    null,

                  position_group:
                    row.position_group ??
                    null,

                  team_abbreviation:
                    row.team_abbreviation ??
                    null,

                  season_games_played:
                    row.games_played ??
                    null,

                  season_fantasy_points:
                    Number(
                      row.fantasy_points ??
                        0,
                    ),

                  season_points:
                    Number(
                      row.points ??
                        0,
                    ),

                  season_rebounds:
                    Number(
                      row.rebounds ??
                        0,
                    ),

                  season_assists:
                    Number(
                      row.assists ??
                        0,
                    ),

                  season_steals:
                    Number(
                      row.steals ??
                        0,
                    ),

                  season_blocks:
                    Number(
                      row.blocks ??
                        0,
                    ),

                  season_turnovers:
                    Number(
                      row.turnovers ??
                        0,
                    ),
                };
              },
            )
          : historyMode ===
                "season" &&
              selectedSport ===
                "nfl"
            ? (
                Array.isArray(
                  rawRows,
                )
                  ? rawRows
                  : []
              ).map(
                (
                  row:
                    any,
                ) => {
                  const fantasyPoints =
                    Number(
                      row.fantasy_points_per_game ??
                        0,
                    );

                  return {
                    player_id:
                      Number(
                        row.player_id,
                      ),

                    player_name:
                      String(
                        row.player_name ??
                          "Unknown Player",
                      ),

                    nba_player_id:
                      null,

                    nfl_player_id:
                      row.nfl_player_id ===
                        null ||
                      row.nfl_player_id ===
                        undefined
                        ? null
                        : Number(
                            row.nfl_player_id,
                          ),

                    times_drafted:
                      0,

                    avg_score:
                      fantasyPoints,

                    high_score:
                      fantasyPoints,

                    low_score:
                      fantasyPoints,

                    winning_lineups:
                      0,

                    runner_up_lineups:
                      0,

                    avg_finish:
                      null,

                    position_group:
                      row.position_group ??
                      row.position ??
                      null,

                    team_abbreviation:
                      row.team_abbreviation ??
                      null,

                    nfl_games_played:
                      Number(
                        row.games_played ??
                          0,
                      ),

                    nfl_fantasy_points_per_game:
                      Number(
                        row.fantasy_points_per_game ??
                          0,
                      ),

                    nfl_passing_yards_per_game:
                      Number(
                        row.passing_yards_per_game ??
                          0,
                      ),

                    nfl_passing_tds_per_game:
                      Number(
                        row.passing_tds_per_game ??
                          0,
                      ),

                    nfl_passing_ints_per_game:
                      Number(
                        row.passing_ints_per_game ??
                          0,
                      ),

                    nfl_rushing_yards_per_game:
                      Number(
                        row.rushing_yards_per_game ??
                          0,
                      ),

                    nfl_rushing_tds_per_game:
                      Number(
                        row.rushing_tds_per_game ??
                          0,
                      ),

                    nfl_receiving_targets_per_game:
                      Number(
                        row.receiving_targets_per_game ??
                          0,
                      ),

                    nfl_receptions_per_game:
                      Number(
                        row.receptions_per_game ??
                          0,
                      ),

                    nfl_receiving_yards_per_game:
                      Number(
                        row.receiving_yards_per_game ??
                          0,
                      ),

                    nfl_receiving_tds_per_game:
                      Number(
                        row.receiving_tds_per_game ??
                          0,
                      ),

                    nfl_fumbles_lost_per_game:
                      Number(
                        row.fumbles_lost_per_game ??
                          0,
                      ),
                  };
                },
              )
            : historyMode ===
                  "season" &&
                selectedSport ===
                  "golf"
              ? (
                  Array.isArray(
                    rawRows,
                  )
                    ? rawRows
                    : []
                ).map(
                  (
                    row:
                      any,
                  ) => ({
                    player_id:
                      Number(
                        row.player_id,
                      ),

                    player_name:
                      String(
                        row.player_name ??
                          "Unknown Golfer",
                      ),

                    nba_player_id:
                      null,

                    nfl_player_id:
                      null,

                    espn_golf_player_id:
                      row.espn_golf_player_id ??
                      null,

                    headshot_url:
                      row.headshot_url ??
                      null,

                    country:
                      row.country ??
                      null,

                    owgr_rank:
                      row.owgr_rank ===
                        null ||
                      row.owgr_rank ===
                        undefined
                        ? null
                        : Number(
                            row.owgr_rank,
                          ),

                    /*
                     * Legacy fields stay structurally valid.
                     * Golf Season Stats UI does not interpret
                     * these as 111 league-history values.
                     */
                    times_drafted:
                      0,

                    avg_score:
                      Number(
                        row.scoring_average ??
                          0,
                      ),

                    high_score:
                      Number(
                        row.scoring_average ??
                          0,
                      ),

                    low_score:
                      Number(
                        row.scoring_average ??
                          0,
                      ),

                    winning_lineups:
                      0,

                    runner_up_lineups:
                      0,

                    podium_lineups:
                      0,

                    avg_finish:
                      null,

                    golf_season_tournaments_played:
                      Number(
                        row.tournaments_played ??
                          0,
                      ),

                    golf_season_rounds_played:
                      Number(
                        row.rounds_played ??
                          0,
                      ),

                    golf_season_cuts_made:
                      Number(
                        row.cuts_made ??
                          0,
                      ),

                    golf_season_cuts_made_pct:
                      row.cuts_made_pct ===
                        null ||
                      row.cuts_made_pct ===
                        undefined
                        ? null
                        : Number(
                            row.cuts_made_pct,
                          ),

                    golf_season_wins:
                      Number(
                        row.wins ??
                          0,
                      ),

                    golf_season_top_5:
                      Number(
                        row.top_5_finishes ??
                          0,
                      ),

                    golf_season_top_10:
                      Number(
                        row.top_10_finishes ??
                          0,
                      ),

                    golf_season_scoring_average:
                      row.scoring_average ===
                        null ||
                      row.scoring_average ===
                        undefined
                        ? null
                        : Number(
                            row.scoring_average,
                          ),

                    golf_season_birdies_per_round:
                      row.birdies_per_round ===
                        null ||
                      row.birdies_per_round ===
                        undefined
                        ? null
                        : Number(
                            row.birdies_per_round,
                          ),

                    golf_season_birdie_rate:
                      row.birdie_rate ===
                        null ||
                      row.birdie_rate ===
                        undefined
                        ? null
                        : Number(
                            row.birdie_rate,
                          ),

                    golf_season_bogey_rate:
                      row.bogey_rate ===
                        null ||
                      row.bogey_rate ===
                        undefined
                        ? null
                        : Number(
                            row.bogey_rate,
                          ),

                    golf_season_gir_pct:
                      row.greens_in_reg_pct ===
                        null ||
                      row.greens_in_reg_pct ===
                        undefined
                        ? null
                        : Number(
                            row.greens_in_reg_pct,
                          ),

                    golf_season_driving_accuracy_pct:
                      row.driving_accuracy_pct ===
                        null ||
                      row.driving_accuracy_pct ===
                        undefined
                        ? null
                        : Number(
                            row.driving_accuracy_pct,
                          ),

                    golf_season_driving_distance:
                      row.driving_distance ===
                        null ||
                      row.driving_distance ===
                        undefined
                        ? null
                        : Number(
                            row.driving_distance,
                          ),

                    golf_season_putts_per_gir:
                      row.putts_per_gir ===
                        null ||
                      row.putts_per_gir ===
                        undefined
                        ? null
                        : Number(
                            row.putts_per_gir,
                          ),

                    golf_season_has_detailed_stats:
                      Boolean(
                        row.has_detailed_stats,
                      ),
                  }),
                )
              : (
                  Array.isArray(
                    rawRows,
                  )
                    ? rawRows
                    : []
                );

      setRows(
        nextRows,
      );
    } catch (
      error
    ) {
      console.error(
        error,
      );

      setRows([]);

      setMessage(
        historyMode ===
        "season"
          ? "Something went wrong while loading season stats."
          : "Something went wrong while loading player history.",
      );
    } finally {
      setIsLoading(
        false,
      );
    }
  }

  function defaultDirection(
    key:
      SortKey,
  ): SortDirection {
    if (
      key ===
      "player_name"
    ) {
      return "asc";
    }

    if (
      isGolf &&
      [
        "avg_score",
        "high_score",
        "low_score",
        "avg_finish",
        "golf_scoring_avg",
        "golf_bogey_rate",
        "golf_putts_gir",
      ].includes(
        key,
      )
    ) {
      return "asc";
    }

    return "desc";
  }

  function handleSort(
    nextKey:
      SortKey,
  ) {
    if (
      sortKey ===
      nextKey
    ) {
      setSortDirection(
        (
          previous,
        ) =>
          previous ===
          "asc"
            ? "desc"
            : "asc",
      );

      return;
    }

    setSortKey(
      nextKey,
    );

    setSortDirection(
      defaultDirection(
        nextKey,
      ),
    );
  }

  const filteredRows =
    useMemo(() => {
      const normalizedSearch =
        searchTerm
          .trim()
          .toLowerCase();

      const filtered =
        rows.filter(
          (row) => {
            const matchesSearch =
              !normalizedSearch ||
              row.player_name
                .toLowerCase()
                .includes(
                  normalizedSearch,
                );

            const matchesMinDrafted =
              historyMode ===
                "season" ||
              row.times_drafted >=
                minTimesDrafted;

            return (
              matchesSearch &&
              matchesMinDrafted
            );
          },
        );

      filtered.sort(
        (a, b) => {
          let comparison =
            0;

          switch (
            sortKey
          ) {
            case "player_name":
              comparison =
                a.player_name.localeCompare(
                  b.player_name,
                );
              break;

            case "times_drafted":
              comparison =
                a.times_drafted -
                b.times_drafted;
              break;

            case "avg_score":
              comparison =
                a.avg_score -
                b.avg_score;
              break;

            case "high_score":
              comparison =
                a.high_score -
                b.high_score;
              break;

            case "low_score":
              comparison =
                a.low_score -
                b.low_score;
              break;

            case "winning_lineups":
              comparison =
                a.winning_lineups -
                b.winning_lineups;
              break;

            case "runner_up_lineups":
              comparison =
                a.runner_up_lineups -
                b.runner_up_lineups;
              break;

            case "podium_lineups":
              comparison =
                (
                  a.podium_lineups ??
                  0
                ) -
                (
                  b.podium_lineups ??
                  0
                );
              break;

            case "avg_finish":
              comparison =
                (
                  a.avg_finish ??
                  999
                ) -
                (
                  b.avg_finish ??
                  999
                );
              break;

            case "cuts_made_pct":
              comparison =
                (
                  a.cuts_made_pct ??
                  -1
                ) -
                (
                  b.cuts_made_pct ??
                  -1
                );
              break;

            case "birdies":
              comparison =
                (
                  a.birdies ??
                  0
                ) -
                (
                  b.birdies ??
                  0
                );
              break;

            case "eagles":
              comparison =
                (
                  a.eagles ??
                  0
                ) -
                (
                  b.eagles ??
                  0
                );
              break;

            case "albatrosses":
              comparison =
                (
                  a.albatrosses ??
                  0
                ) -
                (
                  b.albatrosses ??
                  0
                );
              break;

            case "holes_in_one":
              comparison =
                (
                  a.holes_in_one ??
                  0
                ) -
                (
                  b.holes_in_one ??
                  0
                );
              break;

            case "rounds_under_par":
              comparison =
                (
                  a.rounds_under_par ??
                  0
                ) -
                (
                  b.rounds_under_par ??
                  0
                );
              break;

            case "season_fantasy_points":
              comparison =
                Number(
                  a.season_fantasy_points ??
                  0,
                ) -
                Number(
                  b.season_fantasy_points ??
                  0,
                );
              break;

            case "season_points":
              comparison =
                Number(
                  a.season_points ??
                  0,
                ) -
                Number(
                  b.season_points ??
                  0,
                );
              break;

            case "season_rebounds":
              comparison =
                Number(
                  a.season_rebounds ??
                  0,
                ) -
                Number(
                  b.season_rebounds ??
                  0,
                );
              break;

            case "season_assists":
              comparison =
                Number(
                  a.season_assists ??
                  0,
                ) -
                Number(
                  b.season_assists ??
                  0,
                );
              break;

            case "season_steals":
              comparison =
                Number(
                  a.season_steals ??
                  0,
                ) -
                Number(
                  b.season_steals ??
                  0,
                );
              break;

            case "season_blocks":
              comparison =
                Number(
                  a.season_blocks ??
                  0,
                ) -
                Number(
                  b.season_blocks ??
                  0,
                );
              break;

            case "season_turnovers":
              comparison =
                Number(
                  a.season_turnovers ??
                  0,
                ) -
                Number(
                  b.season_turnovers ??
                  0,
                );
              break;

            case "golf_scoring_avg":
              comparison =
                (
                  a.golf_season_scoring_average ??
                  999
                ) -
                (
                  b.golf_season_scoring_average ??
                  999
                );
              break;

            case "golf_cuts_pct":
              comparison =
                (
                  a.golf_season_cuts_made_pct ??
                  -1
                ) -
                (
                  b.golf_season_cuts_made_pct ??
                  -1
                );
              break;

            case "golf_wins":
              comparison =
                (
                  a.golf_season_wins ??
                  0
                ) -
                (
                  b.golf_season_wins ??
                  0
                );
              break;

            case "golf_top5":
              comparison =
                (
                  a.golf_season_top_5 ??
                  0
                ) -
                (
                  b.golf_season_top_5 ??
                  0
                );
              break;

            case "golf_top10":
              comparison =
                (
                  a.golf_season_top_10 ??
                  0
                ) -
                (
                  b.golf_season_top_10 ??
                  0
                );
              break;

            case "golf_birdies_round":
              comparison =
                (
                  a.golf_season_birdies_per_round ??
                  -1
                ) -
                (
                  b.golf_season_birdies_per_round ??
                  -1
                );
              break;

            case "golf_birdie_rate":
              comparison =
                (
                  a.golf_season_birdie_rate ??
                  -1
                ) -
                (
                  b.golf_season_birdie_rate ??
                  -1
                );
              break;

            case "golf_bogey_rate":
              comparison =
                (
                  a.golf_season_bogey_rate ??
                  999
                ) -
                (
                  b.golf_season_bogey_rate ??
                  999
                );
              break;

            case "golf_gir":
              comparison =
                (
                  a.golf_season_gir_pct ??
                  -1
                ) -
                (
                  b.golf_season_gir_pct ??
                  -1
                );
              break;

            case "golf_drive_acc":
              comparison =
                (
                  a.golf_season_driving_accuracy_pct ??
                  -1
                ) -
                (
                  b.golf_season_driving_accuracy_pct ??
                  -1
                );
              break;

            case "golf_drive_dist":
              comparison =
                (
                  a.golf_season_driving_distance ??
                  -1
                ) -
                (
                  b.golf_season_driving_distance ??
                  -1
                );
              break;

            case "golf_putts_gir":
              comparison =
                (
                  a.golf_season_putts_per_gir ??
                  999
                ) -
                (
                  b.golf_season_putts_per_gir ??
                  999
                );
              break;

            case "golf_events":
              comparison =
                (
                  a.golf_season_tournaments_played ??
                  0
                ) -
                (
                  b.golf_season_tournaments_played ??
                  0
                );
              break;

            case "nfl_fp":
              comparison =
                (
                  a.nfl_fantasy_points_per_game ??
                  0
                ) -
                (
                  b.nfl_fantasy_points_per_game ??
                  0
                );
              break;

            case "nfl_pass_yd":
              comparison =
                (
                  a.nfl_passing_yards_per_game ??
                  0
                ) -
                (
                  b.nfl_passing_yards_per_game ??
                  0
                );
              break;

            case "nfl_pass_td":
              comparison =
                (
                  a.nfl_passing_tds_per_game ??
                  0
                ) -
                (
                  b.nfl_passing_tds_per_game ??
                  0
                );
              break;

            case "nfl_int":
              comparison =
                (
                  a.nfl_passing_ints_per_game ??
                  0
                ) -
                (
                  b.nfl_passing_ints_per_game ??
                  0
                );
              break;

            case "nfl_rush_yd":
              comparison =
                (
                  a.nfl_rushing_yards_per_game ??
                  0
                ) -
                (
                  b.nfl_rushing_yards_per_game ??
                  0
                );
              break;

            case "nfl_rush_td":
              comparison =
                (
                  a.nfl_rushing_tds_per_game ??
                  0
                ) -
                (
                  b.nfl_rushing_tds_per_game ??
                  0
                );
              break;

            case "nfl_targets":
              comparison =
                (
                  a.nfl_receiving_targets_per_game ??
                  0
                ) -
                (
                  b.nfl_receiving_targets_per_game ??
                  0
                );
              break;

            case "nfl_receptions":
              comparison =
                (
                  a.nfl_receptions_per_game ??
                  0
                ) -
                (
                  b.nfl_receptions_per_game ??
                  0
                );
              break;

            case "nfl_rec_yd":
              comparison =
                (
                  a.nfl_receiving_yards_per_game ??
                  0
                ) -
                (
                  b.nfl_receiving_yards_per_game ??
                  0
                );
              break;

            case "nfl_rec_td":
              comparison =
                (
                  a.nfl_receiving_tds_per_game ??
                  0
                ) -
                (
                  b.nfl_receiving_tds_per_game ??
                  0
                );
              break;
          }

          if (
            comparison ===
            0
          ) {
            comparison =
              a.player_name.localeCompare(
                b.player_name,
              );
          }

          return (
            sortDirection ===
            "asc"
              ? comparison
              : -comparison
          );
        },
      );

      return filtered;
    }, [
      rows,
      searchTerm,
      minTimesDrafted,
      sortKey,
      sortDirection,
    ]);

  const playerAverageMap =
    useMemo(() => {
      const map =
        new Map<
          number,
          number
        >();

      rows.forEach(
        (row) => {
          map.set(
            row.player_id,
            row.avg_score,
          );
        },
      );

      return map;
    }, [
      rows,
    ]);

  function sortIndicator(
    key:
      SortKey,
  ) {
    if (
      sortKey !==
      key
    ) {
      return "";
    }

    return (
      sortDirection ===
      "asc"
        ? " ↑"
        : " ↓"
    );
  }

  function headerButton(
    label:
      string,
    key:
      SortKey,
  ) {
    return (
      <button
        type="button"
        onClick={() =>
          handleSort(
            key,
          )
        }
        className="whitespace-nowrap text-left font-semibold transition hover:text-emerald-700"
      >
        {label}
        {sortIndicator(
          key,
        )}
      </button>
    );
  }

  const compareRows =
    useMemo(
      () =>
        comparePlayerIds
          .map(
            (playerId) =>
              rows.find(
                (row) =>
                  row.player_id ===
                  playerId,
              ),
          )
          .filter(
            (
              row,
            ): row is PlayerHistoryRow =>
              Boolean(
                row,
              ),
          ),
      [
        comparePlayerIds,
        rows,
      ],
    );

  function toggleComparePlayer(
    row:
      PlayerHistoryRow,
  ) {
    setComparePlayerIds(
      (
        previous,
      ) => {
        if (
          previous.includes(
            row.player_id,
          )
        ) {
          return previous.filter(
            (playerId) =>
              playerId !==
              row.player_id,
          );
        }

        if (
          previous.length >=
          3
        ) {
          return previous;
        }

        return [
          ...previous,
          row.player_id,
        ];
      },
    );
  }

  function handlePlayerHistoryRowClick(
    row:
      PlayerHistoryRow,
  ) {
    if (
      compareMode
    ) {
      toggleComparePlayer(
        row,
      );

      return;
    }

    openPlayerProfile(
      row,
    );
  }

  function cancelCompareMode() {
    setCompareMode(
      false,
    );

    setComparePlayerIds(
      [],
    );

    setCompareOpen(
      false,
    );
  }

  function isCompareSelected(
    row:
      PlayerHistoryRow,
  ) {
    return comparePlayerIds.includes(
      row.player_id,
    );
  }

  function isVisibleSortSlotActive(
    slot:
      | "avg"
      | "best"
      | "wins"
      | "cuts"
      | "dynamic",
  ) {
    if (
      slot ===
      "avg"
    ) {
      return (
        sortKey ===
        "avg_score"
      );
    }

    if (
      slot ===
      "best"
    ) {
      return (
        sortKey ===
        "high_score"
      );
    }

    if (
      slot ===
      "wins"
    ) {
      return (
        sortKey ===
        "winning_lineups"
      );
    }

    if (
      slot ===
      "cuts"
    ) {
      return (
        sortKey ===
        "cuts_made_pct"
      );
    }

    return ![
      "avg_score",
      "high_score",
      "winning_lineups",
      "cuts_made_pct",
      "player_name",
    ].includes(
      sortKey,
    );
  }

  function getGolfMobileDynamicStat(
    row:
      PlayerHistoryRow,
  ) {
    switch (
      sortKey
    ) {
      case "times_drafted":
        return {
          value:
            row.times_drafted,
          label:
            "Drafted",
        };

      case "podium_lineups":
        return {
          value:
            row.podium_lineups ??
            0,
          label:
            (
              row.podium_lineups ??
              0
            ) === 1
              ? "Podium"
              : "Podiums",
        };

      case "avg_finish":
        return {
          value:
            row.avg_finish ===
            null
              ? "—"
              : fmt(
                  row.avg_finish,
                  1,
                ),
          label:
            "Avg Finish",
        };

      case "cuts_made_pct":
        return {
          value:
            row.cuts_made_pct ===
              null ||
            row.cuts_made_pct ===
              undefined
              ? "—"
              : `${fmt(
                  row.cuts_made_pct,
                  0,
                )}%`,
          label:
            "Cuts",
        };

      case "birdies":
        return {
          value:
            row.birdies ??
            0,
          label:
            "Birdies",
        };

      case "eagles":
        return {
          value:
            row.eagles ??
            0,
          label:
            (
              row.eagles ??
              0
            ) === 1
              ? "Eagle"
              : "Eagles",
        };

      case "albatrosses":
        return {
          value:
            row.albatrosses ??
            0,
          label:
            (
              row.albatrosses ??
              0
            ) === 1
              ? "Albatross"
              : "Albatrosses",
        };

      case "holes_in_one":
        return {
          value:
            row.holes_in_one ??
            0,
          label:
            (
              row.holes_in_one ??
              0
            ) === 1
              ? "Ace"
              : "Aces",
        };

      case "rounds_under_par":
        return {
          value:
            row.rounds_under_par ??
            0,
          label:
            "Rds Under",
        };

      /*
       * Avg Score is already prominent in the upper-right.
       * Best Score and Wins already have permanent slots.
       * Name sorting also does not need a duplicate metric.
       */
      case "avg_score":
      case "high_score":
      case "winning_lineups":
      case "player_name":
      default:
        return {
          value:
            row.times_drafted,
          label:
            "Drafted",
        };
    }
  }

  function openPlayerProfile(
    row:
      PlayerHistoryRow,
  ) {
    if (
      isGolf
    ) {
      setGolfProfileRow(
        row,
      );

      return;
    }

    setProfilePlayer({
      id:
        row.player_id,
      name:
        row.player_name,
      nba_player_id:
        row.nba_player_id,
      nfl_player_id:
        row.nfl_player_id,
      position_group:
        row.position_group ??
        "",
      is_active:
        true,
      is_playing_today:
        null,
    });
  }

  return (
    <main className="min-h-screen bg-slate-50 px-3 py-5 pb-24 text-slate-900 sm:px-4 sm:py-6 sm:pb-6">
      <div className="mx-auto max-w-7xl space-y-6">
        <AppNav />

        <section
          className={`rounded-3xl border px-5 py-6 shadow-sm ${
            isGolf
              ? "border-emerald-200 bg-gradient-to-br from-emerald-950 via-emerald-900 to-slate-950 text-white"
              : "border-slate-200 bg-white"
          }`}
        >
          <div className="flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
            <div>
              <p
                className={`text-sm font-bold uppercase tracking-[0.18em] ${
                  isGolf
                    ? "text-emerald-300"
                    : "text-sky-700"
                }`}
              >
                {isGolf
                  ? "Golfer History"
                  : "Player History"}
              </p>

              <h1 className="mt-2 text-3xl font-black tracking-tight">
                {isGolf
                  ? "Golfer Stats"
                  : "Player Stats"}
              </h1>

              <p
                className={`mt-2 max-w-2xl text-sm ${
                  isGolf
                    ? "text-emerald-100"
                    : "text-slate-600"
                }`}
              >
                {isGolf
                  ? "Career performance, league impact, cuts, and scoring history for every drafted golfer."
                  : "Explore past performance and trends for all players."}
              </p>
            </div>

          </div>
        </section>

        <section className="rounded-3xl border border-slate-200 bg-white p-5 shadow-sm">
          <div className="space-y-3">
            <div
              className="grid grid-cols-2 gap-2 rounded-2xl bg-slate-100 p-1"
              aria-label="Player stats mode"
            >
              <button
                type="button"
                onClick={() => {
                  setHistoryMode(
                    "league",
                  );

                  setSortKey(
                    "times_drafted",
                  );

                  setSortDirection(
                    "desc",
                  );
                }}
                className={`rounded-xl px-3 py-2.5 text-sm font-bold transition ${
                  historyMode ===
                  "league"
                    ? isGolf
                      ? "bg-emerald-700 text-white shadow-sm"
                      : "bg-sky-700 text-white shadow-sm"
                    : "text-slate-600 hover:bg-white/70"
                }`}
              >
                League History
              </button>

              <button
                type="button"
                onClick={() => {
                  setHistoryMode(
                    "season",
                  );

                  if (
                    season ===
                    "all"
                  ) {
                    setSeason(
                      2026,
                    );
                  }

                  setMinTimesDrafted(
                    0,
                  );

                  setSortKey(
                    selectedSport ===
                      "golf"
                      ? "golf_scoring_avg"
                      : selectedSport ===
                          "nfl"
                        ? "nfl_fp"
                        : "season_fantasy_points",
                  );

                  setSortDirection(
                    selectedSport ===
                      "golf"
                      ? "asc"
                      : "desc",
                  );
                }}
                className={`rounded-xl px-3 py-2.5 text-sm font-bold transition ${
                  historyMode ===
                  "season"
                    ? isGolf
                      ? "bg-emerald-700 text-white shadow-sm"
                      : "bg-sky-700 text-white shadow-sm"
                    : "text-slate-600 hover:bg-white/70"
                }`}
              >
                Season Stats
              </button>
            </div>

            <div>
              <label
                htmlFor="player-search"
                className="mb-2 block text-sm font-medium text-slate-700"
              >
                Search{" "}
                {isGolf
                  ? "golfers"
                  : "players"}
              </label>

              <input
                id="player-search"
                type="text"
                value={
                  searchTerm
                }
                onChange={
                  (
                    event,
                  ) =>
                    setSearchTerm(
                      event.target.value,
                    )
                }
                placeholder={
                  isGolf
                    ? "Search by golfer name"
                    : "Search by player name"
                }
                className="w-full rounded-xl border border-slate-200 bg-white px-3 py-3 text-sm text-slate-900 outline-none transition focus:border-emerald-300"
              />
            </div>

            <div
              className={`grid gap-3 ${
                historyMode ===
                "league"
                  ? "grid-cols-2"
                  : "grid-cols-1"
              }`}
            >
              {historyMode ===
              "league" ? (
                <div>
                  <label
                    htmlFor="min-times-drafted"
                    className="mb-2 block text-sm font-medium text-slate-700"
                  >
                    Min Drafted
                  </label>

                  <select
                    id="min-times-drafted"
                    value={
                      minTimesDrafted
                    }
                    onChange={
                      (
                        event,
                      ) =>
                        setMinTimesDrafted(
                          Number(
                            event.target.value,
                          ),
                        )
                    }
                    className="w-full rounded-xl border border-slate-200 bg-white px-3 py-3 text-sm text-slate-900 outline-none transition focus:border-emerald-300"
                  >
                    <option value={0}>
                      Any
                    </option>
                    <option value={2}>
                      2+
                    </option>
                    <option value={3}>
                      3+
                    </option>
                    <option value={5}>
                      5+
                    </option>
                    <option value={10}>
                      10+
                    </option>
                    <option value={15}>
                      15+
                    </option>
                  </select>
                </div>
              ) : null}

              <div>
                <label
                  htmlFor="season-select"
                  className="mb-2 block text-sm font-medium text-slate-700"
                >
                  Season
                </label>

                <select
                  id="season-select"
                  value={
                    season
                  }
                  onChange={
                    (
                      event,
                    ) =>
                      setSeason(
                        event.target.value ===
                          "all"
                          ? "all"
                          : Number(
                              event.target.value,
                            ),
                      )
                  }
                  className="w-full rounded-xl border border-slate-200 bg-white px-3 py-3 text-sm text-slate-900 outline-none transition focus:border-emerald-300"
                >
                  {historyMode ===
                  "league" ? (
                    <option value="all">
                      All-Time
                    </option>
                  ) : null}

                  {[
                    2026,
                    2025,
                    2024,
                    2023,
                  ].map(
                    (
                      year,
                    ) => (
                      <option
                        key={
                          year
                        }
                        value={
                          year
                        }
                      >
                        {
                          year
                        }
                      </option>
                    ),
                  )}
                </select>
              </div>
            </div>
          </div>

          {message ? (
            <div className="mt-4 rounded-2xl border border-orange-200 bg-orange-50 px-4 py-3 text-sm text-orange-800">
              {message}
            </div>
          ) : null}
        </section>

        <section className="rounded-3xl border border-slate-200 bg-white p-4 shadow-sm sm:p-5">
          {!isLoading ? (
            <div className="mb-3 text-sm text-slate-500">
              Showing{" "}
              {
                filteredRows.length
              }{" "}
              of{" "}
              {
                rows.length
              }{" "}
              {isGolf
                ? "golfers"
                : "players"}
              {historyMode ===
                "league" &&
              minTimesDrafted >
                0
                ? ` with ${minTimesDrafted}+ drafts`
                : ""}
              .
            </div>
          ) : null}

          {!isLoading &&
          filteredRows.length >
            0 &&
          compareMode ? (
            <div className="mb-4 rounded-2xl border border-emerald-700/50 bg-slate-900/80 p-3">
              {!compareMode ? (
                <button
                  type="button"
                  onClick={() => {
                    setCompareMode(
                      true,
                    );

                    setComparePlayerIds(
                      [],
                    );
                  }}
                  className={`w-full rounded-xl border bg-white px-4 py-3 text-sm font-black transition sm:w-auto ${
                    isGolf
                      ? "border-emerald-300 text-emerald-800 hover:bg-emerald-50"
                      : "border-sky-300 text-sky-800 hover:bg-sky-50"
                  }`}
                >
                  ⇄ Compare{" "}
                  {isGolf
                    ? "Golfers"
                    : "Players"}
                </button>
              ) : (
                <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
                  <div>
                    <div className="font-black text-white">
                      Select 2–3{" "}
                      {isGolf
                        ? "golfers"
                        : "players"}
                    </div>

                    <div className="mt-0.5 text-xs text-emerald-300">
                      Tap a{" "}
                      {isGolf
                        ? "golfer"
                        : "player"}{" "}
                      to add or remove them.
                      {" "}
                      {
                        comparePlayerIds.length
                      }
                      /3 selected
                    </div>
                  </div>

                  <div className="flex gap-2">
                    <button
                      type="button"
                      onClick={
                        cancelCompareMode
                      }
                      className="rounded-xl border border-slate-600 bg-slate-800 px-4 py-2 text-sm font-bold text-slate-200 hover:bg-slate-700 sm:px-4 sm:py-2.5"
                    >
                      Cancel
                    </button>

                    <button
                      type="button"
                      disabled={
                        comparePlayerIds.length <
                        2
                      }
                      onClick={() =>
                        setCompareOpen(
                          true,
                        )
                      }
                      className="rounded-xl bg-emerald-700 px-4 py-2 text-sm font-black text-white transition enabled:hover:bg-emerald-800 disabled:cursor-not-allowed disabled:opacity-40 sm:px-4 sm:py-2.5"
                    >
                      Compare (
                      {
                        comparePlayerIds.length
                      }
                      )
                    </button>
                  </div>
                </div>
              )}

              {compareMode &&
              compareRows.length >
                0 ? (
                <div className="mt-3 flex flex-wrap gap-2 border-t border-emerald-800/60 pt-3">
                  {compareRows.map(
                    (
                      row,
                    ) => (
                      <button
                        key={
                          row.player_id
                        }
                        type="button"
                        onClick={() =>
                          toggleComparePlayer(
                            row,
                          )
                        }
                        className="rounded-full bg-emerald-800 px-3 py-1.5 text-xs font-bold text-white"
                      >
                        {
                          row.player_name
                        }{" "}
                        ×
                      </button>
                    ),
                  )}
                </div>
              ) : null}
            </div>
          ) : null}

          {historyMode ===
            "league" &&
          !isGolf &&
          !isLoading &&
          filteredRows.length >
            0 ? (
            <div className="mb-4 flex items-end gap-2 md:hidden">
              <div className="min-w-0 flex-1">
                <label
                  htmlFor="league-mobile-sort"
                  className="mb-2 block text-sm font-medium text-slate-700"
                >
                  Sort by
                </label>

                <select
                  id="league-mobile-sort"
                  value={
                    sortKey
                  }
                  onChange={
                    (
                      event,
                    ) => {
                      const nextKey =
                        event.target.value as SortKey;

                      setSortKey(
                        nextKey,
                      );

                      setSortDirection(
                        defaultDirection(
                          nextKey,
                        ),
                      );
                    }
                  }
                  className={`w-full rounded-xl border border-slate-200 bg-white px-3 py-3 text-sm font-semibold text-slate-900 outline-none transition ${
                    selectedSport ===
                    "nba"
                      ? "focus:border-orange-300"
                      : "focus:border-sky-300"
                  }`}
                >
                  <option value="times_drafted">
                    Times Drafted
                  </option>

                  <option value="avg_score">
                    Avg Score
                  </option>

                  <option value="high_score">
                    Best Score
                  </option>

                  <option value="winning_lineups">
                    Wins
                  </option>

                  <option value="runner_up_lineups">
                    Runner-Ups
                  </option>

                  <option value="avg_finish">
                    Avg Finish
                  </option>

                  <option value="player_name">
                    Player Name
                  </option>
                </select>
              </div>

              <button
                type="button"
                onClick={() =>
                  setSortDirection(
                    (
                      previous,
                    ) =>
                      previous ===
                      "asc"
                        ? "desc"
                        : "asc",
                  )
                }
                className={`flex h-[46px] w-[52px] shrink-0 items-center justify-center rounded-xl border bg-white text-xl font-black ${
                  selectedSport ===
                  "nba"
                    ? "border-orange-200 text-orange-700"
                    : "border-sky-200 text-sky-700"
                }`}
                aria-label="Reverse sort direction"
              >
                {sortDirection ===
                "asc"
                  ? "↑"
                  : "↓"}
              </button>
            </div>
          ) : null}

          {isLoading ? (
            <div className="rounded-xl border border-dashed border-slate-300 px-4 py-6 text-sm text-slate-500">
              Loading{" "}
              {isGolf
                ? "golfer"
                : "player"}{" "}
              {historyMode ===
              "season"
                ? "stats"
                : "history"}
              ...
            </div>
          ) : filteredRows.length ===
            0 ? (
            <div className="rounded-xl border border-dashed border-slate-300 px-4 py-6 text-sm text-slate-500">
              No{" "}
              {isGolf
                ? "golfer"
                : "player"}{" "}
              history found.
            </div>
          ) : historyMode ===
              "season" &&
            selectedSport ===
              "golf" ? (
            <>
              <div className="mb-4 flex items-end gap-2 md:hidden">
                <div className="min-w-0 flex-1">
                  <label
                    htmlFor="golf-season-mobile-sort"
                    className="mb-2 block text-sm font-medium text-slate-700"
                  >
                    Sort by
                  </label>

                  <select
                    id="golf-season-mobile-sort"
                    value={
                      sortKey
                    }
                    onChange={
                      (
                        event,
                      ) => {
                        const nextKey =
                          event.target.value as SortKey;

                        setSortKey(
                          nextKey,
                        );

                        setSortDirection(
                          [
                            "golf_scoring_avg",
                            "golf_bogey_rate",
                            "golf_putts_gir",
                            "player_name",
                          ].includes(
                            nextKey,
                          )
                            ? "asc"
                            : "desc",
                        );
                      }
                    }
                    className="w-full rounded-xl border border-slate-200 bg-white px-3 py-3 text-sm font-semibold text-slate-900 outline-none transition focus:border-emerald-300"
                  >
                    <option value="golf_scoring_avg">
                      Scoring Average
                    </option>

                    <option value="golf_cuts_pct">
                      Cuts Made %
                    </option>

                    <option value="golf_wins">
                      Wins
                    </option>

                    <option value="golf_top5">
                      Top 5s
                    </option>

                    <option value="golf_top10">
                      Top 10s
                    </option>

                    <option value="golf_birdies_round">
                      Birdies / Round
                    </option>

                    <option value="golf_birdie_rate">
                      Birdie %
                    </option>

                    <option value="golf_bogey_rate">
                      Bogey %
                    </option>

                    <option value="golf_gir">
                      GIR %
                    </option>

                    <option value="golf_drive_acc">
                      Driving Accuracy
                    </option>

                    <option value="golf_drive_dist">
                      Driving Distance
                    </option>

                    <option value="golf_putts_gir">
                      Putts / GIR
                    </option>

                    <option value="golf_events">
                      Events Played
                    </option>

                    <option value="player_name">
                      Golfer Name
                    </option>
                  </select>
                </div>

                <button
                  type="button"
                  onClick={() =>
                    setSortDirection(
                      (
                        previous,
                      ) =>
                        previous ===
                        "asc"
                          ? "desc"
                          : "asc",
                    )
                  }
                  className="flex h-[46px] w-[52px] shrink-0 items-center justify-center rounded-xl border border-slate-200 bg-white text-xl font-black text-emerald-800"
                  aria-label="Reverse sort direction"
                >
                  {sortDirection ===
                  "asc"
                    ? "↑"
                    : "↓"}
                </button>
              </div>

              <div className="space-y-3 md:hidden">
                {filteredRows.map(
                  (
                    row,
                  ) => {
                    const selected =
                      isCompareSelected(
                        row,
                      );

                    const dynamicStat =
                      sortKey ===
                        "golf_wins"
                        ? {
                            label:
                              "WINS",
                            value:
                              String(
                                row.golf_season_wins ??
                                  0,
                              ),
                            key:
                              "golf_wins" as SortKey,
                          }
                        : sortKey ===
                            "golf_top5"
                          ? {
                              label:
                                "TOP 5",
                              value:
                                String(
                                  row.golf_season_top_5 ??
                                    0,
                                ),
                              key:
                                "golf_top5" as SortKey,
                            }
                          : sortKey ===
                              "golf_birdie_rate"
                            ? {
                                label:
                                  "BIRD %",
                                value:
                                  row.golf_season_birdie_rate ===
                                    null ||
                                  row.golf_season_birdie_rate ===
                                    undefined
                                    ? "—"
                                    : `${fmt(
                                        row.golf_season_birdie_rate,
                                        1,
                                      )}%`,
                                key:
                                  "golf_birdie_rate" as SortKey,
                              }
                            : sortKey ===
                                "golf_bogey_rate"
                              ? {
                                  label:
                                    "BOGEY %",
                                  value:
                                    row.golf_season_bogey_rate ===
                                      null ||
                                    row.golf_season_bogey_rate ===
                                      undefined
                                      ? "—"
                                      : `${fmt(
                                          row.golf_season_bogey_rate,
                                          1,
                                        )}%`,
                                  key:
                                    "golf_bogey_rate" as SortKey,
                                }
                              : sortKey ===
                                  "golf_drive_acc"
                                ? {
                                    label:
                                      "DRV ACC",
                                    value:
                                      row.golf_season_driving_accuracy_pct ===
                                        null ||
                                      row.golf_season_driving_accuracy_pct ===
                                        undefined
                                        ? "—"
                                        : `${fmt(
                                            row.golf_season_driving_accuracy_pct,
                                            1,
                                          )}%`,
                                    key:
                                      "golf_drive_acc" as SortKey,
                                  }
                                : sortKey ===
                                    "golf_drive_dist"
                                  ? {
                                      label:
                                        "DRV DIST",
                                      value:
                                        row.golf_season_driving_distance ===
                                          null ||
                                        row.golf_season_driving_distance ===
                                          undefined
                                          ? "—"
                                          : fmt(
                                              row.golf_season_driving_distance,
                                              1,
                                            ),
                                      key:
                                        "golf_drive_dist" as SortKey,
                                    }
                                  : sortKey ===
                                      "golf_putts_gir"
                                    ? {
                                        label:
                                          "PUTTS/GIR",
                                        value:
                                          fmt(
                                            row.golf_season_putts_per_gir,
                                            2,
                                          ),
                                        key:
                                          "golf_putts_gir" as SortKey,
                                      }
                                    : sortKey ===
                                        "golf_events"
                                      ? {
                                          label:
                                            "EVENTS",
                                          value:
                                            String(
                                              row.golf_season_tournaments_played ??
                                                0,
                                            ),
                                          key:
                                            "golf_events" as SortKey,
                                        }
                                      : {
                                          label:
                                            "GIR",
                                          value:
                                            row.golf_season_gir_pct ===
                                              null ||
                                            row.golf_season_gir_pct ===
                                              undefined
                                              ? "—"
                                              : `${fmt(
                                                  row.golf_season_gir_pct,
                                                  1,
                                                )}%`,
                                          key:
                                            "golf_gir" as SortKey,
                                        };

                    const scoringActive =
                      sortKey ===
                      "golf_scoring_avg";

                    const cutsActive =
                      sortKey ===
                      "golf_cuts_pct";

                    const top10Active =
                      sortKey ===
                      "golf_top10";

                    const birdiesActive =
                      sortKey ===
                      "golf_birdies_round";

                    const dynamicActive =
                      dynamicStat.key ===
                      sortKey;

                    return (
                      <button
                        key={
                          row.player_id
                        }
                        type="button"
                        onClick={() =>
                          handlePlayerHistoryRowClick(
                            row,
                          )
                        }
                        className={`relative w-full rounded-2xl border bg-white p-3.5 text-left shadow-sm transition ${
                          selected
                            ? "border-emerald-400 ring-2 ring-emerald-300/50"
                            : "border-slate-200"
                        }`}
                      >
                        {compareMode &&
                        selected ? (
                          <div className="absolute right-3 top-3 flex h-6 w-6 items-center justify-center rounded-full bg-emerald-500 text-xs font-black text-white">
                            ✓
                          </div>
                        ) : null}

                        <div className="flex items-center gap-3">
                          <div className="h-12 w-12 shrink-0 overflow-hidden rounded-full bg-slate-100">
                            {row.headshot_url ||
                            row.espn_golf_player_id ? (
                              <img
                                src={
                                  row.headshot_url ??
                                  `https://a.espncdn.com/i/headshots/golf/players/full/${row.espn_golf_player_id}.png`
                                }
                                alt={
                                  row.player_name
                                }
                                className="h-full w-full object-cover"
                              />
                            ) : (
                              <div className="flex h-full w-full items-center justify-center">
                                ⛳
                              </div>
                            )}
                          </div>

                          <div className="min-w-0 flex-1">
                            <div className="truncate pr-7 font-black text-slate-950">
                              {
                                row.player_name
                              }
                            </div>

                            <div className="mt-0.5 text-xs text-slate-500">
                              {row.owgr_rank
                                ? `OWGR #${row.owgr_rank}`
                                : "OWGR —"}
                              {" · "}
                              {
                                row.golf_season_tournaments_played ??
                                0
                              }{" "}
                              events
                            </div>
                          </div>
                        </div>

                        <div className="mt-3 grid grid-cols-4 gap-1 border-t border-slate-100 pt-2 text-center">
                          {[
                            {
                              label:
                                "AVG",
                              value: fmt(
                                row.golf_season_scoring_average,
                                2,
                              ),
                              active:
                                scoringActive,
                            },
                            {
                              label:
                                "CUTS",
                              value:
                                row.golf_season_cuts_made_pct ===
                                  null ||
                                row.golf_season_cuts_made_pct ===
                                  undefined
                                  ? "—"
                                  : `${fmt(
                                      row.golf_season_cuts_made_pct,
                                      0,
                                    )}%`,
                              active:
                                cutsActive,
                            },
                            {
                              label:
                                "BIRD/R",
                              value: fmt(
                                row.golf_season_birdies_per_round,
                                2,
                              ),
                              active:
                                birdiesActive,
                            },
                            {
                              label:
                                dynamicStat.label,
                              value:
                                dynamicStat.value,
                              active:
                                dynamicActive,
                            },
                          ].map(
                            (
                              stat,
                            ) => (
                              <div
                                key={
                                  stat.label
                                }
                                className={`rounded-lg border px-1 py-1.5 ${
                                  stat.active
                                    ? "border-emerald-400 bg-emerald-50"
                                    : "border-transparent bg-slate-50"
                                }`}
                              >
                                <div
                                  className={`text-[13px] font-black ${
                                    stat.active
                                      ? "text-emerald-700"
                                      : "text-slate-900"
                                  }`}
                                >
                                  {
                                    stat.value
                                  }
                                </div>

                                <div
                                  className={`text-[9px] font-bold uppercase ${
                                    stat.active
                                      ? "text-emerald-700"
                                      : "text-slate-400"
                                  }`}
                                >
                                  {
                                    stat.label
                                  }
                                </div>
                              </div>
                            ),
                          )}
                        </div>
                      </button>
                    );
                  },
                )}
              </div>

              <div className="hidden overflow-x-auto md:block">
                <table className="min-w-[1450px] w-full border-collapse text-sm">
                  <thead className="bg-emerald-950 text-left text-white">
                    <tr>
                      <th className="px-4 py-3">
                        {headerButton(
                          "Golfer",
                          "player_name",
                        )}
                      </th>

                      <th className="px-3 py-3">
                        OWGR
                      </th>

                      <th className="px-3 py-3">
                        {headerButton(
                          "Avg",
                          "golf_scoring_avg",
                        )}
                      </th>

                      <th className="px-3 py-3">
                        {headerButton(
                          "Cuts %",
                          "golf_cuts_pct",
                        )}
                      </th>

                      <th className="px-3 py-3">
                        {headerButton(
                          "Wins",
                          "golf_wins",
                        )}
                      </th>

                      <th className="px-3 py-3">
                        {headerButton(
                          "Top 5",
                          "golf_top5",
                        )}
                      </th>

                      <th className="px-3 py-3">
                        {headerButton(
                          "Top 10",
                          "golf_top10",
                        )}
                      </th>

                      <th className="px-3 py-3">
                        {headerButton(
                          "Bird/R",
                          "golf_birdies_round",
                        )}
                      </th>

                      <th className="px-3 py-3">
                        {headerButton(
                          "Bird %",
                          "golf_birdie_rate",
                        )}
                      </th>

                      <th className="px-3 py-3">
                        {headerButton(
                          "Bogey %",
                          "golf_bogey_rate",
                        )}
                      </th>

                      <th className="px-3 py-3">
                        {headerButton(
                          "GIR %",
                          "golf_gir",
                        )}
                      </th>

                      <th className="px-3 py-3">
                        {headerButton(
                          "Drv Acc",
                          "golf_drive_acc",
                        )}
                      </th>

                      <th className="px-3 py-3">
                        {headerButton(
                          "Drv Dist",
                          "golf_drive_dist",
                        )}
                      </th>

                      <th className="px-3 py-3">
                        {headerButton(
                          "Putts/GIR",
                          "golf_putts_gir",
                        )}
                      </th>
                    </tr>
                  </thead>

                  <tbody>
                    {filteredRows.map(
                      (
                        row,
                      ) => (
                        <tr
                          key={
                            row.player_id
                          }
                          className={`border-t border-slate-100 ${
                            isCompareSelected(
                              row,
                            )
                              ? "bg-emerald-50"
                              : "hover:bg-emerald-50/40"
                          }`}
                        >
                          <td className="px-4 py-3">
                            <button
                              type="button"
                              onClick={() =>
                                handlePlayerHistoryRowClick(
                                  row,
                                )
                              }
                              className="flex items-center gap-2 font-bold text-emerald-800"
                            >
                              <div className="h-8 w-8 overflow-hidden rounded-full bg-slate-100">
                                {row.headshot_url ||
                                row.espn_golf_player_id ? (
                                  <img
                                    src={
                                      row.headshot_url ??
                                      `https://a.espncdn.com/i/headshots/golf/players/full/${row.espn_golf_player_id}.png`
                                    }
                                    alt={
                                      row.player_name
                                    }
                                    className="h-full w-full object-cover"
                                  />
                                ) : (
                                  <div className="flex h-full w-full items-center justify-center">
                                    ⛳
                                  </div>
                                )}
                              </div>

                              {
                                row.player_name
                              }
                            </button>
                          </td>

                          <td className="px-3 py-3">
                            {row.owgr_rank
                              ? `#${row.owgr_rank}`
                              : "—"}
                          </td>

                          <td className="px-3 py-3 font-black">
                            {fmt(
                              row.golf_season_scoring_average,
                              2,
                            )}
                          </td>

                          <td className="px-3 py-3">
                            {row.golf_season_cuts_made_pct ===
                              null ||
                            row.golf_season_cuts_made_pct ===
                              undefined
                              ? "—"
                              : `${fmt(
                                  row.golf_season_cuts_made_pct,
                                  1,
                                )}%`}
                          </td>

                          <td className="px-3 py-3">
                            {
                              row.golf_season_wins ??
                              0
                            }
                          </td>

                          <td className="px-3 py-3">
                            {
                              row.golf_season_top_5 ??
                              0
                            }
                          </td>

                          <td className="px-3 py-3">
                            {
                              row.golf_season_top_10 ??
                              0
                            }
                          </td>

                          <td className="px-3 py-3">
                            {fmt(
                              row.golf_season_birdies_per_round,
                              2,
                            )}
                          </td>

                          <td className="px-3 py-3">
                            {row.golf_season_birdie_rate ===
                              null ||
                            row.golf_season_birdie_rate ===
                              undefined
                              ? "—"
                              : `${fmt(
                                  row.golf_season_birdie_rate,
                                  1,
                                )}%`}
                          </td>

                          <td className="px-3 py-3">
                            {row.golf_season_bogey_rate ===
                              null ||
                            row.golf_season_bogey_rate ===
                              undefined
                              ? "—"
                              : `${fmt(
                                  row.golf_season_bogey_rate,
                                  1,
                                )}%`}
                          </td>

                          <td className="px-3 py-3">
                            {row.golf_season_gir_pct ===
                              null ||
                            row.golf_season_gir_pct ===
                              undefined
                              ? "—"
                              : `${fmt(
                                  row.golf_season_gir_pct,
                                  1,
                                )}%`}
                          </td>

                          <td className="px-3 py-3">
                            {row.golf_season_driving_accuracy_pct ===
                              null ||
                            row.golf_season_driving_accuracy_pct ===
                              undefined
                              ? "—"
                              : `${fmt(
                                  row.golf_season_driving_accuracy_pct,
                                  1,
                                )}%`}
                          </td>

                          <td className="px-3 py-3">
                            {fmt(
                              row.golf_season_driving_distance,
                              1,
                            )}
                          </td>

                          <td className="px-3 py-3">
                            {fmt(
                              row.golf_season_putts_per_gir,
                              2,
                            )}
                          </td>
                        </tr>
                      ),
                    )}
                  </tbody>
                </table>
              </div>
            </>
          ) : historyMode ===
              "season" &&
            selectedSport ===
              "nfl" ? (
            <>
              <div className="mb-4 flex items-end gap-2 md:hidden">
                <div className="min-w-0 flex-1">
                  <label
                    htmlFor="nfl-season-mobile-sort"
                    className="mb-2 block text-sm font-medium text-slate-700"
                  >
                    Sort by
                  </label>

                  <select
                    id="nfl-season-mobile-sort"
                    value={
                      sortKey
                    }
                    onChange={
                      (
                        event,
                      ) => {
                        const nextKey =
                          event.target.value as SortKey;

                        setSortKey(
                          nextKey,
                        );

                        setSortDirection(
                          nextKey ===
                            "nfl_int"
                            ? "asc"
                            : nextKey ===
                                "player_name"
                              ? "asc"
                              : "desc",
                        );
                      }
                    }
                    className="w-full rounded-xl border border-slate-200 bg-white px-3 py-3 text-sm font-semibold text-slate-900 outline-none transition focus:border-sky-300"
                  >
                    <option value="nfl_fp">
                      Fantasy Points / Game
                    </option>

                    <option value="nfl_pass_yd">
                      Pass Yards / Game
                    </option>

                    <option value="nfl_pass_td">
                      Pass TD / Game
                    </option>

                    <option value="nfl_int">
                      INT / Game
                    </option>

                    <option value="nfl_rush_yd">
                      Rush Yards / Game
                    </option>

                    <option value="nfl_rush_td">
                      Rush TD / Game
                    </option>

                    <option value="nfl_targets">
                      Targets / Game
                    </option>

                    <option value="nfl_receptions">
                      Receptions / Game
                    </option>

                    <option value="nfl_rec_yd">
                      Receiving Yards / Game
                    </option>

                    <option value="nfl_rec_td">
                      Receiving TD / Game
                    </option>

                    <option value="player_name">
                      Player Name
                    </option>
                  </select>
                </div>

                <button
                  type="button"
                  onClick={() =>
                    setSortDirection(
                      (
                        previous,
                      ) =>
                        previous ===
                        "asc"
                          ? "desc"
                          : "asc",
                    )
                  }
                  className="rounded-xl border border-slate-200 bg-white px-3 py-3 text-sm font-black text-slate-700"
                >
                  {sortDirection ===
                  "asc"
                    ? "↑"
                    : "↓"}
                </button>
              </div>

              <div className="space-y-3 md:hidden">
                {filteredRows.map(
                  (
                    row,
                  ) => {
                    const position =
                      String(
                        row.position_group ??
                          "",
                      ).toUpperCase();

                    const selected =
                      isCompareSelected(
                        row,
                      );

                    const fixedStats =
                      position ===
                      "QB"
                        ? [
                            {
                              label:
                                "PASS",
                              value:
                                row.nfl_passing_yards_per_game,
                              key:
                                "nfl_pass_yd" as SortKey,
                            },
                            {
                              label:
                                "P TD",
                              value:
                                row.nfl_passing_tds_per_game,
                              key:
                                "nfl_pass_td" as SortKey,
                            },
                            {
                              label:
                                "RUSH",
                              value:
                                row.nfl_rushing_yards_per_game,
                              key:
                                "nfl_rush_yd" as SortKey,
                            },
                          ]
                        : position ===
                            "RB"
                          ? [
                              {
                                label:
                                  "RUSH",
                                value:
                                  row.nfl_rushing_yards_per_game,
                                key:
                                  "nfl_rush_yd" as SortKey,
                              },
                              {
                                label:
                                  "TGT",
                                value:
                                  row.nfl_receiving_targets_per_game,
                                key:
                                  "nfl_targets" as SortKey,
                              },
                              {
                                label:
                                  "REC",
                                value:
                                  row.nfl_receptions_per_game,
                                key:
                                  "nfl_receptions" as SortKey,
                              },
                            ]
                          : [
                              {
                                label:
                                  "TGT",
                                value:
                                  row.nfl_receiving_targets_per_game,
                                key:
                                  "nfl_targets" as SortKey,
                              },
                              {
                                label:
                                  "REC",
                                value:
                                  row.nfl_receptions_per_game,
                                key:
                                  "nfl_receptions" as SortKey,
                              },
                              {
                                label:
                                  "REC YD",
                                value:
                                  row.nfl_receiving_yards_per_game,
                                key:
                                  "nfl_rec_yd" as SortKey,
                              },
                            ];

                    const nflDynamicStat =
                      sortKey ===
                      "nfl_int"
                        ? {
                            label:
                              "INT",
                            value:
                              row.nfl_passing_ints_per_game,
                            key:
                              "nfl_int" as SortKey,
                          }
                        : sortKey ===
                            "nfl_rush_td"
                          ? {
                              label:
                                "R TD",
                              value:
                                row.nfl_rushing_tds_per_game,
                              key:
                                "nfl_rush_td" as SortKey,
                            }
                          : sortKey ===
                              "nfl_rec_td"
                            ? {
                                label:
                                  "REC TD",
                                value:
                                  row.nfl_receiving_tds_per_game,
                                key:
                                  "nfl_rec_td" as SortKey,
                              }
                            : sortKey ===
                                "nfl_rec_yd"
                              ? {
                                  label:
                                    "REC YD",
                                  value:
                                    row.nfl_receiving_yards_per_game,
                                  key:
                                    "nfl_rec_yd" as SortKey,
                                }
                              : sortKey ===
                                  "nfl_receptions"
                                ? {
                                    label:
                                      "REC",
                                    value:
                                      row.nfl_receptions_per_game,
                                    key:
                                      "nfl_receptions" as SortKey,
                                  }
                                : sortKey ===
                                    "nfl_targets"
                                  ? {
                                      label:
                                        "TGT",
                                      value:
                                        row.nfl_receiving_targets_per_game,
                                      key:
                                        "nfl_targets" as SortKey,
                                    }
                                  : sortKey ===
                                      "nfl_pass_td"
                                    ? {
                                        label:
                                          "P TD",
                                        value:
                                          row.nfl_passing_tds_per_game,
                                        key:
                                          "nfl_pass_td" as SortKey,
                                      }
                                    : sortKey ===
                                        "nfl_pass_yd"
                                      ? {
                                          label:
                                            "PASS",
                                          value:
                                            row.nfl_passing_yards_per_game,
                                          key:
                                            "nfl_pass_yd" as SortKey,
                                        }
                                      : {
                                          label:
                                            "FP/G",
                                          value:
                                            row.nfl_fantasy_points_per_game,
                                          key:
                                            "nfl_fp" as SortKey,
                                        };

                    const stats = [
                      ...fixedStats,
                      nflDynamicStat,
                    ];

                    return (
                      <button
                        key={
                          row.player_id
                        }
                        type="button"
                        onClick={() =>
                          handlePlayerHistoryRowClick(
                            row,
                          )
                        }
                        className={`relative w-full rounded-2xl border bg-white p-3.5 text-left shadow-sm transition ${
                          selected
                            ? "border-sky-400 ring-2 ring-sky-300/60"
                            : "border-slate-200"
                        }`}
                      >
                        <div className="flex items-center gap-3">
                          <PlayerHeadshot
                            nbaPlayerId={
                              null
                            }
                            nflPlayerId={
                              row.nfl_player_id
                            }
                            playerName={
                              row.player_name
                            }
                            size="md"
                          />

                          <div className="min-w-0 flex-1">
                            <div className="truncate font-black text-slate-950">
                              {
                                row.player_name
                              }
                            </div>

                            <div className="mt-0.5 text-xs text-slate-500">
                              {[
                                row.team_abbreviation,
                                row.position_group,
                                row.nfl_games_played
                                  ? `${row.nfl_games_played} GP`
                                  : null,
                              ]
                                .filter(
                                  Boolean,
                                )
                                .join(" · ")}
                            </div>
                          </div>

                          <div className="text-right">
                            <div className={`text-xl font-black ${
                              sortKey ===
                              "nfl_fp"
                                ? "text-sky-800"
                                : "text-slate-950"
                            }`}>
                              {fmt(
                                row.nfl_fantasy_points_per_game,
                                2,
                              )}
                            </div>

                            <div className="text-[10px] font-bold uppercase text-slate-400">
                              FP/G
                            </div>
                          </div>
                        </div>

                        <div className="mt-3 grid grid-cols-4 gap-1 text-center">
                          {stats.map(
                            (
                              stat,
                            ) => {
                              const active =
                                stat.key ===
                                sortKey;

                              return (
                                <div
                                  key={
                                    stat.label
                                  }
                                  className={`rounded-lg px-1 py-1.5 ${
                                    active
                                      ? "border border-sky-300 bg-sky-50"
                                      : ""
                                  }`}
                                >
                                  <div className={`text-[13px] font-black ${
                                    active
                                      ? "text-sky-800"
                                      : "text-slate-900"
                                  }`}>
                                    {fmt(
                                      stat.value,
                                      stat.label.includes(
                                        "TD",
                                      ) ||
                                      stat.label ===
                                        "INT"
                                        ? 2
                                        : 1,
                                    )}
                                  </div>

                                  <div className={`text-[9px] font-bold uppercase ${
                                    active
                                      ? "text-sky-700"
                                      : "text-slate-400"
                                  }`}>
                                    {
                                      stat.label
                                    }
                                  </div>
                                </div>
                              );
                            },
                          )}
                        </div>
                      </button>
                    );
                  },
                )}
              </div>

              <div className="hidden overflow-x-auto md:block">
                <table className="min-w-[1100px] w-full border-collapse text-sm">
                  <thead className="bg-sky-50 text-slate-700">
                    <tr className="text-left">
                      <th className="px-4 py-3">
                        {headerButton(
                          "Player",
                          "player_name",
                        )}
                      </th>

                      <th className="px-3 py-3">
                        Pos
                      </th>

                      <th className="px-3 py-3">
                        GP
                      </th>

                      <th className="px-3 py-3">
                        {headerButton(
                          "FP/G",
                          "nfl_fp",
                        )}
                      </th>

                      <th className="px-3 py-3">
                        {headerButton(
                          "Pass Yd/G",
                          "nfl_pass_yd",
                        )}
                      </th>

                      <th className="px-3 py-3">
                        {headerButton(
                          "Pass TD/G",
                          "nfl_pass_td",
                        )}
                      </th>

                      <th className="px-3 py-3">
                        {headerButton(
                          "INT/G",
                          "nfl_int",
                        )}
                      </th>

                      <th className="px-3 py-3">
                        {headerButton(
                          "Rush Yd/G",
                          "nfl_rush_yd",
                        )}
                      </th>

                      <th className="px-3 py-3">
                        {headerButton(
                          "Rush TD/G",
                          "nfl_rush_td",
                        )}
                      </th>

                      <th className="px-3 py-3">
                        {headerButton(
                          "TGT/G",
                          "nfl_targets",
                        )}
                      </th>

                      <th className="px-3 py-3">
                        {headerButton(
                          "REC/G",
                          "nfl_receptions",
                        )}
                      </th>

                      <th className="px-3 py-3">
                        {headerButton(
                          "Rec Yd/G",
                          "nfl_rec_yd",
                        )}
                      </th>

                      <th className="px-3 py-3">
                        {headerButton(
                          "Rec TD/G",
                          "nfl_rec_td",
                        )}
                      </th>
                    </tr>
                  </thead>

                  <tbody className="bg-white text-slate-800">
                    {filteredRows.map(
                      (
                        row,
                      ) => (
                        <tr
                          key={
                            row.player_id
                          }
                          className={`border-t border-slate-100 ${
                            isCompareSelected(
                              row,
                            )
                              ? "bg-sky-50"
                              : "hover:bg-sky-50/40"
                          }`}
                        >
                          <td className="px-4 py-3">
                            <button
                              type="button"
                              onClick={() =>
                                handlePlayerHistoryRowClick(
                                  row,
                                )
                              }
                              className="flex items-center gap-2 font-bold text-sky-800"
                            >
                              <PlayerHeadshot
                                nbaPlayerId={
                                  null
                                }
                                nflPlayerId={
                                  row.nfl_player_id
                                }
                                playerName={
                                  row.player_name
                                }
                                size="xs"
                              />

                              {
                                row.player_name
                              }
                            </button>
                          </td>

                          <td className="px-3 py-3 font-bold">
                            {
                              row.position_group ??
                              "—"
                            }
                          </td>

                          <td className="px-3 py-3">
                            {
                              row.nfl_games_played ??
                              "—"
                            }
                          </td>

                          <td className="px-3 py-3 font-black text-sky-800">
                            {fmt(
                              row.nfl_fantasy_points_per_game,
                              2,
                            )}
                          </td>

                          <td className="px-3 py-3">
                            {fmt(
                              row.nfl_passing_yards_per_game,
                              1,
                            )}
                          </td>

                          <td className="px-3 py-3">
                            {fmt(
                              row.nfl_passing_tds_per_game,
                              2,
                            )}
                          </td>

                          <td className="px-3 py-3">
                            {fmt(
                              row.nfl_passing_ints_per_game,
                              2,
                            )}
                          </td>

                          <td className="px-3 py-3">
                            {fmt(
                              row.nfl_rushing_yards_per_game,
                              1,
                            )}
                          </td>

                          <td className="px-3 py-3">
                            {fmt(
                              row.nfl_rushing_tds_per_game,
                              2,
                            )}
                          </td>

                          <td className="px-3 py-3">
                            {fmt(
                              row.nfl_receiving_targets_per_game,
                              2,
                            )}
                          </td>

                          <td className="px-3 py-3">
                            {fmt(
                              row.nfl_receptions_per_game,
                              2,
                            )}
                          </td>

                          <td className="px-3 py-3">
                            {fmt(
                              row.nfl_receiving_yards_per_game,
                              1,
                            )}
                          </td>

                          <td className="px-3 py-3">
                            {fmt(
                              row.nfl_receiving_tds_per_game,
                              2,
                            )}
                          </td>
                        </tr>
                      ),
                    )}
                  </tbody>
                </table>
              </div>
            </>
          ) : historyMode ===
              "season" &&
            selectedSport ===
              "nba" ? (
            <>
              <div className="mb-4 flex items-end gap-2 md:hidden">
                <div className="min-w-0 flex-1">
                  <label
                    htmlFor="nba-season-mobile-sort"
                    className="mb-2 block text-sm font-medium text-slate-700"
                  >
                    Sort by
                  </label>

                  <select
                    id="nba-season-mobile-sort"
                    value={
                      sortKey
                    }
                    onChange={
                      (
                        event,
                      ) => {
                        const nextKey =
                          event.target.value as SortKey;

                        setSortKey(
                          nextKey,
                        );

                        setSortDirection(
                          nextKey ===
                            "player_name"
                            ? "asc"
                            : "desc",
                        );
                      }
                    }
                    className="w-full rounded-xl border border-slate-200 bg-white px-3 py-3 text-sm font-semibold text-slate-900 outline-none transition focus:border-orange-300"
                  >
                    <option value="season_fantasy_points">
                      Fantasy Points
                    </option>

                    <option value="season_points">
                      Points
                    </option>

                    <option value="season_rebounds">
                      Rebounds
                    </option>

                    <option value="season_assists">
                      Assists
                    </option>

                    <option value="season_steals">
                      Steals
                    </option>

                    <option value="season_blocks">
                      Blocks
                    </option>

                    <option value="season_turnovers">
                      Turnovers
                    </option>

                    <option value="player_name">
                      Player Name
                    </option>
                  </select>
                </div>

                <button
                  type="button"
                  onClick={() =>
                    setSortDirection(
                      (
                        previous,
                      ) =>
                        previous ===
                        "asc"
                          ? "desc"
                          : "asc",
                    )
                  }
                  className="rounded-xl border border-slate-200 bg-white px-3 py-3 text-sm font-black text-slate-700"
                  aria-label="Reverse sort direction"
                >
                  {sortDirection ===
                  "asc"
                    ? "↑"
                    : "↓"}
                </button>
              </div>

              <div className="space-y-3 md:hidden">
                {filteredRows.map(
                  (
                    row,
                  ) => {
                    const selected =
                      isCompareSelected(
                        row,
                      );

                    /*
                     * PTS / REB / AST already have permanent
                     * quick-stat slots.
                     *
                     * Only replace the fourth slot when sorting
                     * by a stat that is not already visible there.
                     */
                    const dynamicStat =
                      sortKey ===
                      "season_steals"
                        ? {
                            label:
                              "STL",
                            value:
                              row.season_steals,
                            key:
                              "season_steals" as SortKey,
                          }
                        : sortKey ===
                            "season_blocks"
                          ? {
                              label:
                                "BLK",
                              value:
                                row.season_blocks,
                              key:
                                "season_blocks" as SortKey,
                            }
                          : sortKey ===
                              "season_turnovers"
                            ? {
                                label:
                                  "TO",
                                value:
                                  row.season_turnovers,
                                key:
                                  "season_turnovers" as SortKey,
                              }
                            : {
                                label:
                                  "AST",
                                value:
                                  row.season_assists,
                                key:
                                  "season_assists" as SortKey,
                              };

                    return (
                      <button
                        key={
                          row.player_id
                        }
                        type="button"
                        onClick={() =>
                          handlePlayerHistoryRowClick(
                            row,
                          )
                        }
                        className={`relative w-full rounded-2xl border bg-white p-3.5 text-left shadow-sm transition ${
                          selected
                            ? "border-orange-400 ring-2 ring-orange-300/60"
                            : "border-slate-200"
                        }`}
                      >
                        {compareMode &&
                        selected ? (
                          <div className="absolute right-3 top-3 flex h-6 w-6 items-center justify-center rounded-full bg-orange-600 text-xs font-black text-white">
                            ✓
                          </div>
                        ) : null}

                        <div className="flex items-center gap-3">
                          <PlayerHeadshot
                            nbaPlayerId={
                              row.nba_player_id
                            }
                            nflPlayerId={
                              null
                            }
                            playerName={
                              row.player_name
                            }
                            size="md"
                          />

                          <div className="min-w-0 flex-1">
                            <div className="truncate pr-7 font-black text-slate-950">
                              {
                                row.player_name
                              }
                            </div>

                            <div className="mt-0.5 text-xs font-medium text-slate-500">
                              {[
                                row.team_abbreviation,
                                row.position_group,
                              ]
                                .filter(
                                  Boolean,
                                )
                                .join(" · ") ||
                                "NBA"}
                            </div>
                          </div>
                        </div>

                        <div className="mt-3 grid grid-cols-4 gap-1 border-t border-slate-100 pt-2 text-center">
                          {[
                            {
                              label:
                                "FP",
                              value:
                                row.season_fantasy_points,
                              key:
                                "season_fantasy_points" as SortKey,
                            },
                            {
                              label:
                                "PTS",
                              value:
                                row.season_points,
                              key:
                                "season_points" as SortKey,
                            },
                            {
                              label:
                                "REB",
                              value:
                                row.season_rebounds,
                              key:
                                "season_rebounds" as SortKey,
                            },
                            {
                              label:
                                dynamicStat.label,
                              value:
                                dynamicStat.value,
                              key:
                                dynamicStat.key,
                            },
                          ].map(
                            (
                              stat,
                              index,
                            ) => {
                              const active =
                                stat.key ===
                                sortKey;

                              return (
                                <div
                                  key={`${row.player_id}-${stat.label}-${index}`}
                                  className={`rounded-lg border px-1 py-1.5 ${
                                    active
                                      ? "border-orange-400 bg-orange-50"
                                      : "border-transparent bg-slate-50"
                                  }`}
                                >
                                  <div
                                    className={`text-[13px] font-black ${
                                      active
                                        ? "text-orange-700"
                                        : "text-slate-900"
                                    }`}
                                  >
                                    {fmt(
                                      stat.value,
                                      1,
                                    )}
                                  </div>

                                  <div
                                    className={`text-[9px] font-bold uppercase ${
                                      active
                                        ? "text-orange-700"
                                        : "text-slate-400"
                                    }`}
                                  >
                                    {
                                      stat.label
                                    }
                                  </div>
                                </div>
                              );
                            },
                          )}
                        </div>
                      </button>
                    );
                  },
                )}
              </div>

              <div className="hidden overflow-x-auto md:block">
                <table className="min-w-[900px] w-full border-collapse text-sm">
                  <thead className="bg-sky-50 text-slate-700">
                    <tr className="text-left">
                      <th className="px-4 py-3">
                        {headerButton(
                          "Player",
                          "player_name",
                        )}
                      </th>

                      <th className="px-3 py-3">
                        {headerButton(
                          "FP",
                          "season_fantasy_points",
                        )}
                      </th>

                      <th className="px-3 py-3">
                        {headerButton(
                          "PTS",
                          "season_points",
                        )}
                      </th>

                      <th className="px-3 py-3">
                        {headerButton(
                          "REB",
                          "season_rebounds",
                        )}
                      </th>

                      <th className="px-3 py-3">
                        {headerButton(
                          "AST",
                          "season_assists",
                        )}
                      </th>

                      <th className="px-3 py-3">
                        {headerButton(
                          "STL",
                          "season_steals",
                        )}
                      </th>

                      <th className="px-3 py-3">
                        {headerButton(
                          "BLK",
                          "season_blocks",
                        )}
                      </th>

                      <th className="px-3 py-3">
                        {headerButton(
                          "TO",
                          "season_turnovers",
                        )}
                      </th>
                    </tr>
                  </thead>

                  <tbody className="bg-white text-slate-800">
                    {filteredRows.map(
                      (
                        row,
                      ) => (
                        <tr
                          key={
                            row.player_id
                          }
                          className={`border-t border-slate-100 transition ${
                            isCompareSelected(
                              row,
                            )
                              ? "bg-sky-50"
                              : "hover:bg-sky-50/40"
                          }`}
                        >
                          <td className="px-4 py-3">
                            <button
                              type="button"
                              onClick={() =>
                                handlePlayerHistoryRowClick(
                                  row,
                                )
                              }
                              className={`flex items-center gap-3 rounded-xl px-2 py-1 text-left font-bold transition ${
                                isCompareSelected(
                                  row,
                                )
                                  ? "bg-sky-100 text-sky-950 ring-2 ring-sky-300"
                                  : "text-sky-800"
                              }`}
                            >
                              <PlayerHeadshot
                                nbaPlayerId={
                                  row.nba_player_id
                                }
                                nflPlayerId={
                                  null
                                }
                                playerName={
                                  row.player_name
                                }
                                size="xs"
                              />

                              <span>
                                <span className="block">
                                  {
                                    row.player_name
                                  }
                                </span>

                                <span className="block text-[10px] font-medium text-slate-400">
                                  {[
                                    row.team_abbreviation,
                                    row.position_group,
                                  ]
                                    .filter(
                                      Boolean,
                                    )
                                    .join(" · ")}
                                </span>
                              </span>
                            </button>
                          </td>

                          <td className="px-3 py-3 font-black text-sky-800">
                            {fmt(
                              row.season_fantasy_points,
                              1,
                            )}
                          </td>

                          <td className="px-3 py-3">
                            {fmt(
                              row.season_points,
                              1,
                            )}
                          </td>

                          <td className="px-3 py-3">
                            {fmt(
                              row.season_rebounds,
                              1,
                            )}
                          </td>

                          <td className="px-3 py-3">
                            {fmt(
                              row.season_assists,
                              1,
                            )}
                          </td>

                          <td className="px-3 py-3">
                            {fmt(
                              row.season_steals,
                              1,
                            )}
                          </td>

                          <td className="px-3 py-3">
                            {fmt(
                              row.season_blocks,
                              1,
                            )}
                          </td>

                          <td className="px-3 py-3">
                            {fmt(
                              row.season_turnovers,
                              1,
                            )}
                          </td>
                        </tr>
                      ),
                    )}
                  </tbody>
                </table>
              </div>
            </>
          ) : isGolf ? (
            <>
              <div className="mb-4 flex items-end gap-2 md:hidden">
                <div className="min-w-0 flex-1">
                  <label
                    htmlFor="golf-mobile-sort"
                    className="mb-2 block text-sm font-medium text-slate-700"
                  >
                    Sort by
                  </label>

                  <select
                    id="golf-mobile-sort"
                    value={
                      sortKey
                    }
                    onChange={
                      (
                        event,
                      ) => {
                        const nextKey =
                          event.target.value as SortKey;

                        setSortKey(
                          nextKey,
                        );

                        setSortDirection(
                          defaultDirection(
                            nextKey,
                          ),
                        );
                      }
                    }
                    className="w-full rounded-xl border border-slate-200 bg-white px-3 py-3 text-sm font-semibold text-slate-900 outline-none transition focus:border-emerald-300"
                  >
                    <option value="times_drafted">
                      Times Drafted
                    </option>

                    <option value="avg_score">
                      Avg Score
                    </option>

                    <option value="high_score">
                      Best Score
                    </option>

                    <option value="winning_lineups">
                      Wins
                    </option>

                    <option value="podium_lineups">
                      Podiums
                    </option>

                    <option value="avg_finish">
                      Avg Finish
                    </option>

                    <option value="cuts_made_pct">
                      Cuts %
                    </option>

                    <option value="birdies">
                      Birdies
                    </option>

                    <option value="eagles">
                      Eagles
                    </option>

                    <option value="albatrosses">
                      Albatrosses
                    </option>

                    <option value="holes_in_one">
                      Aces
                    </option>

                    <option value="rounds_under_par">
                      Rounds Under Par
                    </option>

                    <option value="player_name">
                      Golfer Name
                    </option>
                  </select>
                </div>

                <button
                  type="button"
                  onClick={() =>
                    setSortDirection(
                      (
                        previous,
                      ) =>
                        previous ===
                        "asc"
                          ? "desc"
                          : "asc",
                    )
                  }
                  className="flex h-[46px] w-[52px] shrink-0 items-center justify-center rounded-xl border border-slate-200 bg-white text-xl font-black text-emerald-800 transition hover:bg-emerald-50"
                  aria-label={
                    sortDirection ===
                    "asc"
                      ? "Sort descending"
                      : "Sort ascending"
                  }
                  title={
                    sortDirection ===
                    "asc"
                      ? "Ascending"
                      : "Descending"
                  }
                >
                  {sortDirection ===
                  "asc"
                    ? "↑"
                    : "↓"}
                </button>
              </div>

              <div className="space-y-3 md:hidden">
                {filteredRows.map(
                  (
                    row,
                  ) => {
                    const selected =
                      isCompareSelected(
                        row,
                      );

                    const dynamic =
                      getGolfMobileDynamicStat(
                        row,
                      );

                    const cards = [
                      {
                        label:
                          "AVG",
                        value:
                          golfScore(
                            row.avg_score,
                          ),
                        active:
                          isVisibleSortSlotActive(
                            "avg",
                          ),
                      },
                      {
                        label:
                          "BEST",
                        value:
                          golfScore(
                            row.high_score,
                          ),
                        active:
                          isVisibleSortSlotActive(
                            "best",
                          ),
                      },
                      {
                        label:
                          "WINS",
                        value:
                          String(
                            row.winning_lineups,
                          ),
                        active:
                          isVisibleSortSlotActive(
                            "wins",
                          ),
                      },
                      {
                        label:
                          dynamic.label,
                        value:
                          dynamic.value,
                        active:
                          isVisibleSortSlotActive(
                            "dynamic",
                          ),
                      },
                    ];

                    return (
                      <button
                        key={
                          row.player_id
                        }
                        type="button"
                        onClick={() =>
                          handlePlayerHistoryRowClick(
                            row,
                          )
                        }
                        className={`relative w-full rounded-2xl border bg-white p-3.5 text-left shadow-sm transition ${
                          selected
                            ? "border-emerald-400 ring-2 ring-emerald-300/50"
                            : "border-slate-200 hover:border-emerald-300 hover:bg-emerald-50/40"
                        }`}
                      >
                        {compareMode &&
                        selected ? (
                          <div className="absolute right-3 top-3 flex h-6 w-6 items-center justify-center rounded-full bg-emerald-500 text-xs font-black text-white">
                            ✓
                          </div>
                        ) : null}

                        <div className="flex items-center gap-3">
                          <div className="h-12 w-12 shrink-0 overflow-hidden rounded-full bg-slate-100">
                            {row.headshot_url ||
                            row.espn_golf_player_id ? (
                              <img
                                src={
                                  row.headshot_url ??
                                  `https://a.espncdn.com/i/headshots/golf/players/full/${row.espn_golf_player_id}.png`
                                }
                                alt={
                                  row.player_name
                                }
                                className="h-full w-full object-cover"
                              />
                            ) : (
                              <div className="flex h-full w-full items-center justify-center">
                                ⛳
                              </div>
                            )}
                          </div>

                          <div className="min-w-0 flex-1">
                            <div className="truncate pr-7 font-black text-slate-950">
                              {
                                row.player_name
                              }
                            </div>

                            <div className="mt-0.5 text-xs text-slate-500">
                              Drafted{" "}
                              {
                                row.times_drafted
                              }
                              x
                              {row.owgr_rank
                                ? ` · OWGR #${row.owgr_rank}`
                                : ""}
                            </div>
                          </div>
                        </div>

                        <div className="mt-3 grid grid-cols-4 gap-1 border-t border-slate-100 pt-2 text-center">
                          {cards.map(
                            (
                              card,
                            ) => (
                              <div
                                key={
                                  card.label
                                }
                                className={`rounded-lg border px-1 py-1.5 ${
                                  card.active
                                    ? "border-emerald-400 bg-emerald-50"
                                    : "border-transparent bg-slate-50"
                                }`}
                              >
                                <div
                                  className={`text-[13px] font-black ${
                                    card.active
                                      ? "text-emerald-700"
                                      : "text-slate-900"
                                  }`}
                                >
                                  {
                                    card.value
                                  }
                                </div>

                                <div
                                  className={`text-[9px] font-bold uppercase ${
                                    card.active
                                      ? "text-emerald-700"
                                      : "text-slate-400"
                                  }`}
                                >
                                  {
                                    card.label
                                  }
                                </div>
                              </div>
                            ),
                          )}
                        </div>

                        {(row.albatrosses ??
                          0) >
                          0 ||
                        (row.holes_in_one ??
                          0) >
                          0 ? (
                          <div className="mt-2 flex gap-2">
                            {(row.albatrosses ??
                              0) >
                            0 ? (
                              <span className="rounded-full bg-violet-100 px-2 py-1 text-[10px] font-bold text-violet-800">
                                🦅{" "}
                                {
                                  row.albatrosses
                                }{" "}
                                Albatross
                              </span>
                            ) : null}

                            {(row.holes_in_one ??
                              0) >
                            0 ? (
                              <span className="rounded-full bg-amber-100 px-2 py-1 text-[10px] font-bold text-amber-800">
                                ⛳{" "}
                                {
                                  row.holes_in_one
                                }{" "}
                                Ace
                              </span>
                            ) : null}
                          </div>
                        ) : null}
                      </button>
                    );
                  },
                )}
              </div>

              <div className="hidden overflow-x-auto md:block">
                <table className="min-w-[1250px] border-collapse text-sm">
                  <thead className="bg-emerald-50 text-slate-700">
                    <tr className="text-left">
                      <th className="px-4 py-3">
                        {headerButton(
                          "Golfer",
                          "player_name",
                        )}
                      </th>

                      <th className="px-3 py-3">
                        {headerButton(
                          "Drafted",
                          "times_drafted",
                        )}
                      </th>

                      <th className="px-3 py-3">
                        {headerButton(
                          "Avg",
                          "avg_score",
                        )}
                      </th>

                      <th className="px-3 py-3">
                        {headerButton(
                          "Best",
                          "high_score",
                        )}
                      </th>

                      <th className="px-3 py-3">
                        {headerButton(
                          "Wins",
                          "winning_lineups",
                        )}
                      </th>

                      <th className="px-3 py-3">
                        {headerButton(
                          "Podiums",
                          "podium_lineups",
                        )}
                      </th>

                      <th className="px-3 py-3">
                        {headerButton(
                          "Avg Finish",
                          "avg_finish",
                        )}
                      </th>

                      <th className="px-3 py-3">
                        {headerButton(
                          "Cuts",
                          "cuts_made_pct",
                        )}
                      </th>

                      <th className="px-3 py-3">
                        {headerButton(
                          "Birdies",
                          "birdies",
                        )}
                      </th>

                      <th className="px-3 py-3">
                        {headerButton(
                          "Eagles",
                          "eagles",
                        )}
                      </th>

                      <th className="px-3 py-3">
                        {headerButton(
                          "Albatross",
                          "albatrosses",
                        )}
                      </th>

                      <th className="px-3 py-3">
                        {headerButton(
                          "Aces",
                          "holes_in_one",
                        )}
                      </th>

                      <th className="px-3 py-3">
                        {headerButton(
                          "Rds Under",
                          "rounds_under_par",
                        )}
                      </th>
                    </tr>
                  </thead>

                  <tbody className="bg-white text-slate-800">
                    {filteredRows.map(
                      (
                        row,
                      ) => (
                        <tr
                          key={
                            row.player_id
                          }
                          className="border-t border-slate-100 transition hover:bg-emerald-50/40"
                        >
                          <td className="px-4 py-3">
                            <button
                              type="button"
                              onClick={() =>
                                handlePlayerHistoryRowClick(
                                  row,
                                )
                              }
                              className={`flex items-center gap-3 rounded-xl px-2 py-1 text-left font-bold transition ${
                                isCompareSelected(
                                  row,
                                )
                                  ? "bg-emerald-100 text-emerald-950 ring-2 ring-emerald-300"
                                  : "text-emerald-800 hover:text-emerald-950"
                              }`}
                            >
                              <div className="h-9 w-9 shrink-0 overflow-hidden rounded-full bg-slate-100">
                                {row.headshot_url ||
                                row.espn_golf_player_id ? (
                                  <img
                                    src={
                                      row.headshot_url ??
                                      `https://a.espncdn.com/i/headshots/golf/players/full/${row.espn_golf_player_id}.png`
                                    }
                                    alt={
                                      row.player_name
                                    }
                                    className="h-full w-full object-cover"
                                  />
                                ) : (
                                  <div className="flex h-full w-full items-center justify-center text-sm">
                                    ⛳
                                  </div>
                                )}
                              </div>

                              <div>
                                <div>
                                  {
                                    row.player_name
                                  }
                                </div>

                                {row.owgr_rank ? (
                                  <div className="text-[10px] font-medium text-slate-400">
                                    OWGR #
                                    {
                                      row.owgr_rank
                                    }
                                  </div>
                                ) : null}
                              </div>
                            </button>
                          </td>

                          <td className="px-3 py-3 font-semibold">
                            {
                              row.times_drafted
                            }
                          </td>

                          <td className="px-3 py-3 font-black text-emerald-800">
                            {golfScore(
                              row.avg_score,
                            )}
                          </td>

                          <td className="px-3 py-3">
                            {golfScore(
                              row.high_score,
                            )}
                          </td>

                          <td className="px-3 py-3 font-bold">
                            {
                              row.winning_lineups
                            }
                          </td>

                          <td className="px-3 py-3">
                            {
                              row.podium_lineups ??
                              0
                            }
                          </td>

                          <td className="px-3 py-3">
                            {row.avg_finish ===
                            null
                              ? "—"
                              : fmt(
                                  row.avg_finish,
                                  1,
                                )}
                          </td>

                          <td className="px-3 py-3">
                            {cutDisplay(
                              row.cuts_made,
                              row.cut_opportunities,
                            )}
                          </td>

                          <td className="px-3 py-3">
                            {
                              row.birdies ??
                              0
                            }
                          </td>

                          <td className="px-3 py-3">
                            {
                              row.eagles ??
                              0
                            }
                          </td>

                          <td
                            className={`px-3 py-3 ${
                              (
                                row.albatrosses ??
                                0
                              ) >
                              0
                                ? "font-black text-violet-700"
                                : ""
                            }`}
                          >
                            {
                              row.albatrosses ??
                              0
                            }
                          </td>

                          <td
                            className={`px-3 py-3 ${
                              (
                                row.holes_in_one ??
                                0
                              ) >
                              0
                                ? "font-black text-amber-700"
                                : ""
                            }`}
                          >
                            {
                              row.holes_in_one ??
                              0
                            }
                          </td>

                          <td className="px-3 py-3">
                            {
                              row.rounds_under_par ??
                              0
                            }
                          </td>
                        </tr>
                      ),
                    )}
                  </tbody>
                </table>
              </div>
            </>
          ) : (
            <>
              <div className="space-y-3 md:hidden">
                {filteredRows.map(
                  (
                    row,
                  ) => {
                    const selected =
                      isCompareSelected(
                        row,
                      );

                    const leagueDynamicStat =
                      sortKey ===
                      "winning_lineups"
                        ? {
                            label:
                              "WINS",
                            value:
                              String(
                                row.winning_lineups,
                              ),
                            key:
                              "winning_lineups" as SortKey,
                          }
                        : sortKey ===
                            "runner_up_lineups"
                          ? {
                              label:
                                "2ND",
                              value:
                                String(
                                  row.runner_up_lineups,
                                ),
                              key:
                                "runner_up_lineups" as SortKey,
                            }
                          : sortKey ===
                              "avg_finish"
                            ? {
                                label:
                                  "FINISH",
                                value:
                                  row.avg_finish
                                    ? row.avg_finish.toFixed(
                                        2,
                                      )
                                    : "—",
                                key:
                                  "avg_finish" as SortKey,
                              }
                            : sortKey ===
                                "low_score"
                              ? {
                                  label:
                                    "LOW",
                                  value:
                                    row.low_score.toFixed(
                                      1,
                                    ),
                                  key:
                                    "low_score" as SortKey,
                                }
                              : {
                                  label:
                                    "DRAFTED",
                                  value:
                                    String(
                                      row.times_drafted,
                                    ),
                                  key:
                                    "times_drafted" as SortKey,
                                };

                    const leagueCardStats = [
                      {
                        label:
                          "AVG",
                        value:
                          row.avg_score.toFixed(
                            1,
                          ),
                        key:
                          "avg_score" as SortKey,
                      },
                      {
                        label:
                          "BEST",
                        value:
                          row.high_score.toFixed(
                            1,
                          ),
                        key:
                          "high_score" as SortKey,
                      },
                      {
                        label:
                          "WINS",
                        value:
                          String(
                            row.winning_lineups,
                          ),
                        key:
                          "winning_lineups" as SortKey,
                      },
                      leagueDynamicStat,
                    ];

                    return (
                      <button
                        key={
                          row.player_id
                        }
                        type="button"
                        onClick={() =>
                          handlePlayerHistoryRowClick(
                            row,
                          )
                        }
                        className={`relative w-full rounded-2xl border bg-white p-4 text-left shadow-sm transition ${
                          selected
                            ? selectedSport === "nfl"
                              ? "border-sky-400 ring-2 ring-sky-300/50"
                              : "border-orange-400 ring-2 ring-orange-300/50"
                            : "border-slate-200"
                        }`}
                      >
                        {compareMode &&
                        selected ? (
                          <div
                            className={`absolute right-3 top-3 flex h-6 w-6 items-center justify-center rounded-full text-xs font-black text-white ${
                              selectedSport === "nfl"
                                ? "bg-sky-600"
                                : "bg-orange-600"
                            }`}
                          >
                            ✓
                          </div>
                        ) : null}

                        <div className="flex items-center gap-3">
                          <PlayerHeadshot
                            nbaPlayerId={
                              row.nba_player_id
                            }
                            nflPlayerId={
                              row.nfl_player_id
                            }
                            playerName={
                              row.player_name
                            }
                            size="md"
                          />

                          <div className="min-w-0 flex-1">
                            <div className="truncate pr-7 font-black text-slate-950">
                              {
                                row.player_name
                              }
                            </div>

                            <div className="mt-0.5 text-xs text-slate-500">
                              Drafted{" "}
                              {
                                row.times_drafted
                              }
                              x
                              {row.avg_finish
                                ? ` · ${row.avg_finish.toFixed(
                                    1,
                                  )} avg finish`
                                : ""}
                            </div>
                          </div>
                        </div>

                        <div className="mt-3 grid grid-cols-4 gap-1 text-center">
                          {leagueCardStats.map(
                            (
                              stat,
                              index,
                            ) => {
                              const active =
                                stat.key ===
                                sortKey;

                              return (
                                <div
                                  key={`${row.player_id}-${stat.label}-${index}`}
                                  className={`rounded-lg border px-1 py-1.5 ${
                                    active
                                      ? selectedSport === "nfl"
                                        ? "border-sky-300 bg-sky-50"
                                        : "border-orange-300 bg-orange-50"
                                      : "border-transparent"
                                  }`}
                                >
                                  <div
                                    className={`text-[13px] font-black ${
                                      active
                                        ? selectedSport === "nfl"
                                          ? "text-sky-800"
                                          : "text-orange-800"
                                        : "text-slate-900"
                                    }`}
                                  >
                                    {
                                      stat.value
                                    }
                                  </div>

                                  <div
                                    className={`mt-0.5 text-[9px] font-bold uppercase ${
                                      active
                                        ? selectedSport === "nfl"
                                          ? "text-sky-700"
                                          : "text-orange-700"
                                        : "text-slate-400"
                                    }`}
                                  >
                                    {
                                      stat.label
                                    }
                                  </div>
                                </div>
                              );
                            },
                          )}
                        </div>
                      </button>
                    );
                  },
                )}
              </div>

              <div className="-mx-4 hidden overflow-x-auto px-4 md:block">
                <table className="min-w-full border-collapse text-sm">
                <thead className="bg-slate-100 text-slate-700">
                  <tr className="text-left">
                    <th className="px-4 py-3">
                      {headerButton(
                        "Player",
                        "player_name",
                      )}
                    </th>

                    <th className="px-4 py-3">
                      {headerButton(
                        "Times Drafted",
                        "times_drafted",
                      )}
                    </th>

                    <th className="px-4 py-3">
                      {headerButton(
                        "Avg Score",
                        "avg_score",
                      )}
                    </th>

                    <th className="px-4 py-3">
                      {headerButton(
                        "High Score",
                        "high_score",
                      )}
                    </th>

                    <th className="px-4 py-3">
                      {headerButton(
                        "Low Score",
                        "low_score",
                      )}
                    </th>

                    <th className="px-4 py-3">
                      {headerButton(
                        "Winning Lineups",
                        "winning_lineups",
                      )}
                    </th>

                    <th className="px-4 py-3">
                      {headerButton(
                        "Runner-up Lineups",
                        "runner_up_lineups",
                      )}
                    </th>

                    <th className="px-4 py-3">
                      {headerButton(
                        "Avg Finish",
                        "avg_finish",
                      )}
                    </th>
                  </tr>
                </thead>

                <tbody className="bg-white text-slate-800">
                  {filteredRows.map(
                    (
                      row,
                    ) => (
                      <tr
                        key={
                          row.player_id
                        }
                        className={`border-t border-slate-100 transition ${
                          isCompareSelected(
                            row,
                          )
                            ? "bg-sky-50"
                            : ""
                        }`}
                      >
                        <td className="px-4 py-3 font-medium">
                          <button
                            type="button"
                            onClick={() =>
                              handlePlayerHistoryRowClick(
                                row,
                              )
                            }
                            className={`flex items-center gap-2 rounded-xl px-2 py-1 font-medium transition ${
                              isCompareSelected(
                                row,
                              )
                                ? "bg-sky-100 text-sky-950 ring-2 ring-sky-300"
                                : "text-sky-700 underline-offset-2 hover:text-sky-900 hover:underline"
                            }`}
                          >
                            <PlayerHeadshot
                              nbaPlayerId={
                                row.nba_player_id
                              }
                              nflPlayerId={
                                row.nfl_player_id
                              }
                              playerName={
                                row.player_name
                              }
                              size="xs"
                            />

                            <span>
                              {
                                row.player_name
                              }
                            </span>
                          </button>
                        </td>

                        <td className="px-4 py-3">
                          {
                            row.times_drafted
                          }
                        </td>

                        <td className="px-4 py-3">
                          {row.avg_score.toFixed(
                            2,
                          )}
                        </td>

                        <td className="px-4 py-3">
                          {row.high_score.toFixed(
                            2,
                          )}
                        </td>

                        <td className="px-4 py-3">
                          {row.low_score.toFixed(
                            2,
                          )}
                        </td>

                        <td className="px-4 py-3">
                          {
                            row.winning_lineups
                          }
                        </td>

                        <td className="px-4 py-3">
                          {
                            row.runner_up_lineups
                          }
                        </td>

                        <td className="px-4 py-3">
                          {row.avg_finish
                            ? row.avg_finish.toFixed(
                                2,
                              )
                            : "—"}
                        </td>
                      </tr>
                    ),
                  )}
                </tbody>
                </table>
              </div>
            </>
          )}
        </section>
      </div>

      <PlayerResearchModal
        player={
          isGolf
            ? golfProfileRow
              ? {
                  id:
                    golfProfileRow.player_id,

                  name:
                    golfProfileRow.player_name,

                  espnGolfPlayerId:
                    golfProfileRow.espn_golf_player_id ??
                    null,

                  headshotUrl:
                    golfProfileRow.headshot_url ??
                    null,

                  owgrRank:
                    golfProfileRow.owgr_rank ??
                    null,

                  country:
                    golfProfileRow.country ??
                    null,
                }
              : null
            : profilePlayer
              ? {
                  id:
                    profilePlayer.id,

                  name:
                    profilePlayer.name,

                  nbaPlayerId:
                    profilePlayer.nba_player_id ??
                    null,

                  nflPlayerId:
                    profilePlayer.nfl_player_id ??
                    null,

                  positionGroup:
                    profilePlayer.position_group ??
                    null,

                  teamAbbreviation:
                    rows.find(
                      (row) =>
                        row.player_id ===
                        profilePlayer.id,
                    )
                      ?.team_abbreviation ??
                    null,
                }
              : null
        }
        sport={
          selectedSport as
            | "nba"
            | "nfl"
            | "golf"
        }
        season={
          season
        }
        defaultMode={
          historyMode
        }
        onClose={() => {
          setProfilePlayer(
            null,
          );

          setGolfProfileRow(
            null,
          );
        }}
      />

      {!compareMode &&
      !compareOpen &&
      !isLoading &&
      filteredRows.length >
        0 ? (
        <div className="fixed bottom-[5.75rem] right-3 z-[10990] sm:hidden">
          <button
            type="button"
            data-floating-compare="true"
            onClick={() => {
              setCompareMode(
                true,
              );

              setComparePlayerIds(
                [],
              );
            }}
            className={`rounded-2xl border px-4 py-3 text-sm font-black text-white shadow-2xl backdrop-blur ${
              isGolf
                ? "border-emerald-400/80 bg-emerald-900/95 text-emerald-50"
                : selectedSport ===
                    "nfl"
                  ? "border-sky-400/80 bg-sky-950/95 text-sky-50"
                  : "border-orange-400/80 bg-orange-950/95 text-orange-50"
            }`}
          >
            ⇄ Compare{" "}
            {isGolf
              ? "Golfers"
              : "Players"}
          </button>
        </div>
      ) : null}

      {compareMode &&
      !compareOpen ? (
        <div className="fixed bottom-[5.75rem] left-3 right-3 z-[11000] sm:hidden">
          <div
            className={`mx-auto flex max-w-md items-center gap-2 rounded-2xl border bg-slate-950/95 p-2.5 text-white shadow-2xl backdrop-blur ${
              isGolf
                ? "border-emerald-700/70"
                : "border-sky-700/70"
            }`}
          >
            <div className="min-w-0 flex-1 px-1">
              <div className="text-xs font-black text-white">
                Compare{" "}
                {isGolf
                  ? "Golfers"
                  : "Players"}
              </div>

              <div
                className={`text-[11px] ${
                  isGolf
                    ? "text-emerald-300"
                    : "text-sky-300"
                }`}
              >
                {
                  comparePlayerIds.length
                }
                /3 selected
              </div>
            </div>

            <button
              type="button"
              onClick={
                cancelCompareMode
              }
              className="shrink-0 rounded-xl border border-slate-700 bg-slate-800 px-3 py-2 text-xs font-bold text-slate-200"
            >
              Cancel
            </button>

            <button
              type="button"
              disabled={
                comparePlayerIds.length <
                2
              }
              onClick={() =>
                setCompareOpen(
                  true,
                )
              }
              className={`shrink-0 rounded-xl px-3 py-2 text-xs font-black text-white shadow-lg disabled:cursor-not-allowed disabled:opacity-40 ${
                isGolf
                  ? "bg-emerald-700"
                  : "bg-sky-700"
              }`}
            >
              Compare (
              {
                comparePlayerIds.length
              }
              )
            </button>
          </div>
        </div>
      ) : null}

      {compareOpen ? (
        <PlayerCompareModal
          rows={
            compareRows
          }
          sport={
            selectedSport as
              | "nba"
              | "nfl"
              | "golf"
          }
          historyMode={
            historyMode
          }
          onClose={() =>
            setCompareOpen(
              false,
            )
          }
        />
      ) : null}
    </main>
  );
}
