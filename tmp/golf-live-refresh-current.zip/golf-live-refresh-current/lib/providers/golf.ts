const ESPN_GOLF_SCOREBOARD_URL =
  "https://site.api.espn.com/apis/site/v2/sports/golf/pga/scoreboard";

const ESPN_GOLF_COURSE_URL =
  "https://site.api.espn.com/apis/site/v2/sports/golf/leaderboard";

type EspnGolfRequest =
  | {
      kind: "scoreboard";
      dates?: string;
    }
  | {
      kind: "course";
      eventId: string;
    };

function getEspnGolfProxyBaseUrl():
  | string
  | null {
  const explicitBaseUrl =
    process.env
      .GOLF_ESPN_PROXY_BASE_URL
      ?.trim();

  if (explicitBaseUrl) {
    return explicitBaseUrl.replace(
      /\/$/,
      "",
    );
  }

  /*
   * Prefer Vercel's stable production domain over VERCEL_URL.
   *
   * VERCEL_URL identifies the specific deployment handling the request.
   * Preview/generated deployment URLs can be protected by Vercel
   * Authentication, which breaks our server-to-server ESPN proxy call
   * with a 401 even though the public production app is reachable.
   *
   * VERCEL_PROJECT_PRODUCTION_URL points at the project's production
   * domain and is therefore the correct default for the Golf Edge proxy.
   */
  const productionUrl =
    process.env
      .VERCEL_PROJECT_PRODUCTION_URL
      ?.trim();

  if (productionUrl) {
    return `https://${productionUrl}`;
  }

  const vercelUrl =
    process.env.VERCEL_URL?.trim();

  if (vercelUrl) {
    return `https://${vercelUrl}`;
  }

  return null;
}

async function fetchEspnGolfJson<T>(
  request: EspnGolfRequest,
): Promise<T> {
  const useEdgeProxy =
    process.env.VERCEL === "1";

  let requestUrl: URL;
  let requestLabel: string;

  if (useEdgeProxy) {
    const proxyBaseUrl =
      getEspnGolfProxyBaseUrl();

    const proxySecret =
      process.env
        .GOLF_CRON_SECRET
        ?.trim();

    if (
      !proxyBaseUrl ||
      !proxySecret
    ) {
      throw new Error(
        "The ESPN Golf Edge proxy is not configured. " +
          "VERCEL_URL and GOLF_CRON_SECRET are required.",
      );
    }

    requestUrl = new URL(
      "/api/espn-golf-proxy",
      proxyBaseUrl,
    );

    requestUrl.searchParams.set(
      "kind",
      request.kind,
    );

    if (
      request.kind ===
        "scoreboard" &&
      request.dates
    ) {
      requestUrl.searchParams.set(
        "dates",
        request.dates,
      );
    }

    if (
      request.kind === "course"
    ) {
      requestUrl.searchParams.set(
        "eventId",
        request.eventId,
      );
    }

    requestLabel =
      "ESPN Golf Edge proxy";

    const response = await fetch(
      requestUrl,
      {
        cache: "no-store",
        headers: {
          Accept:
            "application/json",
          Authorization:
            `Bearer ${proxySecret}`,
        },
      },
    );

    if (!response.ok) {
      const errorBody =
        await response
          .text()
          .catch(() => "");

      throw new Error(
        `${requestLabel} failed with ` +
          `${response.status} ` +
          `${response.statusText}` +
          (
            errorBody
              ? `: ${errorBody.slice(0, 300)}`
              : ""
          ),
      );
    }

    return (
      await response.json()
    ) as T;
  }

  if (
    request.kind === "scoreboard"
  ) {
    requestUrl = new URL(
      ESPN_GOLF_SCOREBOARD_URL,
    );

    if (request.dates) {
      requestUrl.searchParams.set(
        "dates",
        request.dates,
      );
    }

    requestLabel =
      "ESPN golf request";
  } else {
    requestUrl = new URL(
      ESPN_GOLF_COURSE_URL,
    );

    requestUrl.searchParams.set(
      "event",
      request.eventId,
    );

    requestLabel =
      "ESPN Golf course request";
  }

  const response = await fetch(
    requestUrl,
    {
      cache: "no-store",
      headers: {
        Accept:
          "application/json",
        "User-Agent":
          request.kind ===
          "scoreboard"
            ? "111-sports-golf-provider/1.0"
            : "111-sports-golf-course-provider/1.0",
      },
    },
  );

  if (!response.ok) {
    throw new Error(
      `${requestLabel} failed with ` +
        `${response.status} ` +
        `${response.statusText}`,
    );
  }

  return (
    await response.json()
  ) as T;
}

export type GolfTournamentStatus =
  "scheduled" | "in_progress" | "final" | "unknown";

export type GolfCompetitorStatus =
  | "scheduled"
  | "active"
  | "round_complete"
  | "finished"
  | "cut"
  | "withdrawn"
  | "disqualified"
  | "did_not_start";

type UnknownRecord = Record<string, unknown>;

type EspnStatusType = {
  name?: string;
  state?: string;
  completed?: boolean;
  description?: string;
  detail?: string;
  shortDetail?: string;
};

type EspnHole = {
  value?: number;
  displayValue?: string;
  period?: number;
  scoreType?: {
    displayValue?: string;
  };
};

type EspnStatistic = {
  value?: number;
  displayValue?: string;
  name?: string;
  label?: string;
  abbreviation?: string;
};

type EspnStatistics = {
  categories?: Array<{
    name?: string;
    displayName?: string;
    stats?: EspnStatistic[];
  }>;
};

type EspnRound = {
  value?: number;
  displayValue?: string;
  period?: number;
  linescores?: EspnHole[];
  statistics?: EspnStatistics;
};

type EspnCompetitor = {
  id?: string;
  uid?: string;
  order?: number;
  score?: string;
  athlete?: {
    fullName?: string;
    displayName?: string;
    shortName?: string;
    links?: Array<{
      href?: string;
      rel?: string[];
    }>;
    flag?: {
      href?: string;
      alt?: string;
    };
  };
  linescores?: EspnRound[];
  statistics?: unknown[];
};

type EspnCompetition = {
  status?: {
    period?: number;
    type?: EspnStatusType;
  };
  competitors?: EspnCompetitor[];
  broadcasts?: Array<{
    market?: string;
    names?: string[];
  }>;
};

type EspnEvent = {
  id?: string;
  name?: string;
  shortName?: string;
  date?: string;
  endDate?: string;
  status?: {
    type?: EspnStatusType;
  };
  competitions?: EspnCompetition[];
  links?: Array<{
    href?: string;
    rel?: string[];
  }>;
};

type EspnCalendarEntry = {
  id?: string;
  label?: string;
  startDate?: string;
  endDate?: string;
  event?: {
    $ref?: string;
  };
};

type EspnGolfScoreboardPayload = {
  season?: {
    year?: number;
    type?: number;
  };
  leagues?: Array<{
    calendar?: EspnCalendarEntry[];
  }>;
  events?: EspnEvent[];
};

export type GolfScheduleEvent = {
  espnEventId: string;
  name: string;
  startDate: string | null;
  endDate: string | null;
};

export type GolfHole = {
  holeNumber: number;
  strokes: number | null;
  relativeToPar: number | null;
  scoreDisplay: string | null;
};

export type GolfRound = {
  roundNumber: number;
  scoreToPar: number | null;
  scoreDisplay: string | null;
  strokes: number | null;
  holesCompleted: number;
  teeTime: string | null;
  teeTimeRaw: string | null;
  holes: GolfHole[];
};

export type GolfCompetitor = {
  espnPlayerId: string;
  displayName: string;
  shortName: string | null;
  country: string | null;
  countryFlagUrl: string | null;
  playerUrl: string | null;

  leaderboardOrder: number | null;
  officialScoreToPar: number | null;
  officialScoreDisplay: string | null;

  roundsCompleted: number;
  holesCompleted: number;
  currentRound: number | null;
  lastHole: number | null;

  status: GolfCompetitorStatus;
  teeTime: string | null;
  teeTimeRaw: string | null;

  rounds: GolfRound[];
};

export type GolfTournament = {
  espnEventId: string;
  name: string;
  startDate: string | null;
  endDate: string | null;
  status: GolfTournamentStatus;
  statusDescription: string | null;
  currentRound: number | null;
  completed: boolean;
  competitors: GolfCompetitor[];
};

function safeArray<T>(value: T[] | null | undefined): T[] {
  return Array.isArray(value) ? value : [];
}

function isRecord(value: unknown): value is UnknownRecord {
  return typeof value === "object" && value !== null;
}

function parseRelativeToPar(value: unknown): number | null {
  if (typeof value === "number" && Number.isFinite(value)) {
    return value;
  }

  if (typeof value !== "string") {
    return null;
  }

  const normalized = value.trim().toUpperCase();

  if (!normalized) return null;
  if (normalized === "E") return 0;

  const parsed = Number(normalized.replace("+", ""));
  return Number.isFinite(parsed) ? parsed : null;
}

function parseEspnDate(value: string | null | undefined): string | null {
  if (!value) return null;

  const parsed = new Date(value);
  if (Number.isNaN(parsed.getTime())) return null;

  return parsed.toISOString();
}

function findPlayerUrl(competitor: EspnCompetitor): string | null {
  const links = safeArray(competitor.athlete?.links);

  const preferred =
    links.find((link) => link.rel?.includes("playercard")) ??
    links.find((link) => link.rel?.includes("overview")) ??
    links[0];

  return preferred?.href ?? null;
}

function findRoundTeeTimeRaw(round: EspnRound): string | null {
  const categories = safeArray(round.statistics?.categories);

  for (const category of categories) {
    for (const stat of safeArray(category.stats)) {
      const name = [stat.name, stat.label, stat.abbreviation]
        .filter(Boolean)
        .join(" ")
        .toLowerCase();

      if (
        name.includes("tee") &&
        typeof stat.displayValue === "string" &&
        stat.displayValue.trim()
      ) {
        return stat.displayValue.trim();
      }
    }
  }

  // The current ESPN golf payload includes an unnamed tee-time value as the
  // final round statistic. Preserve the raw value, but keep this fallback
  // isolated here so the rest of the app never depends on the array position.
  for (const category of categories) {
    const stats = safeArray(category.stats);
    const finalStat = stats.at(-1);

    if (
      finalStat &&
      finalStat.value === undefined &&
      typeof finalStat.displayValue === "string" &&
      finalStat.displayValue.trim()
    ) {
      return finalStat.displayValue.trim();
    }
  }

  return null;
}

function parseTeeTime(raw: string | null): string | null {
  if (!raw) return null;

  const parsed = new Date(raw);
  if (Number.isNaN(parsed.getTime())) return null;

  return parsed.toISOString();
}

function normalizeTournamentStatus(
  status: EspnStatusType | undefined,
): GolfTournamentStatus {
  const state = status?.state?.toLowerCase();
  const name = status?.name?.toUpperCase();

  if (status?.completed || state === "post" || name === "STATUS_FINAL") {
    return "final";
  }

  if (state === "in" || name === "STATUS_IN_PROGRESS") {
    return "in_progress";
  }

  if (state === "pre" || name === "STATUS_SCHEDULED") {
    return "scheduled";
  }

  return "unknown";
}

function roundHasActivity(round: GolfRound): boolean {
  return (
    round.holesCompleted > 0 || (round.strokes !== null && round.strokes > 0)
  );
}

function inferCompetitorStatus(input: {
  tournamentStatus: GolfTournamentStatus;
  tournamentCurrentRound: number | null;
  rounds: GolfRound[];
}): GolfCompetitorStatus {
  const playedRounds = input.rounds.filter(roundHasActivity);

  const completedRounds = playedRounds.filter(
    (round) => round.holesCompleted === 18,
  ).length;

  const hasStarted = playedRounds.length > 0;

  const hasPartialRound = playedRounds.some(
    (round) =>
      round.holesCompleted > 0 &&
      round.holesCompleted < 18,
  );

  const allPlayedRoundsComplete =
    playedRounds.length > 0 &&
    playedRounds.every(
      (round) =>
        round.holesCompleted === 18,
    );

  const hasRoundThreeOrLaterActivity = playedRounds.some(
    (round) => round.roundNumber >= 3,
  );

  /*
   * ESPN includes future-round records and tee times for golfers
   * who made the cut but have not started the next round yet.
   *
   * A golfer with a Round 3 tee time must remain scheduled rather
   * than being inferred as cut merely because Round 3 has begun.
   */
  const hasRoundThreeOrLaterTeeTime = input.rounds.some(
    (round) =>
      round.roundNumber >= 3 &&
      Boolean(round.teeTime || round.teeTimeRaw),
  );

  const tournamentHasReachedRoundThree =
    (input.tournamentCurrentRound ?? 0) >= 3;

  if (input.tournamentStatus === "scheduled") {
    return "scheduled";
  }

  if (!hasStarted) {
    return input.tournamentStatus === "final" ? "did_not_start" : "scheduled";
  }

  if (completedRounds >= 4 && input.tournamentStatus === "final") {
    return "finished";
  }

  if (
    completedRounds === 2 &&
    !hasRoundThreeOrLaterActivity &&
    tournamentHasReachedRoundThree
  ) {
    /*
     * Made-cut golfers often have a Round 3 tee time before they
     * record their first Saturday hole. Keep them upcoming so they
     * receive no missed-cut penalty and still count as remaining.
     */
    if (hasRoundThreeOrLaterTeeTime) {
      return "scheduled";
    }

    return "cut";
  }

  /*
   * Do not infer withdrawal solely from missing rounds.
   *
   * ESPN's scoreboard payload can report an event as final before all
   * tournament rounds are represented. That previously classified anyone
   * with fewer than four rounds as WD and applied missing-round penalties.
   *
   * Until ESPN provides an explicit competitor-level WD/DQ status, a golfer
   * who started and was not identified as cut should be treated as finished
   * after a genuinely final event.
   */
  if (input.tournamentStatus === "final") {
    return "finished";
  }

  /*
   * A golfer who completed today's round is not actively
   * playing merely because the tournament itself continues.
   *
   * Keep this distinct from "scheduled": round_complete means
   * today's round is finished; scheduled means the golfer has
   * not yet begun the tournament's current round.
   */
  if (
    allPlayedRoundsComplete &&
    !hasPartialRound
  ) {
    return "round_complete";
  }

  return "active";
}

function parseRound(round: EspnRound): GolfRound | null {
  const roundNumber = Number(round.period);

  if (!Number.isInteger(roundNumber) || roundNumber < 1) {
    return null;
  }

  const holes = safeArray(round.linescores)
    .map((hole): GolfHole | null => {
      const holeNumber = Number(hole.period);

      if (!Number.isInteger(holeNumber) || holeNumber < 1 || holeNumber > 18) {
        return null;
      }

      const strokes =
        typeof hole.value === "number" &&
        Number.isFinite(hole.value) &&
        hole.value > 0
          ? hole.value
          : null;

      return {
        holeNumber,
        strokes,
        relativeToPar:
          strokes === null
            ? null
            : parseRelativeToPar(hole.scoreType?.displayValue),
        scoreDisplay: strokes === null ? null : (hole.displayValue ?? null),
      };
    })
    .filter((hole): hole is GolfHole => hole !== null && hole.strokes !== null)
    .sort((a, b) => a.holeNumber - b.holeNumber);

  const rawStrokes =
    typeof round.value === "number" && Number.isFinite(round.value)
      ? round.value
      : null;

  const displayValue = round.displayValue?.trim() ?? null;

  const isPlaceholderRound =
    holes.length === 0 &&
    (rawStrokes === 0 || displayValue === "-" || displayValue === "");

  const teeTimeRaw = findRoundTeeTimeRaw(round);

  return {
    roundNumber,
    scoreToPar: isPlaceholderRound ? null : parseRelativeToPar(displayValue),
    scoreDisplay: isPlaceholderRound ? null : displayValue,
    strokes: isPlaceholderRound ? null : rawStrokes,
    holesCompleted: holes.length,
    teeTime: parseTeeTime(teeTimeRaw),
    teeTimeRaw,
    holes,
  };
}

function parseCompetitor(
  competitor: EspnCompetitor,
  tournamentStatus: GolfTournamentStatus,
  tournamentCurrentRound: number | null,
): GolfCompetitor | null {
  const espnPlayerId = String(competitor.id ?? "").trim();
  const displayName = String(
    competitor.athlete?.displayName ?? competitor.athlete?.fullName ?? "",
  ).trim();

  if (!espnPlayerId || !displayName) {
    return null;
  }

  const rounds = safeArray(competitor.linescores)
    .map(parseRound)
    .filter((round): round is GolfRound => round !== null)
    .sort((a, b) => a.roundNumber - b.roundNumber);

  const roundsWithActivity = rounds.filter(roundHasActivity);

  const currentRound =
    roundsWithActivity.length > 0
      ? Math.max(...roundsWithActivity.map((round) => round.roundNumber))
      : null;

  const currentRoundRecord =
    currentRound === null
      ? null
      : (rounds.find((round) => round.roundNumber === currentRound) ?? null);

  const lastHole =
    currentRoundRecord && currentRoundRecord.holes.length > 0
      ? (currentRoundRecord.holes.at(-1)?.holeNumber ?? null)
      : null;

  /*
   * Only expose a next-round tee time when ESPN provides a genuine
   * later-round record.
   *
   * After Round 3 completed, ESPN continued reporting the completed
   * Round 3 tee time while the event status still said Round 3.
   * The UI then mislabeled that Saturday time as a Round 4 tee time.
   */
  const currentRoundIsComplete =
    currentRoundRecord?.holesCompleted === 18;

  const futureTeeTimeRound =
    rounds
      .filter(
        (round) =>
          round.roundNumber >
            Number(currentRound ?? 0) &&
          !roundHasActivity(round) &&
          Boolean(
            round.teeTimeRaw ||
              round.teeTime,
          ),
      )
      .sort(
        (a, b) =>
          a.roundNumber -
          b.roundNumber,
      )[0] ?? null;

  const tournamentRoundRecord =
    tournamentCurrentRound === null
      ? null
      : (
          rounds.find(
            (round) =>
              round.roundNumber ===
              tournamentCurrentRound,
          ) ?? null
        );

  const tournamentRoundIsUpcoming =
    tournamentRoundRecord !== null &&
    !roundHasActivity(
      tournamentRoundRecord,
    ) &&
    Boolean(
      tournamentRoundRecord.teeTimeRaw ||
        tournamentRoundRecord.teeTime,
    );

  const preferredTeeTimeRound =
    futureTeeTimeRound ??
    (
      !currentRoundIsComplete &&
      tournamentRoundIsUpcoming
        ? tournamentRoundRecord
        : null
    ) ??
    (
      !currentRoundIsComplete &&
      Boolean(
        currentRoundRecord?.teeTimeRaw ||
          currentRoundRecord?.teeTime,
      )
        ? currentRoundRecord
        : null
    );

  const teeTimeRaw =
    preferredTeeTimeRound?.teeTimeRaw ??
    null;

  const teeTime =
    preferredTeeTimeRound?.teeTime ??
    null;

  return {
    espnPlayerId,
    displayName,
    shortName: competitor.athlete?.shortName ?? null,
    country: competitor.athlete?.flag?.alt ?? null,
    countryFlagUrl: competitor.athlete?.flag?.href ?? null,
    playerUrl: findPlayerUrl(competitor),

    leaderboardOrder:
      typeof competitor.order === "number" ? competitor.order : null,
    officialScoreToPar: parseRelativeToPar(competitor.score),
    officialScoreDisplay: competitor.score ?? null,

    roundsCompleted: rounds.filter((round) => round.holesCompleted === 18)
      .length,
    holesCompleted: rounds.reduce(
      (total, round) => total + round.holesCompleted,
      0,
    ),
    currentRound,
    lastHole,

    status: inferCompetitorStatus({
      tournamentStatus,
      tournamentCurrentRound,
      rounds,
    }),
    teeTime,
    teeTimeRaw,

    rounds,
  };
}

function parseTournament(event: EspnEvent): GolfTournament | null {
  const espnEventId = String(event.id ?? "").trim();
  const name = String(event.name ?? event.shortName ?? "").trim();

  if (!espnEventId || !name) {
    return null;
  }

  const competition = event.competitions?.[0];
  const eventStatus = event.status?.type;
  const competitionStatus = competition?.status?.type;
  const statusSource = competitionStatus ?? eventStatus;

  const reportedStatus = normalizeTournamentStatus(statusSource);

  const tournamentCurrentRound =
    typeof competition?.status?.period === "number"
      ? competition.status.period
      : null;

  /*
   * ESPN can mark the current competition/day as final after
   * an early tournament round. Do not use event.endDate to
   * decide whether that represents the end of the full event.
   *
   * A four-round PGA tournament cannot be truly final while
   * ESPN still reports the current round as 1, 2, or 3.
   */
  const isPrematureEarlyRoundFinal =
    reportedStatus === "final" &&
    tournamentCurrentRound !== null &&
    tournamentCurrentRound >= 1 &&
    tournamentCurrentRound < 4;

  const normalizedReportedStatus: GolfTournamentStatus =
    isPrematureEarlyRoundFinal
      ? "in_progress"
      : reportedStatus;

  const preliminaryCompetitors = safeArray(competition?.competitors)
    .map((competitor) =>
      parseCompetitor(
        competitor,
        normalizedReportedStatus,
        tournamentCurrentRound,
      ),
    )
    .filter(
      (competitor): competitor is GolfCompetitor =>
        competitor !== null,
    );

  /*
   * ESPN can briefly return STATUS_FINAL for the event while the current
   * tournament payload still contains golfers in a partially completed
   * round. Treating that as a true final incorrectly turns every golfer
   * with fewer than four rounds into a withdrawal and applies penalties.
   *
   * A partial round is stronger evidence that the tournament is still live.
   */
  const hasPartialRoundActivity = preliminaryCompetitors.some(
    (competitor) =>
      competitor.rounds.some(
        (round) =>
          round.holesCompleted > 0 &&
          round.holesCompleted < 18,
      ),
  );

  const status: GolfTournamentStatus =
    normalizedReportedStatus === "final" && hasPartialRoundActivity
      ? "in_progress"
      : normalizedReportedStatus;

  const competitors =
    status === normalizedReportedStatus
      ? preliminaryCompetitors
      : safeArray(competition?.competitors)
          .map((competitor) =>
            parseCompetitor(
              competitor,
              status,
              tournamentCurrentRound,
            ),
          )
          .filter(
            (competitor): competitor is GolfCompetitor =>
              competitor !== null,
          );

  competitors.sort((a, b) => {
    const aOrder =
      a.leaderboardOrder ?? Number.MAX_SAFE_INTEGER;
    const bOrder =
      b.leaderboardOrder ?? Number.MAX_SAFE_INTEGER;

    if (aOrder !== bOrder) return aOrder - bOrder;
    return a.displayName.localeCompare(b.displayName);
  });

  return {
    espnEventId,
    name,
    startDate: parseEspnDate(event.date),
    endDate: parseEspnDate(event.endDate),
    status,
    statusDescription:
      competitionStatus?.detail ??
      competitionStatus?.shortDetail ??
      competitionStatus?.description ??
      eventStatus?.description ??
      null,
    currentRound: tournamentCurrentRound,
    completed: status === "final",
    competitors,
  };
}

async function fetchGolfPayload(
  dates?: string,
): Promise<EspnGolfScoreboardPayload> {
  const payload: unknown =
    await fetchEspnGolfJson<unknown>({
      kind: "scoreboard",
      dates,
    });

  if (!isRecord(payload)) {
    throw new Error(
      "ESPN golf returned an invalid payload.",
    );
  }

  return payload as EspnGolfScoreboardPayload;
}

export function parseGolfTournamentsFromPayload(
  payload: unknown,
): GolfTournament[] {
  if (!isRecord(payload)) {
    throw new Error(
      "ESPN golf returned an invalid payload.",
    );
  }

  const scoreboard =
    payload as EspnGolfScoreboardPayload;

  return safeArray(
    scoreboard.events,
  )
    .map(parseTournament)
    .filter(
      (
        tournament,
      ): tournament is GolfTournament =>
        tournament !== null,
    );
}

export function parseGolfTournamentByEventIdFromPayload(
  payload: unknown,
  espnEventId: string,
): GolfTournament | null {
  const normalizedEventId =
    espnEventId.trim();

  if (!normalizedEventId) {
    return null;
  }

  return (
    parseGolfTournamentsFromPayload(
      payload,
    ).find(
      (tournament) =>
        tournament.espnEventId ===
        normalizedEventId,
    ) ?? null
  );
}

export async function fetchGolfTournaments(
  dates?: string,
): Promise<GolfTournament[]> {
  const payload =
    await fetchGolfPayload(dates);

  return parseGolfTournamentsFromPayload(
    payload,
  );
}

export async function fetchGolfTournamentByEventId(
  espnEventId: string,
  dates?: string,
): Promise<GolfTournament | null> {
  const normalizedEventId = espnEventId.trim();

  if (!normalizedEventId) {
    return null;
  }

  const tournaments = await fetchGolfTournaments(dates);

  return (
    tournaments.find(
      (tournament) => tournament.espnEventId === normalizedEventId,
    ) ?? null
  );
}

export async function fetchGolfSchedule(
  dates?: string,
): Promise<GolfScheduleEvent[]> {
  const payload = await fetchGolfPayload(dates);
  const calendar = safeArray(payload.leagues?.[0]?.calendar);

  const schedule = calendar
    .map((entry): GolfScheduleEvent | null => {
      const espnEventId = String(entry.id ?? "").trim();
      const name = String(entry.label ?? "").trim();

      if (!espnEventId || !name) {
        return null;
      }

      return {
        espnEventId,
        name,
        startDate: parseEspnDate(entry.startDate),
        endDate: parseEspnDate(entry.endDate),
      };
    })
    .filter((event): event is GolfScheduleEvent => event !== null);

  return Array.from(
    new Map(schedule.map((event) => [event.espnEventId, event])).values(),
  ).sort((a, b) => {
    const aDate = a.startDate ?? "";
    const bDate = b.startDate ?? "";

    return aDate.localeCompare(bDate);
  });
}

export type GolfCourseHole = {
  holeNumber: number;
  par: number;
  yards: number | null;
};

export type GolfCourse = {
  espnCourseId: string;
  name: string | null;
  totalYards: number | null;
  totalPar: number | null;
  parIn: number | null;
  parOut: number | null;
  isHost: boolean;
  holes: GolfCourseHole[];
};

type EspnLeaderboardCourseHole = {
  number?: number;
  shotsToPar?: number;
  totalYards?: number;
};

type EspnLeaderboardCourse = {
  id?: string;
  name?: string;
  totalYards?: number;
  shotsToPar?: number;
  parIn?: number;
  parOut?: number;
  host?: boolean;
  holes?: EspnLeaderboardCourseHole[];
};

type EspnLeaderboardPayload = {
  events?: Array<{
    courses?: EspnLeaderboardCourse[];
  }>;
};

function nullableFiniteNumber(value: unknown): number | null {
  const numeric = Number(value);
  return Number.isFinite(numeric) ? numeric : null;
}

export async function fetchGolfCoursesByEventId(
  espnEventId: string,
): Promise<GolfCourse[]> {
  const normalizedEventId = espnEventId.trim();

  if (!normalizedEventId) {
    return [];
  }

  const payload =
    await fetchEspnGolfJson<EspnLeaderboardPayload>(
      {
        kind: "course",
        eventId:
          normalizedEventId,
      },
    );
  const courses = payload.events?.[0]?.courses ?? [];

  return courses
    .map((course): GolfCourse | null => {
      const espnCourseId = String(course.id ?? "").trim();

      if (!espnCourseId) {
        return null;
      }

      const holes = (course.holes ?? [])
        .map((hole): GolfCourseHole | null => {
          const holeNumber = Number(hole.number);
          const par = Number(hole.shotsToPar);

          if (
            !Number.isInteger(holeNumber) ||
            holeNumber < 1 ||
            holeNumber > 18 ||
            !Number.isInteger(par) ||
            par < 2 ||
            par > 7
          ) {
            return null;
          }

          const yards = nullableFiniteNumber(hole.totalYards);

          return {
            holeNumber,
            par,
            yards:
              yards !== null && yards > 0
                ? yards
                : null,
          };
        })
        .filter(
          (hole): hole is GolfCourseHole =>
            hole !== null,
        )
        .sort(
          (a, b) => a.holeNumber - b.holeNumber,
        );

      return {
        espnCourseId,
        name:
          typeof course.name === "string"
            ? course.name.trim() || null
            : null,
        totalYards: nullableFiniteNumber(
          course.totalYards,
        ),
        totalPar: nullableFiniteNumber(
          course.shotsToPar,
        ),
        parIn: nullableFiniteNumber(course.parIn),
        parOut: nullableFiniteNumber(course.parOut),
        isHost: Boolean(course.host),
        holes,
      };
    })
    .filter(
      (course): course is GolfCourse =>
        course !== null &&
        course.holes.length > 0,
    );
}

