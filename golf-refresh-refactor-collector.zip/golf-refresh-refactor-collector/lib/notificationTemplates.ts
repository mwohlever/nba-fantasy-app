import { supabaseAdmin } from "@/lib/supabaseAdmin";

export type NotificationSport = "nba" | "nfl" | "golf";

const NBA_NOTIFICATION_DEFAULTS = {
  draft_turn: {
    notificationType: "draft_turn",
    titleTemplate: "{sportEmoji} Your turn to draft!",
    bodyTemplate:
      "{teamName}, you're on the clock for your {roundOrdinal} round pick.",
    description:
      "Sent to the next participant after a draft pick is submitted.",
    availablePlaceholders: [
      "{sportEmoji}",
      "{teamName}",
      "{slateLabel}",
      "{roundNumber}",
      "{roundOrdinal}",
      "{overallPickNumber}",
      "{remainingNeeds}",
    ],
  },
  draft_final_pick: {
    notificationType: "draft_final_pick",
    titleTemplate: "{sportEmoji} Last pick!",
    bodyTemplate:
      "{teamName}, you're on the clock for your last pick — you need a {positionNeed}!",
    description:
      "Sent when the next participant is making their final draft pick.",
    availablePlaceholders: [
      "{sportEmoji}",
      "{teamName}",
      "{slateLabel}",
      "{roundNumber}",
      "{roundOrdinal}",
      "{overallPickNumber}",
      "{positionNeed}",
      "{remainingNeeds}",
    ],
  },
  player_finished: {
    notificationType: "player_finished",
    titleTemplate: "{sportEmoji} {playerName} finished!",
    bodyTemplate:
      "{playerName} finished with {fantasyPoints} fantasy points for {teamName}.",
    description:
      "Sent when one of a participant's drafted players finishes a game.",
    availablePlaceholders: [
      "{sportEmoji}",
      "{playerName}",
      "{fantasyPoints}",
      "{teamName}",
      "{slateLabel}",
    ],
  },
  slate_complete: {
    notificationType: "slate_complete",
    titleTemplate: "🏆 Slate Complete!",
    bodyTemplate:
      "{winnerName} wins with {winningScore} fantasy points. You finished {finishOrdinal} with {teamScore}.",
    description:
      "Sent to participants after a slate finishes and final standings are calculated.",
    availablePlaceholders: [
      "{winnerName}",
      "{winningScore}",
      "{teamName}",
      "{teamScore}",
      "{finishNumber}",
      "{finishOrdinal}",
      "{slateLabel}",
    ],
  },
  slate_complete_winner: {
    notificationType: "slate_complete_winner",
    titleTemplate: "🏆 You won!",
    bodyTemplate:
      "You won the {slateLabel} slate with {teamScore} fantasy points!",
    description:
      "Sent to the participant who wins a completed slate.",
    availablePlaceholders: [
      "{winnerName}",
      "{winningScore}",
      "{teamName}",
      "{teamScore}",
      "{finishNumber}",
      "{finishOrdinal}",
      "{slateLabel}",
    ],
  },
} as const;

const NFL_NOTIFICATION_DEFAULTS = {
  draft_turn: {
    ...NBA_NOTIFICATION_DEFAULTS.draft_turn,
    description:
      "Sent to the next participant after an NFL draft pick is submitted.",
  },
  draft_final_pick: {
    ...NBA_NOTIFICATION_DEFAULTS.draft_final_pick,
    description:
      "Sent when the next participant is making their final NFL draft pick.",
  },
  player_finished: {
    ...NBA_NOTIFICATION_DEFAULTS.player_finished,
    description:
      "Sent when one of a participant's drafted NFL players finishes a game.",
  },
  slate_complete: {
    ...NBA_NOTIFICATION_DEFAULTS.slate_complete,
    description:
      "Sent after an NFL slate finishes and final standings are calculated.",
  },
  slate_complete_winner: {
    ...NBA_NOTIFICATION_DEFAULTS.slate_complete_winner,
    description:
      "Sent to the participant who wins a completed NFL slate.",
  },
} as const;

const GOLF_NOTIFICATION_DEFAULTS = {
  draft_turn: {
    notificationType: "draft_turn",
    titleTemplate: "{sportEmoji} You're on the clock!",
    bodyTemplate:
      "{teamName}, it's your turn to make your {roundOrdinal} pick in {slateLabel}.",
    description:
      "Sent to the next participant after a Golf draft pick is submitted.",
    availablePlaceholders: [
      "{sportEmoji}",
      "{teamName}",
      "{slateLabel}",
      "{roundNumber}",
      "{roundOrdinal}",
      "{overallPickNumber}",
    ],
  },
  draft_final_pick: {
    notificationType: "draft_final_pick",
    titleTemplate: "{sportEmoji} Last pick!",
    bodyTemplate:
      "{teamName}, you're on the clock for the final pick of {slateLabel}.",
    description:
      "Sent when the next participant is making their final golfer selection.",
    availablePlaceholders: [
      "{sportEmoji}",
      "{teamName}",
      "{slateLabel}",
      "{roundNumber}",
      "{roundOrdinal}",
      "{overallPickNumber}",
    ],
  },
  player_finished: {
    notificationType: "player_finished",
    titleTemplate: "{sportEmoji} {playerName} finished!",
    bodyTemplate:
      "{playerName} completed Round {roundNumber} at {slateLabel} with a score of {roundScore}.",
    description:
      "Sent when one of a participant's drafted golfers completes a tournament round.",
    availablePlaceholders: [
      "{sportEmoji}",
      "{playerName}",
      "{roundNumber}",
      "{roundScore}",
      "{fantasyPoints}",
      "{teamName}",
      "{slateLabel}",
    ],
  },
  slate_complete: {
    notificationType: "slate_complete",
    titleTemplate: "🏆 Tournament Complete!",
    bodyTemplate:
      "{winnerName} wins {slateLabel} with {winningScore}. You finished {finishOrdinal} with {teamScore}.",
    description:
      "Sent after a Golf tournament finishes and final standings are calculated.",
    availablePlaceholders: [
      "{winnerName}",
      "{winningScore}",
      "{teamName}",
      "{teamScore}",
      "{finishNumber}",
      "{finishOrdinal}",
      "{slateLabel}",
    ],
  },
  slate_complete_winner: {
    notificationType: "slate_complete_winner",
    titleTemplate: "🏆 Tournament Winner!",
    bodyTemplate:
      "You won {slateLabel} with a score of {teamScore}!",
    description:
      "Sent to the participant who wins a completed Golf tournament.",
    availablePlaceholders: [
      "{winnerName}",
      "{winningScore}",
      "{teamName}",
      "{teamScore}",
      "{finishNumber}",
      "{finishOrdinal}",
      "{slateLabel}",
    ],
  },
} as const;

export const NOTIFICATION_TEMPLATE_DEFAULTS = {
  nba: NBA_NOTIFICATION_DEFAULTS,
  nfl: NFL_NOTIFICATION_DEFAULTS,
  golf: GOLF_NOTIFICATION_DEFAULTS,
} as const;

export type NotificationTemplateType =
  keyof typeof NBA_NOTIFICATION_DEFAULTS;

export type NotificationTemplate = {
  notificationType: NotificationTemplateType;
  sport: NotificationSport;
  titleTemplate: string;
  bodyTemplate: string;
  description: string;
  availablePlaceholders: string[];
};

type NotificationTemplateRow = {
  notification_type: string;
  sport: string;
  title_template: string;
  body_template: string;
  description: string | null;
  available_placeholders: string[] | null;
};

export function normalizeNotificationSport(
  value: unknown
): NotificationSport {
  if (value === "nfl") return "nfl";
  if (value === "golf") return "golf";

  return "nba";
}

export function isNotificationSport(
  value: unknown
): value is NotificationSport {
  return value === "nba" || value === "nfl" || value === "golf";
}

export function isNotificationTemplateType(
  value: unknown
): value is NotificationTemplateType {
  return (
    typeof value === "string" &&
    value in NBA_NOTIFICATION_DEFAULTS
  );
}

export function renderNotificationTemplate(
  template: string,
  values: Record<string, string | number | null | undefined>
) {
  return Object.entries(values).reduce((result, [key, value]) => {
    const replacement = value == null ? "" : String(value);

    return result.replaceAll(`{${key}}`, replacement);
  }, template);
}

export function getDefaultNotificationTemplate(
  notificationType: NotificationTemplateType,
  sport: NotificationSport = "nba"
): NotificationTemplate {
  const template =
    NOTIFICATION_TEMPLATE_DEFAULTS[sport][notificationType];

  return {
    notificationType,
    sport,
    titleTemplate: template.titleTemplate,
    bodyTemplate: template.bodyTemplate,
    description: template.description,
    availablePlaceholders: [...template.availablePlaceholders],
  };
}

export async function getNotificationTemplate(
  notificationType: NotificationTemplateType,
  sport: NotificationSport = "nba"
): Promise<NotificationTemplate> {
  const fallback = getDefaultNotificationTemplate(
    notificationType,
    sport
  );

  const { data, error } = await supabaseAdmin
    .from("notification_templates")
    .select(
      `
        notification_type,
        sport,
        title_template,
        body_template,
        description,
        available_placeholders
      `
    )
    .eq("notification_type", notificationType)
    .eq("sport", sport)
    .maybeSingle();

  if (error) {
    console.error("Failed to load notification template", {
      notificationType,
      sport,
      error,
    });

    return fallback;
  }

  const row = data as NotificationTemplateRow | null;

  if (!row) {
    return fallback;
  }

  return {
    notificationType,
    sport,
    titleTemplate:
      row.title_template?.trim() || fallback.titleTemplate,
    bodyTemplate:
      row.body_template?.trim() || fallback.bodyTemplate,
    description:
      row.description?.trim() || fallback.description,
    availablePlaceholders:
      row.available_placeholders?.length
        ? row.available_placeholders
        : fallback.availablePlaceholders,
  };
}
