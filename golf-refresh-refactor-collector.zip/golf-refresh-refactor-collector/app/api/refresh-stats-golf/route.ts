import { NextResponse } from "next/server";
import { getCurrentUser } from "@/lib/auth";
import { supabaseAdmin } from "@/lib/supabaseAdmin";
import { notifyNewlyFinishedPlayers } from "@/lib/playerFinishedNotifications";
import { notifyCompletedSlate } from "@/lib/slateCompleteNotifications";
import {
  fetchGolfCoursesByEventId,
  fetchGolfTournamentByEventId,
  parseGolfTournamentByEventIdFromPayload,
  type GolfCompetitor,
  type GolfCompetitorStatus,
  type GolfRound,
  type GolfTournament,
} from "@/lib/providers/golf";

type RefreshBody = {
  slateId?: number | string;
  scoreboardPayload?: unknown;
};

type GolfSlateRecord = {
  id: number;
  sport: string;
  display_name: string | null;
  external_event_id: string | null;
  start_date: string;
  end_date: string;
  is_locked: boolean;
  cut_penalty_per_round: number | null;
};

type GolfPlayerIdRow = {
  id: number;
  display_name?: string;
  espn_player_id: string;
};

type GolfEventPlayerIdRow = {
  id: number;
  player_id: number;
};

type GolfRoundIdRow = {
  id: number;
  event_player_id: number;
  round_number: number;
};

type DatabaseError = {
  message: string;
};

const EXPECTED_TOURNAMENT_ROUNDS = 4;
const INSERT_BATCH_SIZE = 750;

function parseSlateId(value: unknown): number | null {
  const parsed = Number(value);

  if (!Number.isInteger(parsed) || parsed <= 0) {
    return null;
  }

  return parsed;
}

function getTournamentYear(startDate: string): string | null {
  const year = startDate.slice(0, 4);
  return /^\d{4}$/.test(year) ? year : null;
}

function deduplicateCompetitors(
  competitors: GolfCompetitor[],
): GolfCompetitor[] {
  return Array.from(
    new Map(
      competitors.map((competitor) => [competitor.espnPlayerId, competitor]),
    ).values(),
  );
}

function chunkRows<T>(rows: T[], size: number): T[][] {
  const chunks: T[][] = [];

  for (let index = 0; index < rows.length; index += size) {
    chunks.push(rows.slice(index, index + size));
  }

  return chunks;
}

function getRoundStatus(
  round: GolfRound,
  tournamentStatus: GolfTournament["status"],
): "scheduled" | "active" | "finished" | "not_played" {
  if (round.holesCompleted === 18) {
    return "finished";
  }

  if (round.holesCompleted > 0) {
    return "active";
  }

  if (round.strokes !== null && round.strokes > 0) {
    return "active";
  }

  return tournamentStatus === "scheduled" ? "scheduled" : "not_played";
}

function calculatePenaltyStrokes(input: {
  status: GolfCompetitorStatus;
  roundsCompleted: number;
  penaltyPerRound: number;
}): number {
  if (input.penaltyPerRound <= 0) {
    return 0;
  }

  const receivesMissingRoundPenalty = [
    "cut",
    "withdrawn",
    "disqualified",
  ].includes(input.status);

  if (!receivesMissingRoundPenalty) {
    return 0;
  }

  const missedRounds = Math.max(
    0,
    EXPECTED_TOURNAMENT_ROUNDS - input.roundsCompleted,
  );

  return missedRounds * input.penaltyPerRound;
}

async function fetchTournamentForSlate(
  slate: GolfSlateRecord,
  scoreboardPayload?: unknown,
): Promise<GolfTournament | null> {
  const eventId =
    slate.external_event_id?.trim();

  if (!eventId) {
    return null;
  }

  if (
    scoreboardPayload !==
    undefined
  ) {
    return parseGolfTournamentByEventIdFromPayload(
      scoreboardPayload,
      eventId,
    );
  }

  const tournamentYear =
    getTournamentYear(
      slate.start_date,
    );

  if (tournamentYear) {
    const tournament =
      await fetchGolfTournamentByEventId(
        eventId,
        tournamentYear,
      );

    if (tournament) {
      return tournament;
    }
  }

  return fetchGolfTournamentByEventId(
    eventId,
  );
}

async function insertInBatches(
  table: string,
  rows: Record<string, unknown>[],
): Promise<DatabaseError | null> {
  for (const batch of chunkRows(rows, INSERT_BATCH_SIZE)) {
    const { error } = await supabaseAdmin.from(table).insert(batch);

    if (error) {
      return {
        message: error.message,
      };
    }
  }

  return null;
}

export async function POST(request: Request) {
  try {
    let body: RefreshBody;

    try {
      body = (await request.json()) as RefreshBody;
    } catch {
      return NextResponse.json(
        {
          error: "A valid JSON request body is required.",
        },
        { status: 400 },
      );
    }

    const slateId =
      parseSlateId(body.slateId);

    const isPayloadIngestion =
      body.scoreboardPayload !==
      undefined;

    if (isPayloadIngestion) {
      const expectedSecret =
        process.env
          .GOLF_CRON_SECRET
          ?.trim();

      const authorization =
        request.headers.get(
          "authorization",
        );

      const hasCronAuthorization =
        Boolean(
          expectedSecret &&
          authorization ===
            `Bearer ${expectedSecret}`,
        );

      const currentUser =
        hasCronAuthorization
          ? null
          : await getCurrentUser();

      if (
        !hasCronAuthorization &&
        !currentUser
      ) {
        return NextResponse.json(
          {
            error: "Login required.",
          },
          {
            status: 401,
          },
        );
      }
    }

    if (!slateId) {
      return NextResponse.json(
        { error: "A valid slateId is required." },
        { status: 400 },
      );
    }

    const { data: slateData, error: slateError } = await supabaseAdmin
      .from("slates")
      .select(
        [
          "id",
          "sport",
          "display_name",
          "external_event_id",
          "start_date",
          "end_date",
          "is_locked",
          "cut_penalty_per_round",
        ].join(","),
      )
      .eq("id", slateId)
      .single();

    if (slateError || !slateData) {
      return NextResponse.json({ error: "Slate not found." }, { status: 404 });
    }

    const slate = slateData as unknown as GolfSlateRecord;

    if (slate.sport !== "golf") {
      return NextResponse.json(
        {
          error: "This slate is not a Golf slate.",
        },
        { status: 400 },
      );
    }

    if (slate.is_locked) {
      return NextResponse.json(
        {
          error: "This slate is locked and cannot be refreshed.",
        },
        { status: 400 },
      );
    }

    if (!slate.external_event_id?.trim()) {
      return NextResponse.json(
        {
          error: "This Golf slate does not have an ESPN external event ID.",
        },
        { status: 400 },
      );
    }

    const tournament =
      await fetchTournamentForSlate(
        slate,
        body.scoreboardPayload,
      );

    if (!tournament) {
      return NextResponse.json(
        {
          error: `ESPN tournament ${slate.external_event_id} was not found.`,
        },
        { status: 404 },
      );
    }

    const competitors = deduplicateCompetitors(tournament.competitors);

    if (competitors.length === 0) {
      return NextResponse.json(
        {
          error:
            "ESPN returned the tournament, but the tournament field is not available yet.",
          tournament: {
            eventId: tournament.espnEventId,
            name: tournament.name,
            status: tournament.status,
          },
        },
        { status: 502 },
      );
    }

    const refreshedAt = new Date().toISOString();

    let courseHolesUpserted = 0;

    try {
      const courses =
        isPayloadIngestion
          ? []
          : await fetchGolfCoursesByEventId(
        slate.external_event_id ?? "",
      );

      const courseRows = courses.flatMap((course) =>
        course.holes.map((hole) => ({
          slate_id: slateId,
          course_id: course.espnCourseId,
          course_name: course.name,
          is_host: course.isHost,
          hole_number: hole.holeNumber,
          par: hole.par,
          yards: hole.yards,
          updated_at: refreshedAt,
        })),
      );

      if (courseRows.length > 0) {
        const { error: courseDeleteError } =
          await supabaseAdmin
            .from("golf_course_holes")
            .delete()
            .eq("slate_id", slateId);

        if (courseDeleteError) {
          throw new Error(courseDeleteError.message);
        }

        const { error: courseUpsertError } =
          await supabaseAdmin
            .from("golf_course_holes")
            .upsert(courseRows, {
              onConflict:
                "slate_id,course_id,hole_number",
            });

        if (courseUpsertError) {
          throw new Error(courseUpsertError.message);
        }

        courseHolesUpserted = courseRows.length;
      }
    } catch (courseError) {
      console.error(
        "Golf player data will refresh, but course-hole data could not be saved:",
        courseError,
      );
    }
    const penaltyPerRound = Math.max(0, slate.cut_penalty_per_round ?? 0);

    const golfPlayerRows = competitors.map((competitor) => ({
      espn_player_id: competitor.espnPlayerId,
      display_name: competitor.displayName,
      short_name: competitor.shortName,
      country: competitor.country,
      country_flag_url: competitor.countryFlagUrl,
      player_url: competitor.playerUrl,
      headshot_url:
        `https://a.espncdn.com/i/headshots/golf/players/full/` +
        `${competitor.espnPlayerId}.png`,
      is_active: true,
      updated_at: refreshedAt,
    }));

    function normalizeGolfName(value: string) {
      return value
        .normalize("NFD")
        .replace(/\p{Diacritic}/gu, "")
        .toLowerCase()
        .replace(/\b(jr|sr|ii|iii|iv)\b/g, "")
        .replace(/&/g, "and")
        .replace(/[^a-z0-9]+/g, " ")
        .trim()
        .replace(/\s+/g, " ");
    }

    /*
     * Pre-draft field imports may create temporary `pga:*`
     * identities before ESPN publishes its competitor feed.
     *
     * Reconcile those records by normalized name so existing
     * drafted player IDs are preserved instead of creating
     * duplicate ESPN player records.
     */
    const {
      data: existingGolfPlayerData,
      error: existingGolfPlayerError,
    } = await supabaseAdmin
      .from("golf_players")
      .select(
        "id, display_name, espn_player_id",
      );

    if (existingGolfPlayerError) {
      return NextResponse.json(
        {
          error:
            "The tournament field was available, but existing Golf players could not be loaded: " +
            existingGolfPlayerError.message,
        },
        { status: 500 },
      );
    }

    const existingGolfPlayers =
      (existingGolfPlayerData ??
        []) as unknown as GolfPlayerIdRow[];

    const existingByEspnId =
      new Map(
        existingGolfPlayers.map(
          (player) => [
            String(
              player.espn_player_id,
            ),
            player,
          ],
        ),
      );

    const existingByNormalizedName =
      new Map<
        string,
        GolfPlayerIdRow[]
      >();

    for (
      const player of existingGolfPlayers
    ) {
      const normalizedName =
        normalizeGolfName(
          String(
            player.display_name ?? "",
          ),
        );

      if (!normalizedName) {
        continue;
      }

      const rows =
        existingByNormalizedName.get(
          normalizedName,
        ) ?? [];

      rows.push(player);

      existingByNormalizedName.set(
        normalizedName,
        rows,
      );
    }

    const playerIdByEspnId =
      new Map<string, number>();

    const rowsToUpsert:
      typeof golfPlayerRows = [];

    for (
      const competitor of competitors
    ) {
      const existingById =
        existingByEspnId.get(
          competitor.espnPlayerId,
        );

      if (existingById) {
        playerIdByEspnId.set(
          competitor.espnPlayerId,
          Number(existingById.id),
        );

        rowsToUpsert.push(
          golfPlayerRows.find(
            (row) =>
              row.espn_player_id ===
              competitor.espnPlayerId,
          )!,
        );

        continue;
      }

      const nameMatches =
        existingByNormalizedName.get(
          normalizeGolfName(
            competitor.displayName,
          ),
        ) ?? [];

      const syntheticMatch =
        nameMatches.length === 1 &&
        String(
          nameMatches[0]
            .espn_player_id,
        ).startsWith("pga:")
          ? nameMatches[0]
          : null;

      if (syntheticMatch) {
        const {
          error:
            reconciliationError,
        } = await supabaseAdmin
          .from("golf_players")
          .update({
            espn_player_id:
              competitor.espnPlayerId,
            display_name:
              competitor.displayName,
            short_name:
              competitor.shortName,
            country:
              competitor.country,
            country_flag_url:
              competitor.countryFlagUrl,
            player_url:
              competitor.playerUrl,
            headshot_url:
              `https://a.espncdn.com/i/headshots/golf/players/full/` +
              `${competitor.espnPlayerId}.png`,
            is_active: true,
            updated_at:
              refreshedAt,
          })
          .eq(
            "id",
            syntheticMatch.id,
          );

        if (reconciliationError) {
          return NextResponse.json(
            {
              error:
                `Could not reconcile ${competitor.displayName} ` +
                `from PGA TOUR to ESPN: ` +
                reconciliationError.message,
            },
            { status: 500 },
          );
        }

        playerIdByEspnId.set(
          competitor.espnPlayerId,
          Number(
            syntheticMatch.id,
          ),
        );

        continue;
      }

      rowsToUpsert.push(
        golfPlayerRows.find(
          (row) =>
            row.espn_player_id ===
            competitor.espnPlayerId,
        )!,
      );
    }

    let savedPlayers: GolfPlayerIdRow[] =
      [];

    if (rowsToUpsert.length > 0) {
      const {
        data: savedPlayersData,
        error: playersUpsertError,
      } = await supabaseAdmin
        .from("golf_players")
        .upsert(rowsToUpsert, {
          onConflict:
            "espn_player_id",
        })
        .select(
          "id, display_name, espn_player_id",
        );

      if (playersUpsertError) {
        return NextResponse.json(
          {
            error:
              `Failed to save Golf players: ` +
              playersUpsertError.message,
          },
          { status: 500 },
        );
      }

      savedPlayers =
        (savedPlayersData ??
          []) as unknown as GolfPlayerIdRow[];

      for (
        const player of savedPlayers
      ) {
        playerIdByEspnId.set(
          player.espn_player_id,
          Number(player.id),
        );
      }
    }

    const unresolvedCompetitors = competitors.filter(
      (competitor) => !playerIdByEspnId.has(competitor.espnPlayerId),
    );

    if (unresolvedCompetitors.length > 0) {
      return NextResponse.json(
        {
          error:
            "Golf players were saved, but one or more database player IDs could not be resolved.",
          unresolvedPlayers: unresolvedCompetitors.map((competitor) => ({
            espnPlayerId: competitor.espnPlayerId,
            displayName: competitor.displayName,
          })),
        },
        { status: 500 },
      );
    }

    const playerIds = Array.from(
      playerIdByEspnId.values(),
    );

    const {
      data: previousEventPlayerData,
      error: previousEventPlayerError,
    } = playerIds.length > 0
      ? await supabaseAdmin
          .from("golf_event_players")
          .select(
            "player_id, rounds_completed, status",
          )
          .eq("slate_id", slateId)
          .in("player_id", playerIds)
      : {
          data: [],
          error: null,
        };

    if (previousEventPlayerError) {
      return NextResponse.json(
        {
          error:
            "Golf players were loaded, but their previous progress could not be read: " +
            previousEventPlayerError.message,
        },
        { status: 500 },
      );
    }

    const previousGolfProgressByPlayerId =
      new Map<
        number,
        {
          roundsCompleted: number;
          status: string | null;
        }
      >(
        (previousEventPlayerData ?? []).map(
          (row) => [
            Number(row.player_id),
            {
              roundsCompleted: Number(
                row.rounds_completed ?? 0,
              ),
              status:
                row.status == null
                  ? null
                  : String(row.status),
            },
          ],
        ),
      );

    const eventPlayerRows = competitors.map((competitor) => {
      const penaltyStrokes = calculatePenaltyStrokes({
        status: competitor.status,
        roundsCompleted: competitor.roundsCompleted,
        penaltyPerRound,
      });

      const fantasyScore =
        competitor.officialScoreToPar === null
          ? null
          : competitor.officialScoreToPar + penaltyStrokes;

      return {
        slate_id: slateId,
        player_id: playerIdByEspnId.get(competitor.espnPlayerId)!,
        leaderboard_order: competitor.leaderboardOrder,
        official_score_to_par: competitor.officialScoreToPar,
        official_score_display: competitor.officialScoreDisplay,
        penalty_strokes: penaltyStrokes,
        fantasy_score: fantasyScore,
        rounds_completed: competitor.roundsCompleted,
        holes_completed: competitor.holesCompleted,
        current_round: competitor.currentRound,
        last_hole: competitor.lastHole,
        status: competitor.status,
        tee_time: competitor.teeTime,
        tee_time_raw: competitor.teeTimeRaw,
        updated_at: refreshedAt,
      };
    });

    const { data: eventPlayersData, error: eventPlayersUpsertError } =
      await supabaseAdmin
        .from("golf_event_players")
        .upsert(eventPlayerRows, {
          onConflict: "slate_id,player_id",
        })
        .select("id, player_id");

    if (eventPlayersUpsertError) {
      return NextResponse.json(
        {
          error:
            "Golf players were saved, but the tournament field could not be linked to the slate: " +
            eventPlayersUpsertError.message,
        },
        { status: 500 },
      );
    }

    const eventPlayers = (eventPlayersData ?? []) as GolfEventPlayerIdRow[];

    const eventPlayerIdByPlayerId = new Map(
      eventPlayers.map((eventPlayer) => [
        Number(eventPlayer.player_id),
        Number(eventPlayer.id),
      ]),
    );

    const unresolvedEventPlayers = competitors.filter((competitor) => {
      const playerId = playerIdByEspnId.get(competitor.espnPlayerId);

      return playerId === undefined || !eventPlayerIdByPlayerId.has(playerId);
    });

    if (unresolvedEventPlayers.length > 0) {
      return NextResponse.json(
        {
          error:
            "Tournament players were linked to the slate, but one or more event-player IDs could not be resolved.",
          unresolvedPlayers: unresolvedEventPlayers.map(
            (competitor) => competitor.displayName,
          ),
        },
        { status: 500 },
      );
    }

    const eventPlayerIds = eventPlayers.map((eventPlayer) =>
      Number(eventPlayer.id),
    );

    const { data: existingRoundsData, error: existingRoundsError } =
      await supabaseAdmin
        .from("golf_rounds")
        .select("id")
        .in("event_player_id", eventPlayerIds);

    if (existingRoundsError) {
      return NextResponse.json(
        {
          error:
            "Tournament players were saved, but existing Golf rounds could not be read: " +
            existingRoundsError.message,
        },
        { status: 500 },
      );
    }

    const existingRoundIds = (existingRoundsData ?? []).map((round) =>
      Number(round.id),
    );

    if (existingRoundIds.length > 0) {
      const { error: holesDeleteError } = await supabaseAdmin
        .from("golf_holes")
        .delete()
        .in("round_id", existingRoundIds);

      if (holesDeleteError) {
        return NextResponse.json(
          {
            error:
              "Existing Golf holes could not be cleared: " +
              holesDeleteError.message,
          },
          { status: 500 },
        );
      }
    }

    const { error: roundsDeleteError } = await supabaseAdmin
      .from("golf_rounds")
      .delete()
      .in("event_player_id", eventPlayerIds);

    if (roundsDeleteError) {
      return NextResponse.json(
        {
          error:
            "Existing Golf rounds could not be cleared: " +
            roundsDeleteError.message,
        },
        { status: 500 },
      );
    }

    const roundRows = competitors.flatMap((competitor) => {
      const playerId = playerIdByEspnId.get(competitor.espnPlayerId)!;

      const eventPlayerId = eventPlayerIdByPlayerId.get(playerId)!;

      /*
       * Before play begins, PGA may return the golfer in the
       * tournament field without returning any round objects.
       *
       * Preserve a scheduled round so the scorecard can show
       * all 18 holes and open the pre-round ShotCast layouts.
       * No golf_holes rows are created until real scoring data
       * arrives.
       */
      if (competitor.rounds.length === 0) {
        const scheduledRoundNumber = Math.min(
          4,
          Math.max(
            1,
            Number(
              competitor.currentRound ??
                competitor.roundsCompleted + 1,
            ),
          ),
        );

        return [
          {
            event_player_id: eventPlayerId,
            round_number: scheduledRoundNumber,
            score_to_par: null,
            score_display: null,
            strokes: null,
            holes_completed: 0,
            tee_time: competitor.teeTime,
            tee_time_raw: competitor.teeTimeRaw,
            status: "scheduled" as const,
            updated_at: refreshedAt,
          },
        ];
      }

      return competitor.rounds.map((round) => ({
        event_player_id: eventPlayerId,
        round_number: round.roundNumber,
        score_to_par: round.scoreToPar,
        score_display: round.scoreDisplay,
        strokes: round.strokes,
        holes_completed: round.holesCompleted,
        tee_time: round.teeTime,
        tee_time_raw: round.teeTimeRaw,
        status: getRoundStatus(round, tournament.status),
        updated_at: refreshedAt,
      }));
    });

    let savedRounds: GolfRoundIdRow[] = [];

    for (const batch of chunkRows(roundRows, INSERT_BATCH_SIZE)) {
      const { data: insertedRoundsData, error: roundsInsertError } =
        await supabaseAdmin
          .from("golf_rounds")
          .insert(batch)
          .select("id, event_player_id, round_number");

      if (roundsInsertError) {
        return NextResponse.json(
          {
            error:
              "Golf rounds could not be saved: " + roundsInsertError.message,
          },
          { status: 500 },
        );
      }

      savedRounds = savedRounds.concat(
        (insertedRoundsData ?? []) as GolfRoundIdRow[],
      );
    }

    const roundIdByKey = new Map(
      savedRounds.map((round) => [
        `${round.event_player_id}:${round.round_number}`,
        Number(round.id),
      ]),
    );

    const holeRows = competitors.flatMap((competitor) => {
      const playerId = playerIdByEspnId.get(competitor.espnPlayerId)!;

      const eventPlayerId = eventPlayerIdByPlayerId.get(playerId)!;

      return competitor.rounds.flatMap((round) => {
        const roundId = roundIdByKey.get(
          `${eventPlayerId}:${round.roundNumber}`,
        );

        if (roundId === undefined) {
          return [];
        }

        return round.holes.map((hole) => ({
          round_id: roundId,
          hole_number: hole.holeNumber,
          strokes: hole.strokes,
          relative_to_par: hole.relativeToPar,
          score_display: hole.scoreDisplay,
          updated_at: refreshedAt,
        }));
      });
    });

    const holesInsertError = await insertInBatches("golf_holes", holeRows);

    if (holesInsertError) {
      return NextResponse.json(
        {
          error: "Golf holes could not be saved: " + holesInsertError.message,
        },
        { status: 500 },
      );
    }

    const statusCounts = competitors.reduce<
      Record<GolfCompetitorStatus, number>
    >(
      (counts, competitor) => {
        counts[competitor.status] += 1;
        return counts;
      },
      {
        scheduled: 0,
        active: 0,
        round_complete: 0,
        finished: 0,
        cut: 0,
        withdrawn: 0,
        disqualified: 0,
        did_not_start: 0,
      },
    );

    const { data: lineupsData, error: lineupsError } =
      await supabaseAdmin
        .from("lineups")
        .select(
          `
          id,
          team_id,
          lineup_players (
            player_id
          )
        `,
        )
        .eq("slate_id", slateId);

    if (lineupsError) {
      return NextResponse.json(
        {
          error:
            "Golf data was refreshed, but fantasy lineups could not be loaded: " +
            lineupsError.message,
        },
        { status: 500 },
      );
    }

    let playerFinishedNotifications = {
      attempted: 0,
      sent: 0,
      skipped: 0,
      failed: 0,
    };

    try {
      const newlyCompletedRounds =
        competitors
          .map((competitor) => {
            const playerId =
              playerIdByEspnId.get(
                competitor.espnPlayerId,
              );

            if (playerId === undefined) {
              return null;
            }

            const previous =
              previousGolfProgressByPlayerId.get(
                playerId,
              ) ?? {
                roundsCompleted: 0,
                status: null,
              };

            const currentCompleted =
              Number(
                competitor.roundsCompleted ?? 0,
              );

            const completedAnotherRound =
              currentCompleted >
              previous.roundsCompleted;

            /*
             * Repair the currently stored bad transition:
             *
             * active after Hole 18
             *          ↓
             * round_complete
             *
             * This allows the first refresh after this fix to send
             * the missed Round 3 notification.
             */
            const repairedCompletedRound =
              previous.status === "active" &&
              competitor.status ===
                "round_complete" &&
              currentCompleted > 0;

            if (
              !completedAnotherRound &&
              !repairedCompletedRound
            ) {
              return null;
            }

            const completedRound =
              competitor.rounds.find(
                (round) =>
                  Number(
                    round.roundNumber,
                  ) === currentCompleted,
              ) ?? null;

            return {
              playerId,
              roundNumber:
                currentCompleted,
              roundScore:
                completedRound?.scoreToPar ??
                null,
              fantasyPoints:
                competitor.officialScoreToPar,
            };
          })
          .filter(
            (
              row,
            ): row is {
              playerId: number;
              roundNumber: number;
              roundScore: number | null;
              fantasyPoints: number | null;
            } => row !== null,
          );

      playerFinishedNotifications =
        await notifyNewlyFinishedPlayers({
          slate: {
            id: slate.id,
            date: slate.start_date,
            start_date:
              slate.start_date,
            end_date:
              slate.end_date,
            sport: "golf",
            display_name:
              slate.display_name?.trim() ||
              tournament.name,
          },
          players: competitors.map(
            (competitor) => ({
              id:
                playerIdByEspnId.get(
                  competitor.espnPlayerId,
                )!,
              name:
                competitor.displayName,
            }),
          ),
          lineups:
            (lineupsData ?? []).map(
              (lineup: any) => ({
                team_id:
                  Number(lineup.team_id),
                lineup_players:
                  lineup.lineup_players ??
                  [],
              }),
            ),
          previousStatuses:
            newlyCompletedRounds.map(
              (row) => ({
                playerId:
                  row.playerId,
                gameStatus: 2,
              }),
            ),
          currentStats:
            newlyCompletedRounds.map(
              (row) => ({
                player_id:
                  row.playerId,
                fantasy_points:
                  row.fantasyPoints,
                game_status: 3,
                round_number:
                  row.roundNumber,
                round_score:
                  row.roundScore,
                event_key_suffix:
                  `round-${row.roundNumber}`,
              }),
            ),
        });
    } catch (notificationError) {
      console.error(
        "Golf stats saved, but round-complete notifications failed",
        notificationError,
      );
    }

    const eventRowByPlayerId = new Map(
      eventPlayerRows.map((row) => [
        Number(row.player_id),
        row,
      ]),
    );

    const competitorByPlayerId = new Map(
      competitors.map((competitor) => {
        const playerId = playerIdByEspnId.get(
          competitor.espnPlayerId,
        );

        return [
          Number(playerId),
          competitor,
        ] as const;
      }),
    );

    const { data: slateTeamData, error: slateTeamError } =
      await supabaseAdmin
        .from("slate_teams")
        .select("team_id, draft_order")
        .eq("slate_id", slateId);

    if (slateTeamError) {
      return NextResponse.json(
        {
          error:
            "Golf data was refreshed, but draft-order tiebreak data could not be loaded: " +
            slateTeamError.message,
        },
        { status: 500 },
      );
    }

    const draftOrderByTeamId = new Map(
      (slateTeamData ?? []).map((row) => [
        Number(row.team_id),
        Number(row.draft_order ?? 999),
      ]),
    );

    const teamResultRows = (lineupsData ?? []).map((lineup: any) => {
      const playerIds = (lineup.lineup_players ?? []).map(
        (row: any) => Number(row.player_id),
      );

      const golferRows = playerIds
        .map((playerId: number) => eventRowByPlayerId.get(playerId))
        .filter(Boolean) as typeof eventPlayerRows;

      const fantasyPoints = golferRows.reduce(
        (sum, row) => sum + Number(row.fantasy_score ?? 0),
        0,
      );

      const completedStatuses = new Set([
        "round_complete",
        "finished",
        "cut",
        "withdrawn",
        "disqualified",
      ]);

      const gamesCompleted = golferRows.filter((row) =>
        completedStatuses.has(String(row.status)),
      ).length;

      const gamesInProgress = golferRows.filter(
        (row) => row.status === "active",
      ).length;

      const gamesRemaining = golferRows.filter((row) =>
        ["scheduled", "did_not_start"].includes(String(row.status)),
      ).length;

      const golferCompetitors = playerIds
        .map((playerId: number) =>
          competitorByPlayerId.get(playerId),
        )
        .filter(Boolean);

      const completedIndividualRounds =
        golferCompetitors.flatMap((competitor: any) =>
          (competitor.rounds ?? [])
            .filter(
              (round: any) =>
                Number(round.holesCompleted ?? 0) >= 18 &&
                round.scoreToPar !== null &&
                round.scoreToPar !== undefined,
            )
            .map((round: any) => ({
              roundNumber: Number(round.roundNumber),
              score: Number(round.scoreToPar),
            })),
        );

      const bestIndividualRound =
        completedIndividualRounds.length > 0
          ? Math.min(
              ...completedIndividualRounds.map(
                (round: any) => round.score,
              ),
            )
          : Number.POSITIVE_INFINITY;

      const teamRoundScores: number[] = [];

      for (const roundNumber of [1, 2, 3, 4]) {
        const roundScores = golferCompetitors
          .map((competitor: any) =>
            (competitor.rounds ?? []).find(
              (round: any) =>
                Number(round.roundNumber) === roundNumber &&
                Number(round.holesCompleted ?? 0) >= 18 &&
                round.scoreToPar !== null &&
                round.scoreToPar !== undefined,
            ),
          )
          .filter(Boolean)
          .map((round: any) =>
            Number(round.scoreToPar),
          );

        // A team round counts only after every drafted golfer has
        // completed that round.
        if (
          golferCompetitors.length > 0 &&
          roundScores.length === golferCompetitors.length
        ) {
          teamRoundScores.push(
            roundScores.reduce(
              (sum: number, score: number) =>
                sum + score,
              0,
            ),
          );
        }
      }

      const bestTeamRound =
        teamRoundScores.length > 0
          ? Math.min(...teamRoundScores)
          : Number.POSITIVE_INFINITY;

      const playedHoles =
        golferCompetitors.flatMap((competitor: any) =>
          (competitor.rounds ?? []).flatMap(
            (round: any) => round.holes ?? [],
          ),
        );

      const birdiesOrBetter = playedHoles.filter(
        (hole: any) =>
          hole.relativeToPar !== null &&
          hole.relativeToPar !== undefined &&
          Number(hole.relativeToPar) <= -1,
      ).length;

      const bogeysOrWorse = playedHoles.filter(
        (hole: any) =>
          hole.relativeToPar !== null &&
          hole.relativeToPar !== undefined &&
          Number(hole.relativeToPar) >= 1,
      ).length;

      return {
        slate_id: slateId,
        team_id: Number(lineup.team_id),
        fantasy_points: fantasyPoints,
        finish_position: null as number | null,
        games_completed: gamesCompleted,
        games_in_progress: gamesInProgress,
        games_remaining: gamesRemaining,

        _tiebreak: {
          bestTeamRound,
          bestIndividualRound,
          birdiesOrBetter,
          bogeysOrWorse,
          draftOrder:
            draftOrderByTeamId.get(
              Number(lineup.team_id),
            ) ?? 999,
        },
      };
    });

    const compareGolfTeams = (
      a: (typeof teamResultRows)[number],
      b: (typeof teamResultRows)[number],
    ) => {
      // Lower tournament score wins.
      if (a.fantasy_points !== b.fantasy_points) {
        return a.fantasy_points - b.fantasy_points;
      }

      // 1. Lowest completed team round.
      if (
        a._tiebreak.bestTeamRound !==
        b._tiebreak.bestTeamRound
      ) {
        return (
          a._tiebreak.bestTeamRound -
          b._tiebreak.bestTeamRound
        );
      }

      // 2. Lowest completed individual golfer round.
      if (
        a._tiebreak.bestIndividualRound !==
        b._tiebreak.bestIndividualRound
      ) {
        return (
          a._tiebreak.bestIndividualRound -
          b._tiebreak.bestIndividualRound
        );
      }

      // 3. Most birdies or better.
      if (
        a._tiebreak.birdiesOrBetter !==
        b._tiebreak.birdiesOrBetter
      ) {
        return (
          b._tiebreak.birdiesOrBetter -
          a._tiebreak.birdiesOrBetter
        );
      }

      // 4. Fewest bogeys or worse.
      if (
        a._tiebreak.bogeysOrWorse !==
        b._tiebreak.bogeysOrWorse
      ) {
        return (
          a._tiebreak.bogeysOrWorse -
          b._tiebreak.bogeysOrWorse
        );
      }

      // 5. Earlier draft position guarantees a stable result.
      if (
        a._tiebreak.draftOrder !==
        b._tiebreak.draftOrder
      ) {
        return (
          a._tiebreak.draftOrder -
          b._tiebreak.draftOrder
        );
      }

      return a.team_id - b.team_id;
    };

    const rankedTeamRows =
      [...teamResultRows].sort(compareGolfTeams);

    rankedTeamRows.forEach((row, index) => {
      row.finish_position = index + 1;
    });

    const persistedTeamRows = rankedTeamRows.map(
      ({ _tiebreak, ...row }) => row,
    );

    if (persistedTeamRows.length > 0) {
      const { error: teamResultsError } = await supabaseAdmin
        .from("team_slate_results")
        .upsert(persistedTeamRows, {
          onConflict: "slate_id,team_id",
        });

      if (teamResultsError) {
        return NextResponse.json(
          {
            error:
              "Golf data was refreshed, but fantasy team totals could not be saved: " +
              teamResultsError.message,
          },
          { status: 500 },
        );
      }
    }

    let slateAutoLocked = false;

    let slateCompleteNotifications = {
      attempted: 0,
      sent: 0,
      skipped: 0,
      failed: 0,
    };

    /*
     * A tournament is settled when ESPN explicitly reports Final,
     * or when there are no golfers still scheduled, active, or
     * waiting between rounds and at least one golfer has finished.
     *
     * Cut, WD, DQ, and DNS golfers are terminal states.
     */
    const tournamentFieldIsSettled =
      statusCounts.scheduled === 0 &&
      statusCounts.active === 0 &&
      statusCounts.round_complete === 0 &&
      statusCounts.finished > 0;

    const tournamentIsComplete =
      tournament.completed ||
      tournament.status === "final" ||
      tournamentFieldIsSettled;

    if (tournamentIsComplete) {
      /*
       * Send notifications before locking. If notification processing
       * throws unexpectedly, leave the slate open so the next cron run
       * can retry instead of permanently losing the final alert.
       *
       * sendLoggedNotification's event keys prevent duplicate pushes.
       */
      try {
        slateCompleteNotifications =
          await notifyCompletedSlate({
            slate: {
              id: slate.id,
              date: slate.start_date,
              start_date:
                slate.start_date,
              end_date:
                slate.end_date,
              sport: "golf",
              display_name:
                slate.display_name?.trim() ||
                tournament.name,
            } as any,
            teamResults:
              persistedTeamRows.map(
                (row) => ({
                  team_id:
                    Number(row.team_id),
                  fantasy_points:
                    Number(
                      row.fantasy_points ?? 0,
                    ),
                  finish_position:
                    row.finish_position,
                }),
              ),
          });
      } catch (notificationError) {
        console.error(
          "Golf tournament is final, but final notifications failed",
          notificationError,
        );

        return NextResponse.json(
          {
            error:
              "Golf results were saved, but final notifications failed. " +
              "The slate was left open so the next refresh can retry.",
            slateId,
          },
          { status: 500 },
        );
      }

      const {
        error: lockError,
      } = await supabaseAdmin
        .from("slates")
        .update({
          is_locked: true,
        })
        .eq("id", slateId)
        .eq("is_locked", false);

      if (lockError) {
        return NextResponse.json(
          {
            error:
              "Golf results and final notifications were saved, " +
              "but the slate could not be locked: " +
              lockError.message,
          },
          { status: 500 },
        );
      }

      slateAutoLocked = true;

      console.log(
        "Golf tournament finalized and slate locked",
        {
          slateId,
          tournament:
            slate.display_name ??
            tournament.name,
          winnerTeamId:
            persistedTeamRows.find(
              (row) =>
                row.finish_position === 1,
            )?.team_id ?? null,
        },
      );
    }

    return NextResponse.json({
      success: true,
      slateId,
      refreshedAt,
      tournament: {
        eventId: tournament.espnEventId,
        name: tournament.name,
        status: tournament.status,
        statusDescription: tournament.statusDescription,
        currentRound: tournament.currentRound,
        completed: tournament.completed,
        startDate: tournament.startDate,
        endDate: tournament.endDate,
      },
      scoring: {
        expectedRounds: EXPECTED_TOURNAMENT_ROUNDS,
        cutPenaltyPerRound: penaltyPerRound,
      },
      statusCounts,
      gamesFound: 1,
      playersUpserted: golfPlayerRows.length,
      eventPlayersUpserted: eventPlayerRows.length,
      playerStatsUpserted: eventPlayerRows.length,
      teamResultsUpserted: persistedTeamRows.length,
      playerFinishedNotifications,
      slateAutoLocked,
      slateCompleteNotifications,
      roundsInserted: roundRows.length,
      holesInserted: holeRows.length,
      courseHolesUpserted,
      preview: competitors.slice(0, 10).map((competitor) => {
        const playerId = playerIdByEspnId.get(competitor.espnPlayerId)!;

        const eventRow = eventPlayerRows.find(
          (row) => row.player_id === playerId,
        );

        return {
          espnPlayerId: competitor.espnPlayerId,
          displayName: competitor.displayName,
          leaderboardOrder: competitor.leaderboardOrder,
          officialScoreDisplay: competitor.officialScoreDisplay,
          roundsCompleted: competitor.roundsCompleted,
          holesCompleted: competitor.holesCompleted,
          status: competitor.status,
          penaltyStrokes: eventRow?.penalty_strokes ?? 0,
          fantasyScore: eventRow?.fantasy_score ?? null,
        };
      }),
    });
  } catch (error) {
    console.error("Unexpected Golf refresh error:", error);

    return NextResponse.json(
      {
        error:
          error instanceof Error
            ? error.message
            : "Unexpected server error while refreshing Golf data.",
      },
      { status: 500 },
    );
  }
}
