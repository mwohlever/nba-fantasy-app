"use client";

import { useState } from "react";
import PlayerHeadshot from "@/components/ui/PlayerHeadshot";
import GolfHoleReplayPanel from "@/components/lineups/GolfHoleReplayPanel";
import type {
  GolfHoleStat,
  GolfRoundStat,
  Player,
  PlayerStat,
} from "@/components/lineups/types";

type Props = {
  player: Player;
  stat: PlayerStat | null;
  slateId: number | null;
  onClose: () => void;
};

function formatToPar(value: number | null | undefined) {
  if (value === null || value === undefined) return "—";
  if (value === 0) return "E";
  return value > 0 ? `+${value}` : String(value);
}

function formatPosition(value: number | null | undefined) {
  if (!value) return "—";
  return `T${value}`;
}

function statusLabel(stat: PlayerStat | null) {
  const status = stat?.status ?? "scheduled";

  if (status === "active") {
    return stat?.last_hole
      ? `Round ${stat.current_round ?? "—"} · Thru ${stat.last_hole}`
      : `Round ${stat?.current_round ?? "—"}`;
  }

  if (status === "finished") return "Tournament complete";
  if (status === "cut") return "Missed cut";
  if (status === "withdrawn") return "Withdrawn";
  if (status === "disqualified") return "Disqualified";
  if (status === "did_not_start") return "Did not start";

  return stat?.tee_time_raw || "Scheduled";
}

function holeClass(hole: GolfHoleStat) {
  const relative = hole.relative_to_par;

  if (relative === null) {
    return "border-slate-200 bg-slate-50 text-slate-400";
  }

  if (relative <= -2) {
    return "border-emerald-700 bg-emerald-700 text-white ring-2 ring-emerald-200";
  }

  if (relative === -1) {
    return "border-emerald-300 bg-emerald-100 text-emerald-900";
  }

  if (relative === 0) {
    return "border-slate-200 bg-white text-slate-700";
  }

  if (relative === 1) {
    return "border-red-300 bg-red-100 text-red-900";
  }

  return "border-red-700 bg-red-700 text-white ring-2 ring-red-200";
}

function holeValue(hole: GolfHoleStat) {
  if (hole.relative_to_par === null) return "—";
  if (hole.relative_to_par === 0) return "E";
  return hole.relative_to_par > 0
    ? `+${hole.relative_to_par}`
    : String(hole.relative_to_par);
}

function holePar(hole: GolfHoleStat | null | undefined) {
  if (
    hole?.par !== null &&
    hole?.par !== undefined &&
    Number.isFinite(Number(hole.par))
  ) {
    return Number(hole.par);
  }

  if (
    hole?.strokes === null ||
    hole?.strokes === undefined ||
    hole.relative_to_par === null ||
    hole.relative_to_par === undefined
  ) {
    return null;
  }

  const par =
    Number(hole.strokes) -
    Number(hole.relative_to_par);

  return Number.isFinite(par) ? par : null;
}

function holeResultName(
  relative: number | null | undefined,
) {
  if (relative === null || relative === undefined) {
    return "Not played";
  }

  if (relative <= -3) return "Albatross or better";
  if (relative === -2) return "Eagle";
  if (relative === -1) return "Birdie";
  if (relative === 0) return "Par";
  if (relative === 1) return "Bogey";
  if (relative === 2) return "Double bogey";
  return `+${relative}`;
}

function holeTitle(
  holeNumber: number,
  hole: GolfHoleStat,
) {
  const par = holePar(hole);
  const yardage =
    hole.yards === null ||
    hole.yards === undefined
      ? null
      : Number(hole.yards);

  const courseDetail = [
    `Hole ${holeNumber}`,
    par === null ? null : `Par ${par}`,
    yardage === null ? null : `${yardage} yards`,
  ]
    .filter(Boolean)
    .join(" · ");

  if (hole.strokes === null) {
    return `${courseDetail} · Not played`;
  }

  return `${courseDetail} · ${hole.strokes} strokes (${holeValue(
    hole,
  )})`;
}

function PenaltyRound({
  roundNumber,
  score,
  status,
}: {
  roundNumber: number;
  score: number;
  status: string;
}) {
  const label =
    status === "cut"
      ? "Missed-cut penalty"
      : status === "withdrawn"
        ? "Withdrawal penalty"
        : status === "disqualified"
          ? "Disqualification penalty"
          : "Penalty round";

  return (
    <section className="rounded-2xl border border-amber-300 bg-amber-50 p-4 shadow-sm">
      <header className="flex items-center justify-between gap-4">
        <div>
          <span className="text-xs font-bold uppercase tracking-wider text-amber-800">
            Round {roundNumber}
          </span>

          <div className="mt-1 text-sm text-amber-800">
            {label}
          </div>
        </div>

        <strong className="text-2xl font-black text-amber-950">
          {formatToPar(score)}
        </strong>
      </header>

      <div className="mt-4 rounded-xl border border-dashed border-amber-300 bg-white/60 px-4 py-4 text-sm text-amber-900">
        No holes played. This round score was added under the league penalty
        rule.
      </div>
    </section>
  );
}

function formatGolfTeeTime(
  value: string | null | undefined,
) {
  if (!value) return null;

  const parsed = new Date(value);

  if (Number.isNaN(parsed.getTime())) {
    return value;
  }

  return parsed.toLocaleString([], {
    weekday: "short",
    month: "short",
    day: "numeric",
    hour: "numeric",
    minute: "2-digit",
  });
}

function RoundScorecard({
  round,
  contextLabel,
  isExpanded,
  onToggle,
  slateId,
  playerId,
}: {
  round: GolfRoundStat;
  contextLabel: string;
  isExpanded: boolean;
  onToggle: () => void;
  slateId: number | null;
  playerId: number;
}) {
  const holesByNumber = new Map(
    round.holes.map((hole) => [hole.hole_number, hole]),
  );

  const [selectedHoleNumber, setSelectedHoleNumber] =
    useState<number | null>(null);

  const roundProgress =
    round.holes_completed >= 18
      ? "Complete"
      : round.holes_completed > 0
        ? `Thru ${round.holes_completed}`
        : formatGolfTeeTime(
            round.tee_time ?? round.tee_time_raw,
          ) ?? "Not started";

  return (
    <section className="overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm">
      <button
        type="button"
        onClick={onToggle}
        aria-expanded={isExpanded}
        className="flex w-full items-center justify-between gap-4 px-4 py-4 text-left transition hover:bg-slate-50"
      >
        <div className="min-w-0">
          <span className="text-[10px] font-bold uppercase tracking-[0.15em] text-emerald-700">
            {contextLabel}
          </span>

          <div className="mt-1 flex flex-wrap items-center gap-x-3 gap-y-1">
            <strong className="text-base text-slate-950">
              Round {round.round_number}
            </strong>

            <span className="text-sm text-slate-500">
              {roundProgress}
            </span>
          </div>
        </div>

        <div className="flex shrink-0 items-center gap-3">
          <div className="text-right">
            <strong className="block text-xl font-black text-slate-950">
              {formatToPar(round.score_to_par)}
            </strong>

            <span className="block text-[10px] font-bold uppercase text-slate-500">
              {round.strokes ?? "—"} strokes
            </span>
          </div>

          <span
            aria-hidden="true"
            className={`flex h-9 w-9 items-center justify-center rounded-full border border-slate-200 bg-slate-50 text-lg font-bold text-slate-600 transition-transform ${
              isExpanded ? "rotate-180" : ""
            }`}
          >
            ⌄
          </span>
        </div>
      </button>

      {isExpanded ? (
        <div className="border-t border-slate-200 px-4 pb-4 pt-4">
          <div className="overflow-x-auto pb-2">
            <div className="grid min-w-[700px] grid-cols-18 gap-1.5">
              {Array.from({ length: 18 }, (_, index) => index + 1).map(
                (holeNumber) => (
                  <div
                    key={`number-${holeNumber}`}
                    className="text-center text-[10px] font-bold text-slate-400"
                  >
                    {holeNumber}
                  </div>
                ),
              )}

              {Array.from({ length: 18 }, (_, index) => index + 1).map(
                (holeNumber) => (
                  <div
                    key={`par-${holeNumber}`}
                    className={
                      holeNumber === 1
                        ? "relative text-center text-[9px] font-bold text-slate-500 before:absolute before:right-full before:mr-2 before:content-['Par']"
                        : "text-center text-[9px] font-bold text-slate-500"
                    }
                  >
                    {holePar(
                      holesByNumber.get(holeNumber),
                    ) ?? "—"}
                  </div>
                ),
              )}

              {Array.from({ length: 18 }, (_, index) => index + 1).map(
                (holeNumber) => {
                  const hole =
                    holesByNumber.get(holeNumber) ??
                    ({
                      hole_number: holeNumber,
                      strokes: null,
                      relative_to_par: null,
                      score_display: null,
                    } satisfies GolfHoleStat);

                  const isSelected =
                    selectedHoleNumber === holeNumber;

                  const par = holePar(hole);

                  const yardage =
                    hole.yards === null ||
                    hole.yards === undefined
                      ? null
                      : Number(hole.yards);

                  return (
                    <div
                      key={`score-${holeNumber}`}
                      className="relative"
                    >
                      <button
                        type="button"
                        className={`flex h-9 w-full items-center justify-center rounded-lg border text-xs font-black ${holeClass(
                          hole,
                        )}`}
                        title={holeTitle(holeNumber, hole)}
                        aria-label={holeTitle(
                          holeNumber,
                          hole,
                        )}
                        aria-expanded={isSelected}
                        onClick={() =>
                          setSelectedHoleNumber(
                            isSelected
                              ? null
                              : holeNumber,
                          )
                        }
                      >
                        {holeValue(hole)}
                      </button>

                    </div>
                  );
                },
              )}
            </div>
          </div>

          {selectedHoleNumber !== null ? (() => {
            const selectedHole =
              holesByNumber.get(
                selectedHoleNumber,
              );

            const selectedPar =
              holePar(selectedHole);

            const selectedYardage =
              selectedHole?.yards === null ||
              selectedHole?.yards === undefined
                ? null
                : Number(selectedHole.yards);

            return slateId ? (
              <GolfHoleReplayPanel
                slateId={slateId}
                playerId={playerId}
                roundNumber={round.round_number}
                holeNumber={selectedHoleNumber}
                fallbackPar={selectedPar}
                fallbackYardage={
                  selectedYardage
                }
                fallbackResult={holeResultName(
                  selectedHole
                    ?.relative_to_par,
                )}
                onClose={() =>
                  setSelectedHoleNumber(null)
                }
              />
            ) : (
              <div className="mt-4 rounded-xl border border-slate-200 bg-slate-50 px-4 py-3 text-sm text-slate-500">
                Shot tracking is unavailable because
                this scorecard is not connected to a
                Golf slate.
              </div>
            );
          })() : null}
        </div>
      ) : null}
    </section>
  );
}

export default function GolfPlayerModal({
  player,
  stat,
  slateId,
  onClose,
}: Props) {
  const persistedRounds = [
    ...(stat?.rounds ?? []),
  ].sort(
    (a, b) =>
      a.round_number -
      b.round_number,
  );

  const scheduledFallbackRound: GolfRoundStat = {
    round_number: Math.min(
      4,
      Math.max(
        1,
        Number(
          stat?.current_round ??
            Number(
              stat?.rounds_completed ??
                0,
            ) +
              1,
        ),
      ),
    ),
    score_to_par: null,
    score_display: null,
    strokes: null,
    holes_completed: 0,
    tee_time:
      stat?.tee_time ?? null,
    tee_time_raw:
      stat?.tee_time_raw ?? null,
    status: "scheduled",
    holes: [],
  };

  const rounds =
    persistedRounds.length > 0
      ? persistedRounds
      : stat?.status === "scheduled"
        ? [scheduledFallbackRound]
        : [];

  const activelyPlayingRound =
    rounds
      .filter(
        (round) =>
          round.holes_completed > 0 &&
          round.holes_completed < 18,
      )
      .at(-1) ?? null;

  const mostRecentPlayedRound =
    rounds
      .filter(
        (round) =>
          round.holes_completed > 0 ||
          round.strokes !== null,
      )
      .at(-1) ?? null;

  const upcomingRound =
    rounds.find(
      (round) =>
        round.status ===
          "scheduled" ||
        (
          round.holes_completed ===
            0 &&
          round.strokes === null
        ),
    ) ?? null;

  const primaryRound =
    activelyPlayingRound ??
    mostRecentPlayedRound ??
    upcomingRound;

  /*
   * Every returned round is meaningful. In particular, a
   * scheduled round must remain visible even when PGA has not
   * published a tee time yet.
   */
  const visibleRounds = rounds;

  const [expandedRoundNumbers, setExpandedRoundNumbers] =
    useState<number[]>(() =>
      primaryRound ? [primaryRound.round_number] : [],
    );

  function toggleRound(roundNumber: number) {
    setExpandedRoundNumbers((current) =>
      current.includes(roundNumber)
        ? current.filter(
            (value) => value !== roundNumber,
          )
        : [...current, roundNumber],
    );
  }

  const completedRoundNumbers = new Set(
    rounds
      .filter(
        (round) =>
          round.holes_completed > 0 ||
          round.strokes !== null,
      )
      .map((round) => round.round_number),
  );

  const missingRoundNumbers = [1, 2, 3, 4].filter(
    (roundNumber) =>
      !completedRoundNumbers.has(roundNumber),
  );

  const totalPenalty = Number(
    stat?.penalty_strokes ?? 0,
  );

  const penaltyRoundNumbers =
    totalPenalty > 0
      ? missingRoundNumbers
      : [];

  const penaltyPerRound =
    penaltyRoundNumbers.length > 0
      ? totalPenalty / penaltyRoundNumbers.length
      : 0;

  return (
    <div
      className="golf-player-modal-overlay mobile-modal-safe fixed inset-0 z-[11000] flex items-end justify-center bg-slate-950/60 px-1 py-1 backdrop-blur-sm sm:items-center sm:px-3 sm:py-4"
      onMouseDown={(event) => {
        if (event.target === event.currentTarget) {
          onClose();
        }
      }}
    >
      <section
        role="dialog"
        aria-modal="true"
        aria-label={`${player.name} Golf scorecard`}
        className="golf-player-modal-shell mobile-modal-panel-safe flex max-h-[97dvh] w-full max-w-6xl flex-col overflow-hidden rounded-2xl bg-slate-50 shadow-2xl sm:max-h-[94dvh] sm:rounded-3xl"
      >
        <header className="relative border-b border-slate-200 bg-slate-950 px-4 py-5 text-white sm:px-6 sm:py-6">
          <button
            type="button"
            onClick={onClose}
            className="absolute right-4 top-4 flex h-10 w-10 items-center justify-center rounded-full bg-white/10 text-2xl transition hover:bg-white/20"
            aria-label="Close Golf scorecard"
          >
            ×
          </button>

          <div className="flex items-center gap-4 pr-12">
            <PlayerHeadshot
              espnGolfPlayerId={player.espn_player_id}
              imageUrl={player.headshot_url}
              playerName={player.name}
              size="xl"
              className="border-white/20 bg-white/10"
            />

            <div className="min-w-0">
              <div className="text-xs font-bold uppercase tracking-[0.2em] text-emerald-300">
                Tournament scorecard
              </div>

              <h2 className="mt-2 truncate text-3xl font-black">
                {player.name}
              </h2>

              <div className="mt-2 flex flex-wrap items-center gap-2 text-sm text-slate-300">
                {player.country ? <span>{player.country}</span> : null}

                <span>{statusLabel(stat)}</span>

                <span>
                  OWGR{" "}
                  {player.owgr_rank
                    ? `#${player.owgr_rank}`
                    : "—"}
                </span>
              </div>
            </div>
          </div>

          <div className="mt-6 grid grid-cols-2 gap-3">
            <div className="rounded-2xl bg-white/10 p-3">
              <span className="block text-xs uppercase text-slate-400">
                Position
              </span>

              <strong className="mt-1 block text-2xl">
                {formatPosition(stat?.leaderboard_order)}
              </strong>
            </div>

            <div className="rounded-2xl bg-emerald-500/20 p-3">
              <span className="block text-xs uppercase text-emerald-200">
                Score
              </span>

              <strong className="mt-1 block text-2xl">
                {formatToPar(stat?.fantasy_points)}
              </strong>
            </div>
          </div>

          {Number(stat?.penalty_strokes ?? 0) > 0 ? (
            <div className="mt-4 rounded-xl border border-amber-300/30 bg-amber-400/10 px-3 py-2 text-sm text-amber-100">
              Includes +{stat?.penalty_strokes} from unplayed-round
              penalties.
            </div>
          ) : null}
        </header>

        <div className="space-y-4 overflow-y-auto p-4 sm:p-5">
          {rounds.length === 0 ? (
            <div className="rounded-2xl border border-dashed border-slate-300 bg-white px-5 py-10 text-center text-sm text-slate-500">
              No completed holes are available yet.
            </div>
          ) : (
            <>
              {[...visibleRounds]
                .sort((a, b) => {
                  const aIsPrimary =
                    a.round_number ===
                    primaryRound?.round_number;

                  const bIsPrimary =
                    b.round_number ===
                    primaryRound?.round_number;

                  if (aIsPrimary) return -1;
                  if (bIsPrimary) return 1;

                  const aIsUpcoming =
                    a.holes_completed === 0 &&
                    a.strokes === null;

                  const bIsUpcoming =
                    b.holes_completed === 0 &&
                    b.strokes === null;

                  if (aIsUpcoming && bIsUpcoming) {
                    return a.round_number - b.round_number;
                  }

                  if (aIsUpcoming) return -1;
                  if (bIsUpcoming) return 1;

                  return b.round_number - a.round_number;
                })
                .map((round) => {
                  const isPrimary =
                    round.round_number ===
                    primaryRound?.round_number;

                  const isUpcoming =
                    round.holes_completed === 0 &&
                    round.strokes === null;

                  const contextLabel = isPrimary
                    ? activelyPlayingRound
                      ? "Current round"
                      : "Most recent round"
                    : isUpcoming
                      ? "Upcoming round"
                      : "Previous round";

                  return (
                    <RoundScorecard
                      key={`played-${round.round_number}`}
                      round={round}
                      contextLabel={contextLabel}
                      isExpanded={expandedRoundNumbers.includes(
                        round.round_number,
                      )}
                      onToggle={() =>
                        toggleRound(round.round_number)
                      }
                      slateId={slateId}
                      playerId={player.id}
                    />
                  );
                })}

              {penaltyRoundNumbers.map(
                (roundNumber) => (
                  <PenaltyRound
                    key={`penalty-${roundNumber}`}
                    roundNumber={roundNumber}
                    score={penaltyPerRound}
                    status={stat?.status ?? ""}
                  />
                ),
              )}
            </>
          )}
        </div>
      </section>
    </div>
  );
}
