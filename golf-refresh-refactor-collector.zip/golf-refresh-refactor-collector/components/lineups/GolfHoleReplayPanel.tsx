"use client";

import dynamic from "next/dynamic";
const GolfHoleMap2D = dynamic(
  () =>
    import(
      "@/components/lineups/GolfHoleMap2D"
    ),
  {
    ssr: false,
    loading: () => (
      <div className="rounded-xl border border-slate-700 bg-slate-900 px-4 py-8 text-center text-xs font-semibold text-slate-400">
        Loading ShotCast…
      </div>
    ),
  },
);


import {
  useCallback,
  useEffect,
  useMemo,
  useState,
} from "react";

type Coordinate = {
  x: number | null;
  y: number | null;
  tourcastX: number | null;
  tourcastY: number | null;
  tourcastZ: number | null;
};

type CoordinateSet = {
  from: Coordinate;
  to: Coordinate;
};

type ReplayShot = {
  strokeNumber: number;
  playByPlay: string | null;
  distance: string | null;
  distanceRemaining: string | null;
  strokeType: string | null;
  fromLocation: string | null;
  toLocation: string | null;
  fromLocationCode: string | null;
  toLocationCode: string | null;
  finalStroke: boolean;
  leftToRight: CoordinateSet | null;
  bottomToTop: CoordinateSet | null;
};

type Replay = {
  tournamentId: string;
  pgaPlayerId: string;
  playerName: string;
  roundNumber: number;
  holeNumber: number;
  par: number | null;
  yardage: number | null;
  holeStatus: string | null;
  holeScore: string | null;
  shots: ReplayShot[];
};

type ResponseBody = {
  success?: boolean;
  available?: boolean;
  message?: string;
  replay?: Replay | null;
  error?: string;
};

type ShotCastCalibration = {
  xScale: number;
  xOffset: number;
  yScale: number;
  yOffset: number;
  verified?: boolean;
};

type ShotCastManifestHole = {
  holeNumber: number;
  available: boolean;
  par: number | null;
  yards: number | null;
  aboutThisHole: string | null;
  localImageUrl: string | null;
  alignedMapUrl?: string | null;
  localAlignedMapUrl?: string | null;
  calibration?: ShotCastCalibration | null;
};

type ShotCastManifest = {
  tournament: {
    id: string;
    name: string | null;
  };
  course: {
    id: string;
    name: string | null;
  };
  holes: ShotCastManifestHole[];
};

type ActiveShotCastConfig = {
  title: string;
  imageUrl: string;
  imageFit: "fill" | "contain";
  calibration: ShotCastCalibration;
  calibrationVerified: boolean;
  aboutThisHole: string | null;
};

type Props = {
  slateId: number;
  playerId: number;
  roundNumber: number;
  holeNumber: number;
  fallbackPar: number | null;
  fallbackYardage: number | null;
  fallbackResult: string;
  onClose: () => void;
};

const IDENTITY_CALIBRATION: ShotCastCalibration = {
  xScale: 1,
  xOffset: 0,
  yScale: 1,
  yOffset: 0,
  verified: false,
};

const DETROIT_HOLE_8_CALIBRATION: ShotCastCalibration = {
  xScale: 2.488624,
  xOffset: -0.748272,
  yScale: 0.974452,
  yOffset: 0.127478,
  verified: true,
};

function titleCase(
  value: string | null | undefined,
) {
  if (!value) return "";

  return value
    .toLowerCase()
    .replace(/\b\w/g, (letter) =>
      letter.toUpperCase(),
    );
}

function locationLabel(
  value: string | null | undefined,
) {
  return value?.trim() || "Unknown lie";
}

function resultToneClass(
  result: string | null | undefined,
) {
  const normalized =
    result?.trim().toLowerCase() ?? "";

  if (
    normalized.includes("albatross") ||
    normalized.includes("eagle") ||
    normalized.includes("birdie")
  ) {
    return "text-emerald-300";
  }

  if (
    normalized.includes("double") ||
    normalized.includes("triple") ||
    normalized.includes("quad") ||
    /^\+\d+/.test(normalized)
  ) {
    return "text-red-400";
  }

  if (normalized.includes("bogey")) {
    return "text-red-300";
  }

  if (
    normalized === "par" ||
    normalized.includes("even")
  ) {
    return "text-slate-200";
  }

  return "text-slate-300";
}

function resultBadgeClass(
  result: string | null | undefined,
) {
  const normalized =
    result?.trim().toLowerCase() ?? "";

  if (
    normalized.includes("albatross") ||
    normalized.includes("eagle")
  ) {
    return "border-emerald-500 bg-emerald-700 text-white";
  }

  if (normalized.includes("birdie")) {
    return "border-emerald-400 bg-emerald-600 text-white";
  }

  if (
    normalized.includes("double") ||
    normalized.includes("triple") ||
    normalized.includes("quad") ||
    /^\+\d+/.test(normalized)
  ) {
    return "border-red-500 bg-red-700 text-white";
  }

  if (normalized.includes("bogey")) {
    return "border-red-400 bg-red-600 text-white";
  }

  return "border-slate-500 bg-slate-700 text-white";
}

function shotSummary(
  shot: ReplayShot,
  holeResult: string,
) {
  const pieces: string[] = [];

  if (shot.distance) {
    pieces.push(shot.distance);
  }

  if (shot.finalStroke) {
    pieces.push("In the hole");

    if (holeResult) {
      pieces.push(holeResult);
    }
  } else if (shot.distanceRemaining) {
    pieces.push(
      `${shot.distanceRemaining} remaining`,
    );
  }

  return pieces.join(" · ");
}

export default function GolfHoleReplayPanel({
  slateId,
  playerId,
  roundNumber,
  holeNumber,
  fallbackPar,
  fallbackYardage,
  fallbackResult,
  onClose,
}: Props) {
  const [replay, setReplay] =
    useState<Replay | null>(null);

  const [message, setMessage] =
    useState("");

  const [isLoading, setIsLoading] =
    useState(true);

  const [isRefreshing, setIsRefreshing] =
    useState(false);

  const [lastUpdatedAt, setLastUpdatedAt] =
    useState<Date | null>(null);

  const [
    selectedStrokeNumber,
    setSelectedStrokeNumber,
  ] = useState<number | null>(null);

  const [
    isShotCastOpen,
    setIsShotCastOpen,
  ] = useState(false);

  const [
    shotCastManifest,
    setShotCastManifest,
  ] = useState<ShotCastManifest | null>(
    null,
  );

  const [
    isManifestLoading,
    setIsManifestLoading,
  ] = useState(false);

  const loadReplay = useCallback(
    async ({
      forceRefresh = false,
      signal,
    }: {
      forceRefresh?: boolean;
      signal?: AbortSignal;
    } = {}) => {
      try {
        if (forceRefresh) {
          setIsRefreshing(true);
        } else {
          setIsLoading(true);
          setReplay(null);
        }

        setMessage("");

        const query =
          new URLSearchParams({
            slateId: String(slateId),
            playerId: String(playerId),
            round: String(roundNumber),
            hole: String(holeNumber),
          });

        if (forceRefresh) {
          query.set(
            "refresh",
            String(Date.now()),
          );
        }

        const response = await fetch(
          `/api/golf/hole-replay?${query}`,
          {
            cache: "no-store",
            signal,
          },
        );

        const result =
          (await response.json()) as ResponseBody;

        if (!response.ok) {
          setMessage(
            result.error ||
              "Unable to load shot tracking.",
          );
          return;
        }

        if (!result.replay) {
          setMessage(
            result.message ||
              "Shot tracking is not available for this hole yet.",
          );
          return;
        }

        setReplay(result.replay);

        if (!result.available) {
          setMessage(
            result.message ||
              "This hole has not started yet.",
          );
        }

        setSelectedStrokeNumber(
          result.replay.shots[0]
            ?.strokeNumber ?? null,
        );
        setLastUpdatedAt(new Date());
      } catch (error) {
        if (
          error instanceof DOMException &&
          error.name === "AbortError"
        ) {
          return;
        }

        console.error(
          "Unable to load Golf hole replay",
          error,
        );

        setMessage(
          "Unable to load shot tracking.",
        );
      } finally {
        setIsLoading(false);
        setIsRefreshing(false);
      }
    },
    [
      slateId,
      playerId,
      roundNumber,
      holeNumber,
    ],
  );

  useEffect(() => {
    const controller =
      new AbortController();

    void loadReplay({
      signal: controller.signal,
    });

    return () => controller.abort();
  }, [loadReplay]);

  useEffect(() => {
    const tournamentId =
      replay?.tournamentId?.trim() ?? "";

    if (!tournamentId) {
      setShotCastManifest(null);
      return;
    }

    const controller =
      new AbortController();

    async function loadManifest() {
      try {
        setIsManifestLoading(true);

        const databaseResponse =
          await fetch(
            `/api/golf/shotcast-manifest?tournamentId=${encodeURIComponent(
              tournamentId,
            )}`,
            {
              cache: "no-store",
              signal:
                controller.signal,
            },
          );

        if (databaseResponse.ok) {
          const manifest =
            (await databaseResponse.json()) as ShotCastManifest;

          setShotCastManifest(
            manifest,
          );

          return;
        }

        /*
         * Preserve previously committed static manifests,
         * including the current Wyndham checkpoint.
         */
        const staticResponse =
          await fetch(
            `/shotcast/${encodeURIComponent(
              tournamentId,
            )}/manifest.json`,
            {
              cache: "no-store",
              signal:
                controller.signal,
            },
          );

        if (!staticResponse.ok) {
          setShotCastManifest(null);
          return;
        }

        const manifest =
          (await staticResponse.json()) as ShotCastManifest;

        setShotCastManifest(manifest);
      } catch (error) {
        if (
          error instanceof DOMException &&
          error.name === "AbortError"
        ) {
          return;
        }

        console.warn(
          "Unable to load ShotCast manifest",
          error,
        );

        setShotCastManifest(null);
      } finally {
        setIsManifestLoading(false);
      }
    }

    void loadManifest();

    return () => controller.abort();
  }, [replay?.tournamentId]);

  const activeShotCastConfig =
    useMemo<ActiveShotCastConfig | null>(
      () => {
        /*
         * Preserve the verified Rocket Classic proof of
         * concept until that event has its own manifest.
         */
        if (
          slateId === 161 &&
          holeNumber === 8
        ) {
          return {
            title:
              "Detroit Golf Club · Hole 8",
            imageUrl:
              "/tourcast/rocket-classic/hole-8/terrain08-web.jpg",
            imageFit: "fill",
            calibration:
              DETROIT_HOLE_8_CALIBRATION,
            calibrationVerified: true,
            aboutThisHole: null,
          };
        }

        const manifestHole =
          shotCastManifest?.holes.find(
            (hole) =>
              Number(
                hole.holeNumber,
              ) === holeNumber,
          ) ?? null;

        const imageUrl =
          manifestHole
            ?.localAlignedMapUrl ||
          manifestHole
            ?.localImageUrl ||
          null;

        if (!imageUrl) {
          return null;
        }

        const calibration =
          manifestHole?.calibration &&
          Number.isFinite(
            manifestHole
              .calibration.xScale,
          ) &&
          Number.isFinite(
            manifestHole
              .calibration.xOffset,
          ) &&
          Number.isFinite(
            manifestHole
              .calibration.yScale,
          ) &&
          Number.isFinite(
            manifestHole
              .calibration.yOffset,
          )
            ? manifestHole.calibration
            : IDENTITY_CALIBRATION;

        return {
          title: `${
            shotCastManifest?.course
              .name ||
            "Golf course"
          } · Hole ${holeNumber}`,

          imageUrl,

          imageFit:
            manifestHole
              ?.localAlignedMapUrl
              ? "fill"
              : "contain",

          calibration,

          calibrationVerified:
            calibration.verified ===
            true,

          aboutThisHole:
            manifestHole
              ?.aboutThisHole ??
            null,
        };
      },
      [
        holeNumber,
        shotCastManifest,
        slateId,
      ],
    );

  const isHoleComplete = useMemo(
    () =>
      Boolean(
        replay?.shots.some(
          (shot) => shot.finalStroke,
        ),
      ),
    [replay],
  );

  const completedResult =
    isHoleComplete
      ? titleCase(replay?.holeStatus) ||
        fallbackResult
      : "";

  const displayStatus =
    isHoleComplete
      ? completedResult || "Complete"
      : replay?.shots.length
        ? "In progress"
        : replay
          ? "Not started"
          : "";

  const par =
    replay?.par ?? fallbackPar;

  const yardage =
    replay?.yardage ??
    fallbackYardage;

  return (
    <section className="mt-4 overflow-hidden rounded-2xl border border-slate-700 bg-slate-950 text-white shadow-xl">
      <header className="flex items-start justify-between gap-4 border-b border-slate-800 px-4 py-3">
        <div className="min-w-0">
          <div className="flex flex-wrap items-center gap-2">
            <div className="text-[10px] font-black uppercase tracking-[0.16em] text-emerald-400">
              Hole replay
            </div>

            {!isHoleComplete &&
            replay?.shots.length ? (
              <span className="inline-flex items-center gap-1 rounded-full border border-red-500/40 bg-red-500/10 px-2 py-0.5 text-[9px] font-black uppercase text-red-300">
                <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-red-400" />
                Live
              </span>
            ) : null}
          </div>

          <h4 className="mt-1 text-lg font-black">
            Hole {holeNumber}
          </h4>

          <div className="mt-1 flex flex-wrap gap-x-2 gap-y-1 text-xs text-slate-400">
            <span>
              {par === null
                ? "Par —"
                : `Par ${par}`}
            </span>

            {yardage !== null ? (
              <>
                <span aria-hidden="true">·</span>
                <span>{yardage} yards</span>
              </>
            ) : null}

            {displayStatus ? (
              <>
                <span aria-hidden="true">·</span>

                <strong
                  className={
                    isHoleComplete
                      ? resultToneClass(
                          completedResult,
                        )
                      : "text-amber-300"
                  }
                >
                  {displayStatus}
                </strong>
              </>
            ) : null}
          </div>
        </div>

        <div className="flex shrink-0 items-center gap-2">
          <button
            type="button"
            onClick={() =>
              void loadReplay({
                forceRefresh: true,
              })
            }
            disabled={isRefreshing}
            className="inline-flex h-9 items-center justify-center rounded-xl border border-emerald-700 bg-emerald-950 px-3 text-[11px] font-bold text-emerald-200 transition hover:bg-emerald-900 disabled:cursor-not-allowed disabled:opacity-60"
            aria-label="Refresh this hole's shot tracking"
          >
            {isRefreshing
              ? "Refreshing…"
              : "↻ Refresh hole"}
          </button>

          <button
            type="button"
            onClick={onClose}
            className="flex h-9 w-9 items-center justify-center rounded-full border border-slate-700 bg-slate-900 text-xl text-slate-300 transition hover:bg-slate-800"
            aria-label="Close hole replay"
          >
            ×
          </button>
        </div>
      </header>

      {isLoading ? (
        <div className="px-4 py-7 text-center">
          <div className="text-sm font-bold text-emerald-300">
            Loading shot tracking…
          </div>

          <div className="mt-1 text-xs text-slate-500">
            Loaded only when you open a hole.
          </div>
        </div>
      ) : message && !replay ? (
        <div className="px-4 py-6 text-center">
          <div className="text-sm font-bold text-slate-200">
            Shot tracking unavailable
          </div>

          <div className="mt-1 text-xs leading-5 text-slate-500">
            {message}
          </div>

          <button
            type="button"
            onClick={() =>
              void loadReplay({
                forceRefresh: true,
              })
            }
            disabled={isRefreshing}
            className="mt-4 rounded-xl border border-emerald-700 bg-emerald-950 px-4 py-2 text-xs font-bold text-emerald-200 disabled:opacity-60"
          >
            Try again
          </button>
        </div>
      ) : replay ? (
        <div className="p-3 sm:p-4">
          {message ? (
            <div className="mb-3 rounded-xl border border-amber-700/60 bg-amber-950/40 px-3 py-2 text-xs text-amber-200">
              {message}
            </div>
          ) : null}

          {activeShotCastConfig ? (
            <div className="mb-3">
              <div className="flex flex-wrap items-center justify-between gap-3 rounded-xl border border-slate-800 bg-slate-900 px-3 py-2.5">
                <div>
                  <div className="flex flex-wrap items-center gap-2">
                    <div className="text-xs font-bold text-slate-200">
                      ShotCast
                    </div>

                    {!activeShotCastConfig
                      .calibrationVerified ? (
                      <span className="rounded-full border border-amber-700/60 bg-amber-950/50 px-2 py-0.5 text-[8px] font-black uppercase tracking-wide text-amber-300">
                        Layout preview
                      </span>
                    ) : null}
                  </div>

                  <div className="mt-0.5 text-[10px] text-slate-500">
                    {activeShotCastConfig
                      .calibrationVerified
                      ? "Interactive aerial shot replay"
                      : "Interactive hole layout · shot alignment pending"}
                  </div>
                </div>

                <button
                  type="button"
                  onClick={() =>
                    setIsShotCastOpen(
                      (current) =>
                        !current,
                    )
                  }
                  aria-expanded={
                    isShotCastOpen
                  }
                  className={`rounded-lg border px-3 py-1.5 text-[10px] font-bold transition ${
                    isShotCastOpen
                      ? "border-slate-600 bg-slate-950 text-slate-300"
                      : "border-emerald-600 bg-emerald-950 text-emerald-200 hover:bg-emerald-900"
                  }`}
                >
                  {isShotCastOpen
                    ? "Hide ShotCast"
                    : "Open ShotCast"}
                </button>
              </div>

              {isShotCastOpen ? (
                <div className="mt-3">
                  <GolfHoleMap2D
                    title={
                      activeShotCastConfig
                        .title
                    }
                    imageUrl={
                      activeShotCastConfig
                        .imageUrl
                    }
                    imageFit={
                      activeShotCastConfig
                        .imageFit
                    }
                    calibration={
                      activeShotCastConfig
                        .calibration
                    }
                    showShotOverlay={
                      activeShotCastConfig
                        .calibrationVerified
                    }
                    emptyStateLabel={
                      replay.shots.length === 0
                        ? "This hole has not started. The course layout is available now, and shot paths will appear once play begins and alignment is verified."
                        : activeShotCastConfig
                              .calibrationVerified
                          ? "No plottable shot coordinates were returned."
                          : "Shot data is available, but its placement is hidden until this hole’s map alignment is verified."
                    }
                    shots={replay.shots}
                    selectedStrokeNumber={
                      selectedStrokeNumber
                    }
                    onSelectStroke={
                      setSelectedStrokeNumber
                    }
                  />

                  {activeShotCastConfig
                    .aboutThisHole ? (
                    <div className="mt-3 rounded-xl border border-slate-800 bg-slate-900 px-3 py-2.5">
                      <div className="text-[9px] font-black uppercase tracking-[0.14em] text-slate-500">
                        About this hole
                      </div>

                      <div className="mt-1 text-xs leading-5 text-slate-400">
                        {
                          activeShotCastConfig
                            .aboutThisHole
                        }
                      </div>
                    </div>
                  ) : null}
                </div>
              ) : null}
            </div>
          ) : isManifestLoading ? (
            <div className="mb-3 rounded-xl border border-slate-800 bg-slate-900 px-3 py-3 text-xs text-slate-500">
              Checking for ShotCast course assets…
            </div>
          ) : null}

          <div className="overflow-hidden rounded-xl border border-slate-800">
            {replay.shots.map(
              (shot, index) => {
                const summary =
                  shotSummary(
                    shot,
                    completedResult,
                  );

                const isCurrentBall =
                  !isHoleComplete &&
                  index ===
                    replay.shots.length - 1;

                const isSelectedShot =
                  shot.strokeNumber ===
                  selectedStrokeNumber;

                return (
                  <button
                    type="button"
                    key={shot.strokeNumber}
                    onClick={() =>
                      setSelectedStrokeNumber(
                        shot.strokeNumber,
                      )
                    }
                    className={`block w-full px-3 py-3 text-left transition sm:px-4 ${
                      index > 0
                        ? "border-t border-slate-800"
                        : ""
                    } ${
                      isSelectedShot
                        ? "bg-emerald-500/10"
                        : isCurrentBall
                          ? "bg-amber-500/5"
                          : "hover:bg-slate-900/70"
                    }`}
                  >
                    <div className="flex gap-3">
                      <span
                        className={`flex h-7 w-7 shrink-0 items-center justify-center rounded-full border text-[11px] font-black ${
                          shot.finalStroke
                            ? resultBadgeClass(
                                completedResult,
                              )
                            : isCurrentBall
                              ? "border-amber-500 bg-amber-950 text-amber-200"
                              : "border-slate-600 bg-slate-800 text-slate-200"
                        }`}
                      >
                        {shot.strokeNumber}
                      </span>

                      <div className="min-w-0 flex-1">
                        <div className="flex flex-wrap items-baseline gap-x-2 gap-y-1">
                          <strong className="text-sm text-white">
                            Shot {shot.strokeNumber}
                          </strong>

                          {summary ? (
                            <>
                              <span
                                aria-hidden="true"
                                className="text-slate-600"
                              >
                                ·
                              </span>

                              <span
                                className={`text-sm font-bold ${
                                  shot.finalStroke
                                    ? resultToneClass(
                                        completedResult,
                                      )
                                    : "text-slate-200"
                                }`}
                              >
                                {summary}
                              </span>
                            </>
                          ) : null}

                          {isCurrentBall ? (
                            <span className="rounded-full border border-amber-700/60 bg-amber-950 px-2 py-0.5 text-[9px] font-black uppercase text-amber-300">
                              Current ball
                            </span>
                          ) : null}
                        </div>

                        <div className="mt-1 text-xs text-slate-400">
                          {locationLabel(
                            shot.fromLocation,
                          )}

                          <span
                            aria-hidden="true"
                            className="mx-2 text-slate-600"
                          >
                            →
                          </span>

                          {shot.finalStroke
                            ? "Hole"
                            : locationLabel(
                                shot.toLocation,
                              )}
                        </div>

                        {shot.playByPlay ? (
                          <div className="mt-1.5 text-[11px] leading-4 text-slate-600">
                            {shot.playByPlay}
                          </div>
                        ) : null}
                      </div>
                    </div>
                  </button>
                );
              },
            )}
          </div>

          <div className="mt-3 flex flex-wrap items-center justify-between gap-2 text-[10px] text-slate-600">
            <span>
              Shot data provided on demand from PGA TOUR tracking.
            </span>

            {lastUpdatedAt ? (
              <span>
                Updated{" "}
                {lastUpdatedAt.toLocaleTimeString(
                  [],
                  {
                    hour: "numeric",
                    minute: "2-digit",
                    second: "2-digit",
                  },
                )}
              </span>
            ) : null}
          </div>
        </div>
      ) : null}
    </section>
  );
}
